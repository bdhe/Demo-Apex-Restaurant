prompt --application/shared_components/navigation/lists/restobar
begin
--   Manifest
--     LIST: RestoBar
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(81109763105280589)
,p_name=>'RestoBar'
,p_list_status=>'PUBLIC'
,p_version_scn=>26836156
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81110414076280592)
,p_list_item_display_sequence=>8
,p_list_item_link_text=>'Home'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-home'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Home''',
''))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81110777935280594)
,p_list_item_display_sequence=>11
,p_list_item_link_text=>'Changement mot de passe'
,p_list_item_link_target=>'f?p=&APP_ID.:105:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-lock-password'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Changement mot de passe'''))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81111205404280594)
,p_list_item_display_sequence=>12
,p_list_item_link_text=>unistr('D\00E9verrouiller bon')
,p_list_item_link_target=>'f?p=&APP_ID.:139:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-unlock'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
unistr('and trim(libelle) =''D\00E9verrouiller bon''')))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81111646065280594)
,p_list_item_display_sequence=>13
,p_list_item_link_text=>unistr('Cl\00F4ture')
,p_list_item_link_target=>'f?p=&APP_ID.:158:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-check'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
unistr('and trim(libelle) =''Cl\00F4ture''')))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81111973380280594)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>'Tableau de bord'
,p_list_item_link_target=>'f?p=&APP_ID.:187:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-pie-chart-80'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Tableau de bord'''))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(83753588340281261)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Comptoir'
,p_list_item_link_target=>'f?p=&APP_ID.:67:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-cart-arrow-down'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81112855384280595)
,p_list_item_display_sequence=>21
,p_list_item_link_text=>unistr('Op\00E9ration caisse')
,p_list_item_link_target=>'f?p=&APP_ID.:47:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-money'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
unistr('and trim(libelle) =''Op\00E9ration caisse''')))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81113214594280595)
,p_list_item_display_sequence=>22
,p_list_item_link_text=>'Point de vente  [&P0_APPRO_PV_TOUS.]'
,p_list_item_icon=>'fa-address-card-o'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) like ''Point de vente%'''))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81113573681280595)
,p_list_item_display_sequence=>23
,p_list_item_link_text=>'Demande approvisionnement  [&P0_APPRO_PV.]'
,p_list_item_link_target=>'f?p=&APP_ID.:107:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and substr(trim(libelle),1,25) =''Demande approvisionnement'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81113214594280595)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81114039008280595)
,p_list_item_display_sequence=>24
,p_list_item_link_text=>unistr('R\00E9ception approvisionnement  [&P0_APPRO_RECEP_PV.]')
,p_list_item_link_target=>'f?p=&APP_ID.:132:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
unistr('and trim(libelle) like ''R\00E9ception approvisionnement%''')))
,p_parent_list_item_id=>wwv_flow_imp.id(81113214594280595)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81114455665280597)
,p_list_item_display_sequence=>26
,p_list_item_link_text=>unistr('Liste appros valid\00E9s')
,p_list_item_link_target=>'f?p=&APP_ID.:119:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
unistr('and trim(libelle) =''Liste appros valid\00E9s''')))
,p_parent_list_item_id=>wwv_flow_imp.id(81113214594280595)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81114775351280597)
,p_list_item_display_sequence=>27
,p_list_item_link_text=>'Etats'
,p_list_item_link_target=>'f?p=&APP_ID.:133:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Etats'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81113214594280595)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81115178880280597)
,p_list_item_display_sequence=>28
,p_list_item_link_text=>'Appro direct PV'
,p_list_item_link_target=>'f?p=&APP_ID.:175:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Appro direct PV'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81113214594280595)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81115603631280597)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Client'
,p_list_item_icon=>'fa-smile-o'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Client'''))
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'4,5'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81115996206280597)
,p_list_item_display_sequence=>31
,p_list_item_link_text=>'Fiche client'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Fiche client'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81115603631280597)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81116373553280598)
,p_list_item_display_sequence=>32
,p_list_item_link_text=>unistr('G\00E9n\00E9ration facture')
,p_list_item_link_target=>'f?p=&APP_ID.:102:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
unistr('and trim(libelle) =''G\00E9n\00E9ration facture''')))
,p_parent_list_item_id=>wwv_flow_imp.id(81115603631280597)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81116843408280598)
,p_list_item_display_sequence=>33
,p_list_item_link_text=>'Liste factures'
,p_list_item_link_target=>'f?p=&APP_ID.:112:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Liste factures'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81115603631280597)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81117164684280598)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Fournisseurs [&P0_CMDE_T.]'
,p_list_item_icon=>'fa-emoji-frown'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) like ''Fournisseurs%'''))
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'10,11,16,17,19,21,37,38'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81117635091280598)
,p_list_item_display_sequence=>45
,p_list_item_link_text=>'Fiche fournisseur'
,p_list_item_link_target=>'f?p=&APP_ID.:10:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Fiche fournisseur'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81117164684280598)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81117992007280598)
,p_list_item_display_sequence=>46
,p_list_item_link_text=>'Commande [&P0_CMDE_0.]'
,p_list_item_link_target=>'f?p=&APP_ID.:129:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) like ''Commande%'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81117164684280598)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81118390730280600)
,p_list_item_display_sequence=>47
,p_list_item_link_text=>'Validation commande [&P0_CMDE_0.]'
,p_list_item_link_target=>'f?p=&APP_ID.:131:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) like ''Validation commande%'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81117164684280598)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81118772180280600)
,p_list_item_display_sequence=>48
,p_list_item_link_text=>'Livraison fournisseur [&P0_CMDE_1.]'
,p_list_item_link_target=>'f?p=&APP_ID.:115:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) like  ''Livraison fournisseur%'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81117164684280598)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81119161859280600)
,p_list_item_display_sequence=>70
,p_list_item_link_text=>'Produits'
,p_list_item_icon=>'fa-lemon-o'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Produits'''))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81119587607280600)
,p_list_item_display_sequence=>71
,p_list_item_link_text=>'Produit'
,p_list_item_link_target=>'f?p=&APP_ID.:85:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Produit'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81119161859280600)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'41'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81119974859280600)
,p_list_item_display_sequence=>72
,p_list_item_link_text=>'Menu du jour'
,p_list_item_link_target=>'f?p=&APP_ID.:89:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Menu du jour'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81119161859280600)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81120399803280601)
,p_list_item_display_sequence=>80
,p_list_item_link_text=>'Production'
,p_list_item_icon=>'fa-shopping-basket'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Production'''))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81120782162280601)
,p_list_item_display_sequence=>81
,p_list_item_link_text=>'Demande appro'
,p_list_item_link_target=>'f?p=&APP_ID.:107:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Demande appro'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81120399803280601)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81121193233280601)
,p_list_item_display_sequence=>82
,p_list_item_link_text=>unistr('R\00E9ception appro')
,p_list_item_link_target=>'f?p=&APP_ID.:132:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
unistr('and trim(libelle) =''R\00E9ception appro''')))
,p_parent_list_item_id=>wwv_flow_imp.id(81120399803280601)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81121567726280601)
,p_list_item_display_sequence=>84
,p_list_item_link_text=>'Production du jour'
,p_list_item_link_target=>'f?p=&APP_ID.:127:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Production du jour'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81120399803280601)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81121988114280601)
,p_list_item_display_sequence=>85
,p_list_item_link_text=>unistr('Liste des appros valid\00E9s')
,p_list_item_link_target=>'f?p=&APP_ID.:119:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
unistr('and trim(libelle) =''Liste des appros valid\00E9s''')))
,p_parent_list_item_id=>wwv_flow_imp.id(81120399803280601)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81122409046280601)
,p_list_item_display_sequence=>86
,p_list_item_link_text=>'Appro direct'
,p_list_item_link_target=>'f?p=&APP_ID.:148:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Appro direct'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81120399803280601)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81122818659280603)
,p_list_item_display_sequence=>87
,p_list_item_link_text=>'Etats production'
,p_list_item_link_target=>'f?p=&APP_ID.:136:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Etats production'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81120399803280601)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81123175074280603)
,p_list_item_display_sequence=>100
,p_list_item_link_text=>'Stock  [&P0_SORTIE_0.]'
,p_list_item_icon=>'fa-cart-full'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) like ''Stock%'''))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81123605058280603)
,p_list_item_display_sequence=>105
,p_list_item_link_text=>unistr('Stock g\00E9n\00E9ral')
,p_list_item_link_target=>'f?p=&APP_ID.:60:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
unistr('and trim(libelle) =''Stock g\00E9n\00E9ral''')))
,p_parent_list_item_id=>wwv_flow_imp.id(81123175074280603)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81124035113280603)
,p_list_item_display_sequence=>106
,p_list_item_link_text=>'Mouvements stock'
,p_list_item_link_target=>'f?p=&APP_ID.:147:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Mouvements stock'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81123175074280603)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81124398638280603)
,p_list_item_display_sequence=>107
,p_list_item_link_text=>unistr('Mouvement stock d\00E9taill\00E9')
,p_list_item_link_target=>'f?p=&APP_ID.:181:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(81123175074280603)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81124855888280604)
,p_list_item_display_sequence=>110
,p_list_item_link_text=>'Stock initial'
,p_list_item_link_target=>'f?p=&APP_ID.:59:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Stock initial'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81123175074280603)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81125237536280604)
,p_list_item_display_sequence=>111
,p_list_item_link_text=>'Sortie [&P0_SORTIE_0.]'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) like ''Sortie%'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81123175074280603)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81125653629280604)
,p_list_item_display_sequence=>112
,p_list_item_link_text=>'Saisie/modification [&P0_SORTIE_0.]'
,p_list_item_link_target=>'f?p=&APP_ID.:802:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) like ''Saisie/modification%'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81125237536280604)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81125969453280604)
,p_list_item_display_sequence=>113
,p_list_item_link_text=>'Validation sortie  [&P0_SORTIE_0.]'
,p_list_item_link_target=>'f?p=&APP_ID.:124:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) like ''Validation sortie%'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81125237536280604)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81126443442280604)
,p_list_item_display_sequence=>114
,p_list_item_link_text=>'Liste des sorties'
,p_list_item_link_target=>'f?p=&APP_ID.:153:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Liste des sorties'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81125237536280604)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81126774496280606)
,p_list_item_display_sequence=>120
,p_list_item_link_text=>'Approvisionnements [&P0_APPRO_MAG_TOUS.]'
,p_list_item_icon=>'fa-box-arrow-in-se'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) like ''Approvisionnements%'''))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81127253261280606)
,p_list_item_display_sequence=>121
,p_list_item_link_text=>'Demande approvisionnements [&P0_APPRO_MAG.]'
,p_list_item_link_target=>'f?p=&APP_ID.:155:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) like ''Demande approvisionnements%'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81126774496280606)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81127590381280606)
,p_list_item_display_sequence=>123
,p_list_item_link_text=>'Appros directs [&P0_APPRO_DIRECTS.]'
,p_list_item_link_target=>'f?p=&APP_ID.:148:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) like ''Appros directs%'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81126774496280606)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81127960567280606)
,p_list_item_display_sequence=>126
,p_list_item_link_text=>unistr('Appros valid\00E9s ')
,p_list_item_link_target=>'f?p=&APP_ID.:110:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
unistr('and trim(libelle) like''Appros valid\00E9s%''')))
,p_parent_list_item_id=>wwv_flow_imp.id(81126774496280606)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81128400032280606)
,p_list_item_display_sequence=>127
,p_list_item_link_text=>'Validation approvisionnements [&P0_APPRO_MAG_TOUS.]'
,p_list_item_link_target=>'f?p=&APP_ID.:113:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and substr(trim(libelle),1,29) =''Validation approvisionnements'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81126774496280606)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81128821370280608)
,p_list_item_display_sequence=>140
,p_list_item_link_text=>'Inventaire  [&P0_INVENT.]'
,p_list_item_icon=>'fa-file-text-o'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) like ''Inventaire%'''))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81129253730280608)
,p_list_item_display_sequence=>141
,p_list_item_link_text=>unistr('Cr\00E9ation et validation  [&P0_INVENT.]')
,p_list_item_link_target=>'f?p=&APP_ID.:117:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
unistr('and trim(libelle) like ''Cr\00E9ation et validation%''')))
,p_parent_list_item_id=>wwv_flow_imp.id(81128821370280608)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81129565792280608)
,p_list_item_display_sequence=>142
,p_list_item_link_text=>unistr('Inventaires cl\00F4tur\00E9s')
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
unistr('and trim(libelle) =''Inventaires cl\00F4tur\00E9s''')))
,p_parent_list_item_id=>wwv_flow_imp.id(81128821370280608)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81129974862280608)
,p_list_item_display_sequence=>145
,p_list_item_link_text=>'Personnel'
,p_list_item_icon=>'fa-emoji-zipper-mouth'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Personnel'''))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81130417961280608)
,p_list_item_display_sequence=>146
,p_list_item_link_text=>'Fiche personnel'
,p_list_item_link_target=>'f?p=&APP_ID.:62:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Fiche personnel'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81129974862280608)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81130854872280609)
,p_list_item_display_sequence=>147
,p_list_item_link_text=>'Affectation'
,p_list_item_link_target=>'f?p=&APP_ID.:64:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Affectation'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81129974862280608)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81131212776280609)
,p_list_item_display_sequence=>148
,p_list_item_link_text=>'Profils'
,p_list_item_link_target=>'f?p=&APP_ID.:151:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Profils'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81129974862280608)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81131561322280609)
,p_list_item_display_sequence=>149
,p_list_item_link_text=>'Liste des bons'
,p_list_item_link_target=>'f?p=&APP_ID.:95:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-bars'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Liste des bons'''))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81132052651280609)
,p_list_item_display_sequence=>150
,p_list_item_link_text=>'Editions'
,p_list_item_icon=>'fa-format'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Editions'''))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81132418776280609)
,p_list_item_display_sequence=>151
,p_list_item_link_text=>'Journal des ventes'
,p_list_item_link_target=>'f?p=&APP_ID.:167:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Journal des ventes'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81132052651280609)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81132764887280611)
,p_list_item_display_sequence=>152
,p_list_item_link_text=>'Facture client'
,p_list_item_link_target=>'f?p=&APP_ID.:168:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Facture client'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81132052651280609)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81133256227280611)
,p_list_item_display_sequence=>153
,p_list_item_link_text=>'Commande fournisseur'
,p_list_item_link_target=>'f?p=&APP_ID.:170:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Commande fournisseur'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81132052651280609)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81133658281280611)
,p_list_item_display_sequence=>154
,p_list_item_link_text=>'Fiche invetaire'
,p_list_item_link_target=>'f?p=&APP_ID.:169:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Fiche invetaire'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81132052651280609)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81133966493280611)
,p_list_item_display_sequence=>155
,p_list_item_link_text=>'Fiche inventaire vierge'
,p_list_item_link_target=>'f?p=&APP_ID.:173:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Fiche inventaire vierge'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81132052651280609)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81134437849280611)
,p_list_item_display_sequence=>160
,p_list_item_link_text=>unistr('Param\00E8tres')
,p_list_item_icon=>'fa-key'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
unistr('and trim(libelle) =''Param\00E8tres''')))
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81134787884280612)
,p_list_item_display_sequence=>169
,p_list_item_link_text=>unistr('Param\00E8tres g\00E9n\00E9raux')
,p_list_item_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
unistr('and trim(libelle) =''Param\00E8tres g\00E9n\00E9raux''')))
,p_parent_list_item_id=>wwv_flow_imp.id(81134437849280611)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81135252362280612)
,p_list_item_display_sequence=>170
,p_list_item_link_text=>unistr('Soci\00E9t\00E9')
,p_list_item_link_target=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
unistr('and trim(libelle) =''Soci\00E9t\00E9''')))
,p_parent_list_item_id=>wwv_flow_imp.id(81134437849280611)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81135600390280612)
,p_list_item_display_sequence=>171
,p_list_item_link_text=>'Point de vente'
,p_list_item_link_target=>'f?p=&APP_ID.:22:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Point de vente'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81134437849280611)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81135979450280612)
,p_list_item_display_sequence=>173
,p_list_item_link_text=>'Contexte perte'
,p_list_item_link_target=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Contexte perte'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81134437849280611)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81136426613280612)
,p_list_item_display_sequence=>174
,p_list_item_link_text=>'Famille & Type produit'
,p_list_item_link_target=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Famille et type produit'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81134437849280611)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81136839215280612)
,p_list_item_display_sequence=>175
,p_list_item_link_text=>'Caisse'
,p_list_item_link_target=>'f?p=&APP_ID.:28:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Caisse'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81134437849280611)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(86441979263967681)
,p_list_item_display_sequence=>175
,p_list_item_link_text=>'Type produit (image)'
,p_list_item_link_target=>'f?p=&APP_ID.:700:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(81134437849280611)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81137228699280614)
,p_list_item_display_sequence=>176
,p_list_item_link_text=>unistr('Mode r\00E8glement')
,p_list_item_link_target=>'f?p=&APP_ID.:30:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
unistr('and trim(libelle) =''Mode r\00E8glement''')))
,p_parent_list_item_id=>wwv_flow_imp.id(81134437849280611)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81137622112280614)
,p_list_item_display_sequence=>177
,p_list_item_link_text=>'Nature mouvement'
,p_list_item_link_target=>'f?p=&APP_ID.:32:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Nature mouvement'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81134437849280611)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81138379614280614)
,p_list_item_display_sequence=>179
,p_list_item_link_text=>unistr('Type op\00E9ration caisse')
,p_list_item_link_target=>'f?p=&APP_ID.:36:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
unistr('and trim(libelle) =''Type op\00E9ration caisse''')))
,p_parent_list_item_id=>wwv_flow_imp.id(81134437849280611)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81138859344280614)
,p_list_item_display_sequence=>180
,p_list_item_link_text=>unistr('Type d\00E9tail produit')
,p_list_item_link_target=>'f?p=&APP_ID.:40:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
unistr('and trim(libelle) =''Type d\00E9tail produit''')))
,p_parent_list_item_id=>wwv_flow_imp.id(81134437849280611)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81139181819280615)
,p_list_item_display_sequence=>181
,p_list_item_link_text=>'Type facture'
,p_list_item_link_target=>'f?p=&APP_ID.:702:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Type facture'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81134437849280611)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81139616429280615)
,p_list_item_display_sequence=>182
,p_list_item_link_text=>'Type commande client'
,p_list_item_link_target=>'f?p=&APP_ID.:704:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Type commande client'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81134437849280611)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81139982851280615)
,p_list_item_display_sequence=>183
,p_list_item_link_text=>'Type caisse'
,p_list_item_link_target=>'f?p=&APP_ID.:706:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Type caisse'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81134437849280611)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81140411544280615)
,p_list_item_display_sequence=>184
,p_list_item_link_text=>'Etat bon'
,p_list_item_link_target=>'f?p=&APP_ID.:708:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Etat bon'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81134437849280611)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81140856389280615)
,p_list_item_display_sequence=>194
,p_list_item_link_text=>'Statut du personnel'
,p_list_item_link_target=>'f?p=&APP_ID.:51:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Statut du personnel'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81134437849280611)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81141939386280619)
,p_list_item_display_sequence=>224
,p_list_item_link_text=>unistr('Unit\00E9 de m\00E9sure')
,p_list_item_link_target=>'f?p=&APP_ID.:149:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
unistr('and trim(libelle) =''Unit\00E9 de m\00E9sure''')))
,p_parent_list_item_id=>wwv_flow_imp.id(81134437849280611)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'149,150'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81142350381280620)
,p_list_item_display_sequence=>225
,p_list_item_link_text=>'Type de produits inclus combo'
,p_list_item_link_target=>'f?p=&APP_ID.:176:&SESSION.::&DEBUG.::::'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select liste_id from profil_statut_personnel p,personnel pp',
'where  p.code_statut_personnel = pp.code_statut_personnel ',
'and trim(profil_app)=v(''app_user'')',
'and trim(libelle) =''Type de produits inclus combo'''))
,p_parent_list_item_id=>wwv_flow_imp.id(81134437849280611)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81142702127280620)
,p_list_item_display_sequence=>226
,p_list_item_link_text=>'Extras'
,p_list_item_link_target=>'f?p=&APP_ID.:183:&SESSION.::&DEBUG.::::'
,p_parent_list_item_id=>wwv_flow_imp.id(81134437849280611)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(81141164648280617)
,p_list_item_display_sequence=>214
,p_list_item_link_text=>'Administration'
,p_list_item_link_target=>'f?p=&APP_ID.:10000:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-user-wrench'
,p_security_scheme=>wwv_flow_imp.id(81141363109280619)
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'10000'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(108905320880501076)
,p_list_item_display_sequence=>20000
,p_list_item_link_text=>'Administration'
,p_list_item_link_target=>'f?p=&APP_ID.:10000:&APP_SESSION.::&DEBUG.:'
,p_list_item_icon=>'fa-user-wrench'
,p_security_scheme=>wwv_flow_imp.id(80609833232980236)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
