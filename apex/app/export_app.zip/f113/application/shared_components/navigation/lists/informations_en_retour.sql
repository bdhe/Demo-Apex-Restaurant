prompt --application/shared_components/navigation/lists/informations_en_retour
begin
--   Manifest
--     LIST: Informations en retour
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(80773109915981298)
,p_name=>'Informations en retour'
,p_list_status=>'PUBLIC'
,p_required_patch=>wwv_flow_imp.id(80607317580980225)
,p_version_scn=>26836156
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(80773557792981300)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Informations en retour des utilisateurs'
,p_list_item_link_target=>'f?p=&APP_ID.:10053:&SESSION.::&DEBUG.:10053:::'
,p_list_item_icon=>'fa-comment-o'
,p_list_text_01=>unistr('Etat de l''ensemble des informations en retour envoy\00E9es par les utilisateurs de l''application')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
