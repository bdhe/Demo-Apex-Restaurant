prompt --application/shared_components/navigation/lists/etats_d_activité
begin
--   Manifest
--     LIST: Etats d'activité
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(80769282471981283)
,p_name=>unistr('Etats d''activit\00E9')
,p_list_status=>'PUBLIC'
,p_required_patch=>wwv_flow_imp.id(80607201485980225)
,p_version_scn=>26836156
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(80769716792981284)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Tableau de bord'
,p_list_item_link_target=>'f?p=&APP_ID.:10030:&SESSION.::&DEBUG.:10030:::'
,p_list_item_icon=>'fa-area-chart'
,p_list_text_01=>unistr('Consulter les mesures d''activit\00E9 d''application')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(80770143799981286)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Principaux utilisateurs'
,p_list_item_link_target=>'f?p=&APP_ID.:10031:&SESSION.::&DEBUG.:10031:::'
,p_list_item_icon=>'fa-user-chart'
,p_list_text_01=>unistr('Etat des vues de page consolid\00E9es par utilisateur')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(80770556158981287)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Journal des erreurs de l''application'
,p_list_item_link_target=>'f?p=&APP_ID.:10032:&SESSION.::&DEBUG.:10032:::'
,p_list_item_icon=>'fa-exclamation'
,p_list_text_01=>unistr('Etat des erreurs consign\00E9es par cette application')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(80770898518981289)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Performances de page'
,p_list_item_link_target=>'f?p=&APP_ID.:10033:&SESSION.::&DEBUG.:10033:::'
,p_list_item_icon=>'fa-file-chart'
,p_list_text_01=>unistr('Etat de l''activit\00E9 et des performances par page d''application')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(80771276907981290)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Vues de page'
,p_list_item_link_target=>'f?p=&APP_ID.:10034:&SESSION.::&DEBUG.:RR,10034:::'
,p_list_item_icon=>'fa-file-search'
,p_list_text_01=>unistr('Etat de chaque vue de page par utilisateur comportant la date d''acc\00E8s et le temps \00E9coul\00E9')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(80771694113981292)
,p_list_item_display_sequence=>60
,p_list_item_link_text=>'Journal des automatisations'
,p_list_item_link_target=>'f?p=&APP_ID.:10035:&SESSION.::&DEBUG.:RR,10035:::'
,p_list_item_icon=>'fa-gears'
,p_list_item_disp_cond_type=>'EXISTS'
,p_list_item_disp_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1',
'from apex_appl_automations a, apex_automation_log l',
'where a.automation_id = l.automation_id',
'and l.application_id = :APP_ID'))
,p_list_text_01=>unistr('Etat des messages et des ex\00E9cutions d''automatisation consign\00E9s par cette application')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
