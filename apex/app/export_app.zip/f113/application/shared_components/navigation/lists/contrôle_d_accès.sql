prompt --application/shared_components/navigation/lists/contrôle_d_accès
begin
--   Manifest
--     LIST: Contrôle d'accès
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(80772006598981295)
,p_name=>unistr('Contr\00F4le d''acc\00E8s')
,p_list_status=>'PUBLIC'
,p_required_patch=>wwv_flow_imp.id(80607084056980225)
,p_version_scn=>26836156
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(80772409474981295)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Utilisateurs'
,p_list_item_link_target=>'f?p=&APP_ID.:10041:&SESSION.::&DEBUG.:RP:::'
,p_list_item_icon=>'fa-users'
,p_list_text_01=>unistr('Modifier les param\00E8tres de contr\00F4le d''acc\00E8s et d\00E9sactiver le contr\00F4le d''acc\00E8s')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(80772858911981297)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>unistr('Contr\00F4le d''acc\00E8s')
,p_list_item_link_target=>'f?p=&APP_ID.:10040:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-key'
,p_list_text_01=>unistr('D\00E9finir le niveau d''acc\00E8s des utilisateurs authentifi\00E9s de cette application')
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
