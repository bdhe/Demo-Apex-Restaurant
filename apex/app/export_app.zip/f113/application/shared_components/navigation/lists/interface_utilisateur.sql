prompt --application/shared_components/navigation/lists/interface_utilisateur
begin
--   Manifest
--     LIST: Interface utilisateur
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(80768620837981278)
,p_name=>'Interface utilisateur'
,p_list_status=>'PUBLIC'
,p_required_patch=>wwv_flow_imp.id(80607946132980225)
,p_version_scn=>26836156
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(80769029006981279)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>unistr('S\00E9lection du style de th\00E8me')
,p_list_item_link_target=>'f?p=&APP_ID.:10020:&SESSION.::&DEBUG.:10020:::'
,p_list_item_icon=>'fa-paint-brush'
,p_list_text_01=>unistr('D\00E9finir la pr\00E9sentation par d\00E9faut de l''application')
,p_required_patch=>wwv_flow_imp.id(80607946132980225)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
