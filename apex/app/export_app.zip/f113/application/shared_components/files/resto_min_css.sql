prompt --application/shared_components/files/resto_min_css
begin
--   Manifest
--     APP STATIC FILES: 113
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2E6831307B6865696768743A313070787D2E6832307B6865696768743A323070787D2E6833307B6865696768743A333070787D2E7072647B646973706C61793A626C6F636B3B6865696768743A353070783B6F766572666C6F773A6175746F7D2E722D71';
wwv_flow_imp.g_varchar2_table(2) := '74657B746578742D616C69676E3A63656E7465723B746578742D6465636F726174696F6E2D636F6C6F723A7265647D';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(55469244073618980)
,p_file_name=>'resto.min.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
