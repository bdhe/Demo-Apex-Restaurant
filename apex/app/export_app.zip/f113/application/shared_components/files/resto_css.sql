prompt --application/shared_components/files/resto_css
begin
--   Manifest
--     APP STATIC FILES: 113
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2E683130207B0D0A202020206865696768743A20313070780D0A7D0D0A0D0A2E683230207B0D0A202020206865696768743A20323070780D0A7D0D0A0D0A2E683330207B0D0A202020206865696768743A20333070780D0A7D0D0A0D0A2E707264207B0D';
wwv_flow_imp.g_varchar2_table(2) := '0A20202020646973706C61793A20626C6F636B3B0D0A202020206865696768743A20353070783B0D0A202020206F766572666C6F773A206175746F3B0D0A7D0D0A2E722D7174657B0D0A746578742D616C69676E3A2063656E7465723B0D0A746578742D';
wwv_flow_imp.g_varchar2_table(3) := '6465636F726174696F6E2D636F6C6F723A207265643B0D0A7D';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(81945106677715892)
,p_file_name=>'resto.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
