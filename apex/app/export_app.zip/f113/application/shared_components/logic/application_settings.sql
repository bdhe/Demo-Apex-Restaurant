prompt --application/shared_components/logic/application_settings
begin
--   Manifest
--     APPLICATION SETTINGS: 113
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(80610821721980245)
,p_name=>'FEEDBACK_ATTACHMENTS_YN'
,p_value=>'Y'
,p_is_required=>'N'
,p_valid_values=>'Y, N'
,p_on_upgrade_keep_value=>true
,p_required_patch=>wwv_flow_imp.id(80607317580980225)
,p_version_scn=>26836205
);
wwv_flow_imp_shared.create_app_setting(
 p_id=>wwv_flow_imp.id(80611070237980247)
,p_name=>'ACCESS_CONTROL_SCOPE'
,p_value=>'ACL_ONLY'
,p_is_required=>'N'
,p_valid_values=>'ACL_ONLY, ALL_USERS'
,p_on_upgrade_keep_value=>true
,p_required_patch=>wwv_flow_imp.id(80607084056980225)
,p_comments=>unistr('Niveau d''acc\00E8s par d\00E9faut attribu\00E9 aux utilisateurs authentifi\00E9s qui ne figurent pas dans la liste de contr\00F4le d''acc\00E8s')
,p_version_scn=>26836205
);
wwv_flow_imp.component_end;
end;
/
