prompt --application/shared_components/logic/build_options
begin
--   Manifest
--     BUILD OPTIONS: 113
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(80417125248979553)
,p_build_option_name=>'Mis en commentaire'
,p_build_option_status=>'EXCLUDE'
,p_version_scn=>26836247
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(80607084056980225)
,p_build_option_name=>unistr('Fonctionnalit\00E9: Contr\00F4le d''acc\00E8s')
,p_build_option_status=>'INCLUDE'
,p_version_scn=>26836247
,p_feature_identifier=>'APPLICATION_ACCESS_CONTROL'
,p_build_option_comment=>unistr('Incorporez l''authentification utilisateur bas\00E9e sur les r\00F4les dans votre application et g\00E9rez les mappings de nom utilisateur avec les r\00F4les d''application.')
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(80607201485980225)
,p_build_option_name=>unistr('Fonctionnalit\00E9: G\00E9n\00E9ration d''\00E9tats d''activit\00E9')
,p_build_option_status=>'INCLUDE'
,p_version_scn=>26836247
,p_feature_identifier=>'APPLICATION_ACTIVITY_REPORTING'
,p_build_option_comment=>unistr('Incluez de nombreux \00E9tats et graphiques relatifs \00E0 l''activit\00E9 des utilisateurs finals.')
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(80607317580980225)
,p_build_option_name=>unistr('Fonctionnalit\00E9: Informations en retour')
,p_build_option_status=>'INCLUDE'
,p_version_scn=>26836247
,p_feature_identifier=>'APPLICATION_FEEDBACK'
,p_build_option_comment=>unistr('Indiquez un m\00E9canisme permettant aux utilisateurs finals de publier des commentaires g\00E9n\00E9raux \00E0 l''intention des administrateurs et des d\00E9veloppeurs de l''application.')
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(80607530230980225)
,p_build_option_name=>unistr('Fonctionnalit\00E9: Options de configuration')
,p_build_option_status=>'INCLUDE'
,p_version_scn=>26836247
,p_feature_identifier=>'APPLICATION_CONFIGURATION'
,p_build_option_comment=>unistr('Autorisez les administrateurs de l''application \00E0 activer ou \00E0 d\00E9sactiver une fonctionnalit\00E9 sp\00E9cifique associ\00E9e \00E0 une option de construction d''Application Express \00E0 partir de l''application.')
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(80607822820980225)
,p_build_option_name=>unistr('Fonctionnalit\00E9: A propos de la page')
,p_build_option_status=>'INCLUDE'
,p_version_scn=>26836247
,p_feature_identifier=>'APPLICATION_ABOUT_PAGE'
,p_build_option_comment=>'A propos de cette page d''application.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(80607946132980225)
,p_build_option_name=>unistr('Fonctionnalit\00E9: S\00E9lection du style de th\00E8me')
,p_build_option_status=>'INCLUDE'
,p_version_scn=>26836247
,p_feature_identifier=>'APPLICATION_THEME_STYLE_SELECTION'
,p_build_option_comment=>unistr('Autorisez les administrateurs \00E0 s\00E9lectionner un sch\00E9ma de couleur par d\00E9faut (style de th\00E8me) pour l''application. Les administrateurs ont \00E9galement la possibilit\00E9 d''autoriser les utilisateurs \00E0 choisir leur propre style de th\00E8me. ')
);
wwv_flow_imp.component_end;
end;
/
