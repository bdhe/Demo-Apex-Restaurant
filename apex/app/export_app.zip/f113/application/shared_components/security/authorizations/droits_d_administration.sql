prompt --application/shared_components/security/authorizations/droits_d_administration
begin
--   Manifest
--     SECURITY SCHEME: Droits d'administration
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(80609833232980236)
,p_name=>'Droits d''administration'
,p_scheme_type=>'NATIVE_IS_IN_GROUP'
,p_attribute_01=>'Administrateur'
,p_attribute_02=>'A'
,p_error_message=>unistr('Privil\00E8ges insuffisants, l''utilisateur n''est pas un administrateur')
,p_version_scn=>26836205
,p_caching=>'BY_USER_BY_PAGE_VIEW'
);
wwv_flow_imp.component_end;
end;
/
