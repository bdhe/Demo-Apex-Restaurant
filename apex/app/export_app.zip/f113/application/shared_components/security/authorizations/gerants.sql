prompt --application/shared_components/security/authorizations/gerants
begin
--   Manifest
--     SECURITY SCHEME: Gerants
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(86873876388868581)
,p_name=>'Gerants'
,p_scheme_type=>'NATIVE_EXISTS'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select PROFIL_APP from personnel',
'where CODE_STATUT_PERSONNEL = 1',
'and trim(PROFIL_APP) = v(''app_user'')'))
,p_error_message=>unistr('Vous devez \00EAtre administrateur avant d''acc\00E9der a cette fonctionnalit\00E9')
,p_version_scn=>26836205
,p_caching=>'BY_USER_BY_SESSION'
);
wwv_flow_imp.component_end;
end;
/
