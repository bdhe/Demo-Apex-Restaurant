prompt --application/shared_components/user_interface/lovs/nature_opération
begin
--   Manifest
--     NATURE OPÉRATION
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(86191786043697133)
,p_lov_name=>unistr('NATURE OP\00C9RATION')
,p_lov_query=>'.'||wwv_flow_imp.id(86191786043697133)||'.'
,p_location=>'STATIC'
,p_version_scn=>26836205
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(86192211040697162)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>unistr('D\00E9bit')
,p_lov_return_value=>'D'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(86192612039697164)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>unistr('Cr\00E9dit')
,p_lov_return_value=>'C'
);
wwv_flow_imp.component_end;
end;
/
