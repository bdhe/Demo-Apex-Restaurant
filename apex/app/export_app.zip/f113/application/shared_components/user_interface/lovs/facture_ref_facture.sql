prompt --application/shared_components/user_interface/lovs/facture_ref_facture
begin
--   Manifest
--     FACTURE.REF_FACTURE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(83572216971706145)
,p_lov_name=>'FACTURE.REF_FACTURE'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'FACTURE'
,p_return_column_name=>'NUM_FACTURE'
,p_display_column_name=>'REF_FACTURE'
,p_default_sort_column_name=>'REF_FACTURE'
,p_default_sort_direction=>'ASC'
,p_version_scn=>26836205
);
wwv_flow_imp.component_end;
end;
/
