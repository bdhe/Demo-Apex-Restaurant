prompt --application/shared_components/user_interface/lovs/espace_vente1
begin
--   Manifest
--     ESPACE_VENTE1
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(81314145607361272)
,p_lov_name=>'ESPACE_VENTE1'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nom_espace as d,',
'       num_espace_vente as r',
'  from espace_vente',
' order by 1'))
,p_source_type=>'LEGACY_SQL'
,p_location=>'LOCAL'
,p_version_scn=>26836205
);
wwv_flow_imp.component_end;
end;
/
