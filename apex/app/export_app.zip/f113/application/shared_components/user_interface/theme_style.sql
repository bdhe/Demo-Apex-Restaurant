prompt --application/shared_components/user_interface/theme_style
begin
--   Manifest
--     THEME STYLE: 113
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
null;
wwv_flow_imp.component_end;
end;
/
