prompt --application/pages/page_00095
begin
--   Manifest
--     PAGE: 00095
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>95
,p_name=>'Liste des bons'
,p_alias=>'LISTE-DES-BONS'
,p_step_title=>'Liste des bons'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(239167078536163558)
,p_plug_name=>unistr('P\00E9riode')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(239286494955073014)
,p_plug_name=>'Liste des bons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>'select * from bons_recap'
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P95_DATE_DEBUT,P95_DATE_FIN'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(113975811629720515)
,p_max_row_count=>'1000000'
,p_allow_save_rpt_public=>'Y'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'N'
,p_owner=>'BDHE'
,p_internal_uid=>58803251174047546
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83585828699750975)
,p_db_column_name=>'NUM_BON'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Num Bon'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83586207916750978)
,p_db_column_name=>'CODE_ETAT_BON'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Code Etat Bon'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(81311737542361267)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83586647266750978)
,p_db_column_name=>'NUM_TABLE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Num Table'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83587048201750979)
,p_db_column_name=>'NUM_CLT'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Num Clt'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(81019207167213398)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83587439336750979)
,p_db_column_name=>'REFERENCE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Reference'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83587770303750981)
,p_db_column_name=>'NUM_POINT_VENTE'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Point Vente'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(81104181522273040)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83588175503750981)
,p_db_column_name=>'NUM_ESPACE_VENTE'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Espace Vente'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(81019840160213400)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83588577779750981)
,p_db_column_name=>'NUM_VACATION'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Num Vacation'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83588992107750983)
,p_db_column_name=>'DATE_BON'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Date Bon'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/YYYY HH24:MI'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83589412190750983)
,p_db_column_name=>'LIVRE'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Livre'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(82135818362696515)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83589818196750984)
,p_db_column_name=>'PAYE'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Paye'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(80976620147194334)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83590172712750984)
,p_db_column_name=>'FACTURE'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Facture'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(80976620147194334)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83590585070750986)
,p_db_column_name=>'NB_PERS'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Nb Pers'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83590994381750986)
,p_db_column_name=>'SUSRPLACE'
,p_display_order=>140
,p_column_identifier=>'N'
,p_column_label=>'Susrplace'
,p_column_type=>'STRING'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83591444077750987)
,p_db_column_name=>'EMETTEUR'
,p_display_order=>150
,p_column_identifier=>'O'
,p_column_label=>'Emetteur'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83591819287750987)
,p_db_column_name=>'DATE_CREATION'
,p_display_order=>160
,p_column_identifier=>'P'
,p_column_label=>'Date Creation'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/YYYY HH24:MI:SS'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83592225718750987)
,p_db_column_name=>'DATE_LIV'
,p_display_order=>170
,p_column_identifier=>'Q'
,p_column_label=>'Date Liv'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/YYYY HH24:MI:SS'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83592587433750989)
,p_db_column_name=>'CODE_TYPE_PRODUIT'
,p_display_order=>180
,p_column_identifier=>'R'
,p_column_label=>'Code Type Produit'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(80978610833194342)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83593021779750989)
,p_db_column_name=>'DESIGNATION_PRODUIT'
,p_display_order=>190
,p_column_identifier=>'S'
,p_column_label=>'Designation Produit'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83593386268750990)
,p_db_column_name=>'QTE_BON'
,p_display_order=>200
,p_column_identifier=>'T'
,p_column_label=>'Qte Bon'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83593808819750992)
,p_db_column_name=>'PU_BON'
,p_display_order=>210
,p_column_identifier=>'U'
,p_column_label=>'Pu Bon'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83594242310750992)
,p_db_column_name=>'TOTAL'
,p_display_order=>230
,p_column_identifier=>'V'
,p_column_label=>'Total'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(55600309225084253)
,p_db_column_name=>'TVA'
,p_display_order=>240
,p_column_identifier=>'AA'
,p_column_label=>'Tva'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83594578096750992)
,p_db_column_name=>'CODE_MODE_REG'
,p_display_order=>250
,p_column_identifier=>'W'
,p_column_label=>unistr('Mode r\00E8glement')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(83601214007751033)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83595045447750994)
,p_db_column_name=>'DATE_DEBUT'
,p_display_order=>260
,p_column_identifier=>'X'
,p_column_label=>'Date Debut'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83595364407750994)
,p_db_column_name=>'DATE_FIN'
,p_display_order=>270
,p_column_identifier=>'Y'
,p_column_label=>'Date Fin'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(83595799990750994)
,p_db_column_name=>'DATE_PRET'
,p_display_order=>280
,p_column_identifier=>'Z'
,p_column_label=>'Date Pret'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/YYYY HH24:MI:SS'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(115376180672384710)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'65873'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NUM_BON:CODE_ETAT_BON:NUM_TABLE:NUM_CLT:REFERENCE:NUM_POINT_VENTE:NUM_ESPACE_VENTE:NUM_VACATION:DATE_BON:LIVRE:PAYE:FACTURE:NB_PERS:SUSRPLACE:EMETTEUR:DATE_CREATION:DATE_LIV:CODE_TYPE_PRODUIT:DESIGNATION_PRODUIT:QTE_BON:PU_BON:TOTAL:CODE_MODE_REG:DAT'
||'E_DEBUT:DATE_FIN:DATE_PRET:TVA'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(83583878752750954)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(239167078536163558)
,p_button_name=>unistr('G\00E9n\00E9rer')
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('G\00E9n\00E9rer')
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83584323566750962)
,p_name=>'P95_DATE_DEBUT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(239167078536163558)
,p_prompt=>'Date Debut'
,p_format_mask=>'DD/MM/YYYY'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_colspan=>4
,p_field_template=>3031561932232085882
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'appearance_and_behavior', 'MONTH-PICKER:YEAR-PICKER',
  'days_outside_month', 'VISIBLE',
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_on', 'FOCUS',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83584757046750964)
,p_name=>'P95_DATE_FIN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(239167078536163558)
,p_prompt=>'Date Fin'
,p_format_mask=>'DD/MM/YYYY'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>3031561932232085882
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'appearance_and_behavior', 'MONTH-PICKER:YEAR-PICKER',
  'days_outside_month', 'VISIBLE',
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_on', 'FOCUS',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83585100278750965)
,p_name=>'P95_ETAT_BON'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(239167078536163558)
,p_use_cache_before_default=>'NO'
,p_item_default=>'1'
,p_prompt=>'Etat Bon'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>unistr('STATIC2:Bons valides;1,Bons annul\00E9s;2')
,p_begin_on_new_line=>'N'
,p_field_template=>3031561932232085882
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83596545043751004)
,p_name=>'P95_TOTAL'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(239286494955073014)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select sum(pu_bon*qte_bon) from details_bon',
'where num_bon in (select num_bon from bons where date_bon between :p95_date_debut and :p95_date_fin);'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83596902169751014)
,p_name=>'New'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(83583878752750954)
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83597458399751017)
,p_event_id=>wwv_flow_imp.id(83596902169751014)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.APEXUTILS.EXECUTE_PLSQL_CODE'
,p_attribute_01=>' pr_genere_bon(:P95_DATE_DEBUT,:P95_DATE_FIN,:P95_ETAT_BON);'
,p_attribute_02=>'P95_DATE_DEBUT,P95_DATE_FIN,P95_ETAT_BON'
,p_attribute_04=>unistr('G\00E9n\00E9ration effectu\00E9e avec succ\00E8s')
,p_attribute_05=>'#SQLERRM#'
,p_attribute_06=>'spinner'
,p_attribute_07=>'body'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83597864980751019)
,p_event_id=>wwv_flow_imp.id(83596902169751014)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(239286494955073014)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83598442813751019)
,p_event_id=>wwv_flow_imp.id(83596902169751014)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P95_TOTAL'
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
