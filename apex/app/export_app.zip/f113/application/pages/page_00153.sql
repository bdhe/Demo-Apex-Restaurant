prompt --application/pages/page_00153
begin
--   Manifest
--     PAGE: 00153
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>153
,p_name=>'Liste des sorties stock'
,p_alias=>'LISTE-DES-SORTIES-STOCK'
,p_step_title=>'Liste des sorties stock'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(115572546618164647)
,p_plug_name=>'Liste des sorties stock'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'SORTIE_STOCK'
,p_query_where=>'num_point_vente = :P153_POINT_VENTE'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P153_POINT_VENTE'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(115572665127164647)
,p_name=>'Liste des sorties stock'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_allow_save_rpt_public=>'Y'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'BDHE'
,p_internal_uid=>60400104671491678
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85753481263218842)
,p_db_column_name=>'DATE_SORTIE'
,p_display_order=>10
,p_column_identifier=>'E'
,p_column_label=>'Date Sortie'
,p_column_type=>'DATE'
,p_format_mask=>'DD/MM/YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85751907256218837)
,p_db_column_name=>'NUM_SORTIE'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>unistr('Num\00E9ro Sortie')
,p_column_link=>'f?p=&APP_ID.:154:&SESSION.::&DEBUG.:RP:P154_NUM_SORTIE:#NUM_SORTIE#'
,p_column_linktext=>'#NUM_SORTIE#'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85752330544218839)
,p_db_column_name=>'LIBELLE'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'Libelle'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85752692123218840)
,p_db_column_name=>'CODE_TYPE_SORTIE'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'Type Sortie'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(83835165315603345)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85753061268218840)
,p_db_column_name=>'OBSERVATIONS'
,p_display_order=>50
,p_column_identifier=>'D'
,p_column_label=>'Observations'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85753870213218842)
,p_db_column_name=>'NUM_POINT_VENTE'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Point Vente'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85754268264218842)
,p_db_column_name=>'CODE_UTLISATEUR'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Code Utlisateur'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85754666397218844)
,p_db_column_name=>'DATE_ENREG'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Date Enreg'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85755064334218844)
,p_db_column_name=>'CODE_ETAT_SORTIE'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Etat Sortie'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(85759957410218861)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85755465203218845)
,p_db_column_name=>'CODE_UTILISATEUR_VALIDE'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Code Utilisateur Valide'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(115576684562165111)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'46198'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NUM_SORTIE:LIBELLE:CODE_TYPE_SORTIE:OBSERVATIONS:DATE_SORTIE:NUM_POINT_VENTE:CODE_UTLISATEUR:DATE_ENREG:CODE_ETAT_SORTIE:CODE_UTILISATEUR_VALIDE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85756228471218854)
,p_name=>'P153_PROFIL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(115572546618164647)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select code_statut_personnel  from personnel',
'    where trim(profil_app) =v(''app_user'');'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85756655105218854)
,p_name=>'P153_POINT_VENTE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(115572546618164647)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Point Vente'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'POINT_VENTE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nom_point_vente as d,',
'       num_point_vente as r',
'  from point_vente where actif=''O''',
'order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_colspan=>5
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85757008918218856)
,p_name=>'APP'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P153_PROFIL'
,p_condition_element=>'P153_PROFIL'
,p_triggering_condition_type=>'NOT_EQUALS'
,p_triggering_expression=>'3'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85757489536218858)
,p_event_id=>wwv_flow_imp.id(85757008918218856)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_pv is select num_point_vente from personnel p,affectation f',
'where p.matricule = f.matricule',
'and trim(profil_app)= v(''app_user'');',
'',
'r_pv c_pv%rowtype;',
'',
'begin',
' ',
'     open c_pv;',
'     fetch c_pv into r_pv;',
'     if c_pv%found then',
'         :P153_POINT_VENTE:= r_pv.num_point_vente;',
'         ',
'     end if;',
'     close c_pv;',
'',
'  end;'))
,p_attribute_02=>'P153_POINT_VENTE'
,p_attribute_03=>'P153_POINT_VENTE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85757985818218858)
,p_event_id=>wwv_flow_imp.id(85757008918218856)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P153_POINT_VENTE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85758367359218859)
,p_name=>'ref'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P153_POINT_VENTE'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85758959689218859)
,p_event_id=>wwv_flow_imp.id(85758367359218859)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(115572546618164647)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
