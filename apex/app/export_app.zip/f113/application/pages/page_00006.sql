prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>6
,p_name=>'Bon'
,p_alias=>'BON1'
,p_page_mode=>'MODAL'
,p_step_title=>'Bon'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(262599776221457816)
,p_plug_name=>'Reglement bon'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81047499626267829)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(262599776221457816)
,p_button_name=>'Enregistrer'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Enregistrer'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(81084912110267872)
,p_branch_name=>'Go To Page 82'
,p_branch_action=>'f?p=&APP_ID.:82:&SESSION.::&DEBUG.:RP::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_COMPUTATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81047959049267831)
,p_name=>'P6_MODE_REG'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(262599776221457816)
,p_use_cache_before_default=>'NO'
,p_item_default=>'1'
,p_prompt=>unistr('Mode R\00E8glement')
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select libelle_mode,ID_MODERGLT from MODE_RGLT',
'order by ID_MODERGLT '))
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '3',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81048323633267831)
,p_name=>'P6_CLIENT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(262599776221457816)
,p_prompt=>'Client'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'CLIENT'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nom_clt as d,',
'       num_clt as r',
'  from client',
' order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81048711044267831)
,p_name=>'P6_REFERENCE_CHEQUE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(262599776221457816)
,p_prompt=>'Reference '
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81049108408267833)
,p_name=>'P6_VERIF'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(262599776221457816)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81049484061267833)
,p_name=>'P6_NUM_PV'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(262599776221457816)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct num_point_vente  from bons b,espace_vente e ',
'where b.num_espace_vente = e.num_espace_vente',
'and num_bon = (select distinct num_bon from details_bon_temp',
'where trim(util_modif) = nvl(v(''app_user''), user));'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81049956817267834)
,p_name=>'P6_CLT'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(262599776221457816)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct num_clt from bons ',
'where num_bon = (select distinct num_bon from details_bon_temp',
'where trim(util_modif) = nvl(v(''app_user''), user));'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81050344394267834)
,p_name=>'P6_NUM_ESPACE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(262599776221457816)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct num_espace_vente from bons ',
'where num_bon = (select distinct num_bon from details_bon_temp',
'where trim(util_modif) = nvl(v(''app_user''), user));'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81050679226267836)
,p_name=>'P6_NBPERS'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(262599776221457816)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81051120632267836)
,p_name=>'P6_TABLE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(262599776221457816)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81051468245267836)
,p_name=>'P6_NUM_BON'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(262599776221457816)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('N\00B0Bon')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct num_bon from details_bon_temp',
'where trim(util_modif) = nvl(v(''app_user''), user);'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81051875844267836)
,p_name=>'P6_CMDE'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(262599776221457816)
,p_prompt=>unistr('N\00B0Cmde')
,p_format_mask=>'999G999G999G999G999G999G990'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select num_table from bons',
'where num_bon = :P6_NUM_BON;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81052294940267837)
,p_name=>'P6_TOTAL'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(262599776221457816)
,p_prompt=>'Total'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct montant_bon from bons ',
'where num_bon = (select distinct num_bon from details_bon_temp',
'where trim(util_modif) = nvl(v(''app_user''), user));'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81052673447267837)
,p_name=>'P6_MT_ARRONDI'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(262599776221457816)
,p_item_default=>'0'
,p_prompt=>unistr('Arrondi \00E0')
,p_format_mask=>'999G999G999G999G999G999G990'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81053101745267837)
,p_name=>'P6_ARRONDI'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(262599776221457816)
,p_prompt=>'Arrondi'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81053469702267839)
,p_name=>'P6_SE'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(262599776221457816)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select code_traitement from bons',
'where num_bon = :P6_NUM_BON;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81053882963267839)
,p_name=>'P6_PWD'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(262599776221457816)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Mot de passe administrateur'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'submit_when_enter_pressed', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81054293500267839)
,p_name=>'P6_TYPE'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(262599776221457816)
,p_prompt=>'Type remise'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:Pourcentage;1,Montant;2'
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81054741602267839)
,p_name=>'P6_VALEUR_REMISE'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(262599776221457816)
,p_prompt=>'Valeur Remise'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_grid_column=>9
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81055070018267840)
,p_name=>'P6_MONTANT_REMISE'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(262599776221457816)
,p_prompt=>'Remise'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_begin_on_new_field=>'N'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81055468772267840)
,p_name=>'P6_LIVREUR'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(262599776221457816)
,p_prompt=>'Livreur'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select trim(nom) || '' '' || trim(prenoms) as nom, matricule from personnel',
'where code_statut_personnel = 8;'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81055911235267840)
,p_name=>'P6_FRAISL'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(262599776221457816)
,p_prompt=>'Frais de livraison'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_grid_column=>7
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81056281797267840)
,p_name=>'P6_NET'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(262599776221457816)
,p_prompt=>unistr('Montant \00E0 payer')
,p_format_mask=>'999G999G999G999G999G999G990'
,p_source=>'P6_TOTAL'
,p_source_type=>'ITEM'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_column=>7
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81056699134267842)
,p_name=>'P6_ENCAISSE'
,p_is_required=>true
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(262599776221457816)
,p_prompt=>unistr('Montant encaiss\00E9')
,p_format_mask=>'999G999G999G999G999G999G990'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_grid_column=>7
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81057099315267842)
,p_name=>'P6_RELIQUAT'
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(262599776221457816)
,p_prompt=>'Reliquat'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_column=>7
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81057539695267844)
,p_name=>'P6_NUM_CAISSE'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(262599776221457816)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.num_caisse',
'from affectation a,personnel p,espace_vente e',
'where a.matricule = p.matricule',
'and a.num_espace_vente = e.num_espace_vente',
'and trim(profil_app) = nvl(v(''app_user''), user);'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81057871495267844)
,p_name=>'P6_NUM_VACATION'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(262599776221457816)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.num_vacation',
'from vacation v,affectation a,personnel p',
'where v.num_espace_vente = a.num_espace_vente',
'and a.matricule = p.matricule',
'and cloture = ''N''',
'and trim(p.profil_app) = trim(nvl(v(''app_user''), user));'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81058312453267844)
,p_name=>'P6_DATE_VAC'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_imp.id(262599776221457816)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.DATEHEURE_DEBUT_VAC ',
'from vacation v,affectation a,personnel p',
'where v.num_espace_vente = a.num_espace_vente',
'and a.matricule = p.matricule',
'and trim(p.profil_app) = trim(nvl(v(''app_user''), user))',
'and cloture=''N'';'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81059136018267845)
,p_name=>'EnregBon'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(81047499626267829)
,p_condition_element=>'P6_RELIQUAT'
,p_triggering_condition_type=>'GREATER_THAN_OR_EQUAL'
,p_triggering_expression=>'0'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81059653601267845)
,p_event_id=>wwv_flow_imp.id(81059136018267845)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Veuillez v&#xE9;rifier les frais de livraisons'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81060097935267847)
,p_event_id=>wwv_flow_imp.id(81059136018267845)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'	enr   number;nbon number;errmess number;mt_deduire number; mt number;etatb number :=1;numclt number:=:p6_clt;cursor c_bon is select * from details_bon_temp  where trim(util_modif) = nvl(v(''app_user''), user) and num_bon in (select num_bon from bons w'
||'here paye=''N'');    r_bon c_bon%rowtype;	cursor c_prd is select * from produits where num_produit = r_bon.num_produit;	r_prd c_prd%rowtype;',
'	cursor c_det is select valeur from detail_produit where num_produit = r_bon.num_produit and code_type_detail = 14; 	r_det c_det%rowtype;cursor c_fiche is select * from fiche_tech  where num_produit = r_bon.num_produit  and qte_fich > 0;     r_fiche '
||'c_fiche%rowtype;',
' begin',
' if nvl(:p6_encaisse,0) >0 and nvl(:p6_net,0) >=0 then',
'	open c_bon;',
'    loop',
'            fetch c_bon into r_bon;',
'            exit when c_bon%notfound;',
'            open c_prd;',
'            fetch c_prd into r_prd;',
'            if c_prd%found then',
'               if r_prd.stockable =''O'' then',
'                     insert into mouvement values (MOUVEMENT_NUM_MVT_SEQ.nextval/*NUM_MVT*/,r_bon.NUM_PRODUIT,15/*CODE_TYPE_MOUVEMENT*/,r_bon.num_bon/*NUM_BON*/,:p6_num_pv/*NUM_POINT_VENTE*/, null/*NUM_LIVR*/, null/*NUM_LIVR_CLT*/,null/*NUM_CMDE*/,nu'
||'ll/*CODE_FOURN*/,r_bon.qte_bon/*QTE*/,:P6_DATE_VAC/*DATE_MVT*/, r_bon.pu_bon/*PU_MVT*/,''1''/*ETAT*/,nvl(v(''app_user''), user)/*CODE_UTILISATEUR*/,sysdate/*DATE_CREATION*/ ,null/*NUM_CARNET*/, to_char(fn_matricule(nvl(v(''app_user''), user)))/*MATRICULE*/'
||',null/*NUM_TICKET*/,2/*CODE_NATURE_MVT*/,null);',
'                    if r_prd.emballage =  ''O'' then',
'                          open c_det;   fetch c_det into r_det;',
'                          if c_det%found then',
'                               insert into mouvement values (MOUVEMENT_NUM_MVT_SEQ.nextval/*NUM_MVT*/,r_det.valeur,16/*CODE_TYPE_MOUVEMENT*/,r_bon.num_bon/*NUM_BON*/,:p6_num_pv/*NUM_POINT_VENTE*/,  null/*NUM_LIVR*/, null/*NUM_LIVR_CLT*/,null/*NUM_CMD'
||'E*/,null/*CODE_FOURN*/,r_bon.qte_bon/*QTE*/,:P6_DATE_VAC/*DATE_MVT*/, r_bon.pu_bon/*PU_MVT*/,''1''/*ETAT*/,nvl(v(''app_user''), user)/*CODE_UTILISATEUR*/,sysdate/*DATE_CREATION*/ ,null/*NUM_CARNET*/,to_char(fn_matricule(nvl(v(''app_user''), user)))/*MATRIC'
||'ULE*/,null/*NUM_TICKET*/,2/*CODE_NATURE_MVT*/,null);',
'                          end if;',
'                          close c_det;',
'                    end if;',
'                end if;',
'            end if;',
'            close c_prd;',
'            open c_fiche;',
'            loop',
'                   fetch c_fiche into r_fiche;',
'                   exit when c_fiche%notfound;',
'                     insert into mouvement values  (MOUVEMENT_NUM_MVT_SEQ.nextval/*NUM_MVT*/,r_fiche.pro_num_produit,15/*CODE_TYPE_MOUVEMENT*/,r_bon.num_bon/*NUM_BON*/,:p6_num_pv/*NUM_POINT_VENTE*/, null/*NUM_LIVR*/, null/*NUM_LIVR_CLT*/,null/*NUM_CM'
||'DE*/,null/*CODE_FOURN*/,r_fiche.qte_fich*r_bon.qte_bon/*QTE*/,:P6_DATE_VAC/*DATE_MVT*/,0/*PU_MVT*/,''1''/*ETAT*/,nvl(v(''app_user''), user)/*CODE_UTILISATEUR*/,sysdate/*DATE_CREATION*/ ,null/*NUM_CARNET*/,to_char(fn_matricule(nvl(v(''app_user''), user)))/*'
||'MATRICULE*/,null/*NUM_TICKET*/,2/*CODE_NATURE_MVT*/,null);',
'            end loop;',
'            close c_fiche;',
'	 end loop;',
'     close c_bon;    ',
'     mt_deduire := (nvl(:p6_arrondi,0)*-1)  + nvl(:p6_montant_remise,0); pr_op_caisse(:p6_net,:p6_num_caisse,:p6_num_vacation,v(''app_user''),:p6_date_vac,:p6_num_bon) ;  if :p6_mode_reg = 2 then etatb := 5; elsif :p6_mode_reg = 3 then etatb := 4; numc'
||'lt:= :p6_client; end if; update bons  set date_creation = sysdate,paye=''O'',montant_bon = montant_bon - nvl(mt_deduire,0),date_liv = sysdate,code_etat_bon =etatb,num_clt = numclt,NUM_CMDE_CLT = :P6_LIVREUR   where num_bon = :p6_num_bon;   update recu '
||'set net = :P6_NET,remise = :p6_montant_remise,arrondi = :p6_arrondi,frais_livraison = :p6_fraisl,montant_recu = :p6_encaisse,reliquat = :p6_reliquat,num_livreur = :p6_livreur,code_mode_reg = :p6_mode_reg, reference_payement = :p6_reference_cheque whe'
||'re num_bon =:p6_num_bon; commit;',
'  end if;',
'  ',
'end ;',
''))
,p_attribute_02=>'P6_NUM_BON,P6_NUM_PV,P6_ARRONDI,P6_MONTANT_REMISE,P6_TOTAL,P6_NET,P6_NUM_CAISSE,P6_NUM_VACATION,P6_DATE_VAC,P6_MODE_REG,P6_CLIENT,P6_CLT,P6_RELIQUAT,P6_REFERENCE_CHEQUE,P6_LIVREUR'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81060644476267847)
,p_event_id=>wwv_flow_imp.id(81059136018267845)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Bon regl&#xE9; avec succ&#xE8;s'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81061097883267848)
,p_event_id=>wwv_flow_imp.id(81059136018267845)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81061654083267848)
,p_event_id=>wwv_flow_imp.id(81059136018267845)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81062059594267848)
,p_name=>'arrondi'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P6_MT_ARRONDI'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81062551071267850)
,p_event_id=>wwv_flow_imp.id(81062059594267848)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P6_ARRONDI'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>' select decode(:p6_mt_arrondi,0,0,(:p6_total-:p6_mt_arrondi)*-1) as mt from dual;'
,p_attribute_07=>'P6_MT_ARRONDI,P6_TOTAL,P6_MONTANT_REMISE'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81063036350267850)
,p_event_id=>wwv_flow_imp.id(81062059594267848)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P6_NET'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'select :p6_total +nvl(:P6_FRAISL,0)+nvl(:p6_arrondi,0)-nvl(:p6_montant_remise,0) as t from dual;'
,p_attribute_07=>'P6_MT_ARRONDI,P6_MONTANT_REMISE,P6_TOTAL,P6_ARRONDI,P6_FRAISL'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81063489040267850)
,p_event_id=>wwv_flow_imp.id(81062059594267848)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P6_ENCAISSE'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'0'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81064050542267850)
,p_event_id=>wwv_flow_imp.id(81062059594267848)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P6_RELIQUAT'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'0'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81064534251267851)
,p_event_id=>wwv_flow_imp.id(81062059594267848)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P6_MONTANT_REMISE'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'select decode(:p6_type,1,:p6_total*:p6_valeur_remise/100,2,:p6_valeur_remise,0)  as t from dual;'
,p_attribute_07=>'P6_TYPE,P6_VALEUR_REMISE,P6_NET,P6_TOTAL'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81064912402267851)
,p_name=>'calculReliquat'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P6_ENCAISSE'
,p_condition_element=>'P6_ENCAISSE'
,p_triggering_condition_type=>'GREATER_THAN_OR_EQUAL'
,p_triggering_expression=>'0'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81065371184267851)
,p_event_id=>wwv_flow_imp.id(81064912402267851)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P6_RELIQUAT'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'select :p6_encaisse - :p6_net from dual;'
,p_attribute_07=>'P6_ENCAISSE,P6_NET'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81065899925267853)
,p_event_id=>wwv_flow_imp.id(81064912402267851)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(81047499626267829)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81066356318267853)
,p_name=>'disable'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P6_NUM_BON'
,p_condition_element=>'P6_NUM_BON'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81066803612267853)
,p_event_id=>wwv_flow_imp.id(81066356318267853)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P6_TYPE,P6_VALEUR_REMISE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81067250780267854)
,p_name=>'showpwd'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P6_TYPE'
,p_condition_element=>'P6_TYPE'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81067746217267854)
,p_event_id=>wwv_flow_imp.id(81067250780267854)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P6_PWD'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81068090009267854)
,p_name=>'New'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P6_VALEUR_REMISE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81068589613267854)
,p_event_id=>wwv_flow_imp.id(81068090009267854)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P6_MONTANT_REMISE'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'select decode(:p6_type,1,:p6_total*:p6_valeur_remise/100,2,:p6_valeur_remise,0)  as t from dual;'
,p_attribute_07=>'P6_VALEUR_REMISE,P6_NET,P6_TYPE,P6_TOTAL'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81069143915267856)
,p_event_id=>wwv_flow_imp.id(81068090009267854)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P6_NET'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'select :p6_total +nvl(:P6_FRAISL,0)+nvl(:p6_arrondi,0)-nvl(:p6_montant_remise,0) as t from dual;'
,p_attribute_07=>'P6_TOTAL,P6_ARRONDI,P6_MONTANT_REMISE,P6_FRAISL'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81069558104267856)
,p_name=>'DisableRemise'
,p_event_sequence=>90
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(262599776221457816)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexbeforerefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81070028092267856)
,p_event_id=>wwv_flow_imp.id(81069558104267856)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P6_TYPE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81070487327267858)
,p_event_id=>wwv_flow_imp.id(81069558104267856)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P6_VALEUR_REMISE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81070961201267858)
,p_event_id=>wwv_flow_imp.id(81069558104267856)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(81047499626267829)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81071376219267858)
,p_name=>'veridpwd'
,p_event_sequence=>100
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P6_PWD'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81071879746267859)
,p_event_id=>wwv_flow_imp.id(81071376219267858)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':p6_verif :=0;',
'if verifpwd(:p6_pwd) = 1 then',
'  :p6_verif := 1;',
'end if;'))
,p_attribute_02=>'P6_PWD,P6_VERIF'
,p_attribute_03=>'P6_VERIF'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81072288934267859)
,p_name=>'verif'
,p_event_sequence=>110
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P6_VERIF'
,p_condition_element=>'P6_VERIF'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81072770465267859)
,p_event_id=>wwv_flow_imp.id(81072288934267859)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P6_TYPE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81073262608267859)
,p_event_id=>wwv_flow_imp.id(81072288934267859)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P6_VALEUR_REMISE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81073707112267861)
,p_name=>'New_1'
,p_event_sequence=>120
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(81047499626267829)
,p_condition_element=>'P6_RELIQUAT'
,p_triggering_condition_type=>'GREATER_THAN'
,p_triggering_expression=>'0'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81074174266267861)
,p_event_id=>wwv_flow_imp.id(81073707112267861)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81074593828267861)
,p_name=>'ESPECES'
,p_event_sequence=>130
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P6_MODE_REG'
,p_condition_element=>'P6_MODE_REG'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81075148689267862)
,p_event_id=>wwv_flow_imp.id(81074593828267861)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P6_CLIENT'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81075486323267862)
,p_event_id=>wwv_flow_imp.id(81074593828267861)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P6_REFERENCE_CHEQUE'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81075945904267864)
,p_name=>'CLIENT'
,p_event_sequence=>140
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P6_MODE_REG'
,p_condition_element=>'P6_MODE_REG'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'3'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81076427508267864)
,p_event_id=>wwv_flow_imp.id(81075945904267864)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P6_REFERENCE_CHEQUE'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81076942733267865)
,p_event_id=>wwv_flow_imp.id(81075945904267864)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P6_CLIENT'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81077331725267865)
,p_name=>'CHEQUE'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P6_MODE_REG'
,p_condition_element=>'P6_MODE_REG'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'2'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81077772393267865)
,p_event_id=>wwv_flow_imp.id(81077331725267865)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P6_CLIENT'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81078327804267867)
,p_event_id=>wwv_flow_imp.id(81077331725267865)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P6_REFERENCE_CHEQUE'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81078737131267867)
,p_name=>'Tmoney'
,p_event_sequence=>160
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P6_MODE_REG'
,p_condition_element=>'P6_MODE_REG'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'4'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81079222624267867)
,p_event_id=>wwv_flow_imp.id(81078737131267867)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P6_CLIENT'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81079713252267869)
,p_event_id=>wwv_flow_imp.id(81078737131267867)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P6_REFERENCE_CHEQUE'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81080077511267869)
,p_name=>'Flooz'
,p_event_sequence=>170
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P6_MODE_REG'
,p_condition_element=>'P6_MODE_REG'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'5'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81080620277267869)
,p_event_id=>wwv_flow_imp.id(81080077511267869)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P6_CLIENT'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81081086456267869)
,p_event_id=>wwv_flow_imp.id(81080077511267869)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P6_REFERENCE_CHEQUE'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81081486698267870)
,p_name=>'liv'
,p_event_sequence=>180
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P6_FRAISL'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81082048816267870)
,p_event_id=>wwv_flow_imp.id(81081486698267870)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P6_NET'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'select :p6_total +nvl(:P6_FRAISL,0)+nvl(:p6_arrondi,0)-nvl(:p6_montant_remise,0) as t from dual;'
,p_attribute_07=>'P6_TOTAL,P6_FRAISL,P6_ARRONDI,P6_MONTANT_REMISE'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81082518533267870)
,p_event_id=>wwv_flow_imp.id(81081486698267870)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P6_RELIQUAT'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'select :p6_encaisse - :p6_net from dual;'
,p_attribute_07=>'P6_ENCAISSE,P6_NET'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81083005171267870)
,p_event_id=>wwv_flow_imp.id(81081486698267870)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P6_ENREG'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'0'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81083403915267872)
,p_name=>'livre'
,p_event_sequence=>190
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P6_SE'
,p_condition_element=>'P6_SE'
,p_triggering_condition_type=>'IN_LIST'
,p_triggering_expression=>'S,E'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81083919220267872)
,p_event_id=>wwv_flow_imp.id(81083403915267872)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P6_LIVREUR,P6_FRAISL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81084426586267872)
,p_event_id=>wwv_flow_imp.id(81083403915267872)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P6_FRAISL,P6_LIVREUR'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(81058688178267845)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Dialogclose'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>81058688178267845
);
wwv_flow_imp.component_end;
end;
/
