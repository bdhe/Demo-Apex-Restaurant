prompt --application/pages/page_00802
begin
--   Manifest
--     PAGE: 00802
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>802
,p_name=>'Sortie de stock'
,p_alias=>'SORTIE-DE-STOCK'
,p_step_title=>'Sortie de stock'
,p_allow_duplicate_submissions=>'N'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Scroll Results Only in Side Column */',
'.t-Body-side {',
'    display: flex;',
'    flex-direction: column;',
'    overflow: hidden;',
'}',
'.search-results {',
'    flex: 1;',
'    overflow: auto;',
'}',
'/* Format Search Region */',
'.search-region {',
'    border-bottom: 1px solid rgba(0,0,0,.1);',
'    flex-shrink: 0;',
'}'))
,p_step_template=>2526643373347724467
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(84039914721143751)
,p_plug_name=>'Sortie de stock'
,p_region_template_options=>'#DEFAULT#:t-HeroRegion--hideIcon'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2674017834225413037
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_query_type=>'SQL'
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(84041138489143753)
,p_plug_name=>'Rechercher'
,p_region_css_classes=>'search-region padding-md'
,p_region_template_options=>'#DEFAULT#:t-Form--stretchInputs'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_02'
,p_query_type=>'SQL'
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(84041937150143756)
,p_name=>unistr('Enregistrements ma\00EEtre')
,p_template=>3371237801798025892
,p_display_sequence=>20
,p_region_css_classes=>'search-results'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'t-MediaList--showDesc:t-MediaList--stack'
,p_display_point=>'REGION_POSITION_02'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "NUM_SORTIE",',
'    null link_class,',
'    apex_page.get_url(p_items => ''P802_NUM_SORTIE'', p_values => "NUM_SORTIE") link,',
'    null icon_class,',
'    null link_attr,',
'    null icon_color_class,',
'    case when nvl(:P802_NUM_SORTIE,''0'') = "NUM_SORTIE"',
'      then ''is-active'' ',
'      else '' ''',
'    end list_class,',
'    substr("LIBELLE", 1, 50)||( case when length("LIBELLE") > 50 then ''...'' end ) list_title,',
'    substr("OBSERVATIONS", 1, 50)||( case when length("OBSERVATIONS") > 50 then ''...'' end ) list_text,',
'    null list_badge',
'from "SORTIE_STOCK" x',
'where (:P802_SEARCH is null',
'        or upper(x."LIBELLE") like ''%''||upper(:P802_SEARCH)||''%''',
'        or upper(x."OBSERVATIONS") like ''%''||upper(:P802_SEARCH)||''%''',
'    )',
'and code_etat_sortie = 0',
'order by "LIBELLE"'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P802_SEARCH'
,p_lazy_loading=>false
,p_query_row_template=>2093604263195414824
,p_query_num_rows=>1000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>unistr('<div class="u-tC">Aucune donn\00E9e n''a \00E9t\00E9 trouv\00E9e.</div>')
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84042633270143759)
,p_query_column_id=>1
,p_column_alias=>'NUM_SORTIE'
,p_column_display_sequence=>1
,p_column_heading=>'NUM_SORTIE'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84043021097143761)
,p_query_column_id=>2
,p_column_alias=>'LINK_CLASS'
,p_column_display_sequence=>2
,p_column_heading=>'LINK_CLASS'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84043377189143761)
,p_query_column_id=>3
,p_column_alias=>'LINK'
,p_column_display_sequence=>3
,p_column_heading=>'LINK'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84043779068143762)
,p_query_column_id=>4
,p_column_alias=>'ICON_CLASS'
,p_column_display_sequence=>4
,p_column_heading=>'ICON_CLASS'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84044197060143762)
,p_query_column_id=>5
,p_column_alias=>'LINK_ATTR'
,p_column_display_sequence=>5
,p_column_heading=>'LINK_ATTR'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84044607264143762)
,p_query_column_id=>6
,p_column_alias=>'ICON_COLOR_CLASS'
,p_column_display_sequence=>6
,p_column_heading=>'ICON_COLOR_CLASS'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84045038663143764)
,p_query_column_id=>7
,p_column_alias=>'LIST_CLASS'
,p_column_display_sequence=>7
,p_column_heading=>'LIST_CLASS'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84045427049143764)
,p_query_column_id=>8
,p_column_alias=>'LIST_TITLE'
,p_column_display_sequence=>8
,p_column_heading=>'LIST_TITLE'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84045796282143764)
,p_query_column_id=>9
,p_column_alias=>'LIST_TEXT'
,p_column_display_sequence=>9
,p_column_heading=>'LIST_TEXT'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84046224482143765)
,p_query_column_id=>10
,p_column_alias=>'LIST_BADGE'
,p_column_display_sequence=>10
,p_column_heading=>'LIST_BADGE'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(84046636688143772)
,p_name=>'Sortie Stock'
,p_template=>4072358936313175081
,p_display_sequence=>10
,p_region_css_classes=>'js-master-region'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-AVPList--leftAligned'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'TABLE'
,p_query_table=>'SORTIE_STOCK'
,p_query_where=>'"NUM_SORTIE" = :P802_NUM_SORTIE'
,p_include_rowid_column=>false
,p_display_when_condition=>'P802_NUM_SORTIE'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2100515439059797523
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>unistr('Aucun enregistrement s\00E9lectionn\00E9')
,p_query_row_count_max=>500
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84047264625143773)
,p_query_column_id=>1
,p_column_alias=>'NUM_SORTIE'
,p_column_display_sequence=>1
,p_column_heading=>'Num Sortie'
,p_heading_alignment=>'LEFT'
,p_hidden_column=>'Y'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "SORTIE_STOCK"',
'where "NUM_SORTIE" is not null',
'and "NUM_SORTIE" = :P802_NUM_SORTIE'))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84047705757143773)
,p_query_column_id=>2
,p_column_alias=>'LIBELLE'
,p_column_display_sequence=>2
,p_column_heading=>'Libelle'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "SORTIE_STOCK"',
'where "LIBELLE" is not null',
'and "NUM_SORTIE" = :P802_NUM_SORTIE'))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84048140997143775)
,p_query_column_id=>3
,p_column_alias=>'CODE_TYPE_SORTIE'
,p_column_display_sequence=>3
,p_column_heading=>'Type Sortie'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "SORTIE_STOCK"',
'where "CODE_TYPE_SORTIE" is not null',
'and "NUM_SORTIE" = :P802_NUM_SORTIE'))
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(83835165315603345)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84048509549143775)
,p_query_column_id=>4
,p_column_alias=>'OBSERVATIONS'
,p_column_display_sequence=>4
,p_column_heading=>'Observations'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "SORTIE_STOCK"',
'where "OBSERVATIONS" is not null',
'and "NUM_SORTIE" = :P802_NUM_SORTIE'))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84048898399143775)
,p_query_column_id=>5
,p_column_alias=>'DATE_SORTIE'
,p_column_display_sequence=>5
,p_column_heading=>'Date Sortie'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "SORTIE_STOCK"',
'where "DATE_SORTIE" is not null',
'and "NUM_SORTIE" = :P802_NUM_SORTIE'))
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84049357092143776)
,p_query_column_id=>6
,p_column_alias=>'NUM_POINT_VENTE'
,p_column_display_sequence=>6
,p_column_heading=>'Point de vente'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "SORTIE_STOCK"',
'where "NUM_POINT_VENTE" is not null',
'and "NUM_SORTIE" = :P802_NUM_SORTIE'))
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(81104181522273040)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84049740006143776)
,p_query_column_id=>7
,p_column_alias=>'CODE_UTLISATEUR'
,p_column_display_sequence=>7
,p_column_heading=>'Utlisateur'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "SORTIE_STOCK"',
'where "CODE_UTLISATEUR" is not null',
'and "NUM_SORTIE" = :P802_NUM_SORTIE'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84050144224143776)
,p_query_column_id=>8
,p_column_alias=>'DATE_ENREG'
,p_column_display_sequence=>8
,p_column_heading=>'Date saisie'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "SORTIE_STOCK"',
'where "DATE_ENREG" is not null',
'and "NUM_SORTIE" = :P802_NUM_SORTIE'))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84050518019143778)
,p_query_column_id=>9
,p_column_alias=>'CODE_ETAT_SORTIE'
,p_column_display_sequence=>9
,p_column_heading=>'Etat Sortie'
,p_heading_alignment=>'LEFT'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "SORTIE_STOCK"',
'where "CODE_ETAT_SORTIE" is not null',
'and "NUM_SORTIE" = :P802_NUM_SORTIE'))
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>unistr('STATIC:Non valid\00E9e;0,Valis\00E9e;1')
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84050901018143778)
,p_query_column_id=>10
,p_column_alias=>'CODE_UTILISATEUR_VALIDE'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_display_when_cond_type=>'EXISTS'
,p_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select 1 from "SORTIE_STOCK"',
'where "CODE_UTILISATEUR_VALIDE" is not null',
'and "NUM_SORTIE" = :P802_NUM_SORTIE'))
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(84057999446143795)
,p_plug_name=>unistr('S\00E9lecteur d''affichage de r\00E9gion')
,p_region_css_classes=>'js-detail-rds'
,p_region_template_options=>'#DEFAULT#:margin-bottom-md'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source_type=>'NATIVE_DISPLAY_SELECTOR'
,p_plug_query_num_rows=>15
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P802_NUM_SORTIE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_region_icons', 'N',
  'include_show_all', 'Y',
  'rds_mode', 'STANDARD',
  'remember_selection', 'NO')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(84058388947143797)
,p_name=>'Sortie Stock Detail'
,p_template=>4072358936313175081
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_css_classes=>'js-detail-region'
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'t-Report--stretch:#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight:t-Report--inline'
,p_new_grid_row=>false
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'TABLE'
,p_query_table=>'SORTIE_STOCK_DETAIL'
,p_query_where=>'"NUM_SORTIE" = :P802_NUM_SORTIE'
,p_include_rowid_column=>true
,p_display_when_condition=>'P802_NUM_SORTIE'
,p_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_no_data_found=>unistr('Aucune donn\00E9e n''a \00E9t\00E9 trouv\00E9e.')
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_query_row_count_max=>5000
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84059236300143801)
,p_query_column_id=>1
,p_column_alias=>'ROWID'
,p_column_display_sequence=>1
,p_column_heading=>'<span class="u-VisuallyHidden">Modifier</span>'
,p_column_link=>'f?p=&APP_ID.:804:&APP_SESSION.::&DEBUG.:RP:P804_ROWID:#ROWID#'
,p_column_linktext=>'<span aria-label="Modifier"><span class="fa fa-edit" aria-hidden="true" title="Modifier"></span></span>'
,p_heading_alignment=>'LEFT'
,p_report_column_width=>32
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84059612696143803)
,p_query_column_id=>2
,p_column_alias=>'NUM_DET_SORTIE'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84059976036143803)
,p_query_column_id=>3
,p_column_alias=>'NUM_SORTIE'
,p_column_display_sequence=>3
,p_column_heading=>'Num Sortie'
,p_heading_alignment=>'LEFT'
,p_hidden_column=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84060378201143803)
,p_query_column_id=>4
,p_column_alias=>'NUM_PRODUIT'
,p_column_display_sequence=>4
,p_column_heading=>'Produit'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(81557789633430934)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84060811858143804)
,p_query_column_id=>5
,p_column_alias=>'QTE'
,p_column_display_sequence=>5
,p_column_heading=>unistr('Qt\00E9')
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84061217842143804)
,p_query_column_id=>6
,p_column_alias=>'CODE_UTLISATEUR'
,p_column_display_sequence=>6
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84061629798143804)
,p_query_column_id=>7
,p_column_alias=>'DATE_ENREG'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84061997049143806)
,p_query_column_id=>8
,p_column_alias=>'UNITE_MESURE'
,p_column_display_sequence=>8
,p_column_heading=>'Unite Mesure'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(84062376534143806)
,p_query_column_id=>9
,p_column_alias=>'TYPE_PRODUIT'
,p_column_display_sequence=>9
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(84079557725143826)
,p_plug_name=>unistr('Aucun enregistrement s\00E9lectionn\00E9')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>50
,p_plug_source=>unistr('Aucun enregistrement s\00E9lectionn\00E9')
,p_plug_query_num_rows=>15
,p_plug_display_condition_type=>'ITEM_IS_NULL'
,p_plug_display_when_condition=>'P802_NUM_SORTIE'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(84066206621143812)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(84058388947143797)
,p_button_name=>'POP_SORTIE_STOCK_DETAIL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Ajouter Sortie Stock Detail'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:804:&APP_SESSION.::&DEBUG.:RP,804:P804_NUM_SORTIE:&P802_NUM_SORTIE.'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(84079976140143828)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(84046636688143772)
,p_button_name=>'EDIT'
,p_button_static_id=>'edit_master_btn'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Modifier'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:803:&APP_SESSION.::&DEBUG.:RP,803:P803_NUM_SORTIE:&P802_NUM_SORTIE.'
,p_icon_css_classes=>'fa-pencil-square-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(84040430982143751)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(84039914721143751)
,p_button_name=>'RESET'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--noUI:t-Button--iconLeft:t-Button--gapRight'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>unistr('R\00E9initialiser')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:802:&APP_SESSION.:RESET:&DEBUG.:RP,802::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(84040795261143753)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(84039914721143751)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Cr\00E9er')
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:803:&APP_SESSION.::&DEBUG.:RP,803::'
,p_icon_css_classes=>'fa-plus'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(84041473727143754)
,p_name=>'P802_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(84041138489143753)
,p_prompt=>'Rechercher'
,p_placeholder=>'Rechercher...'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>2040785906935475274
,p_item_icon_css_classes=>'fa-search'
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--large:t-Form-fieldContainer--postTextBlock'
,p_lov_display_extra=>'NO'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'send_on_page_submit', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(84057623273143795)
,p_name=>'P802_NUM_SORTIE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(84046636688143772)
,p_display_as=>'NATIVE_HIDDEN'
,p_lov_display_extra=>'NO'
,p_protection_level=>'S'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(84080328324143828)
,p_name=>unistr('Bo\00EEte de dialogue ferm\00E9e')
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(84046636688143772)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(84080877649143828)
,p_event_id=>wwv_flow_imp.id(84080328324143828)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(84046636688143772)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(84081413706143828)
,p_event_id=>wwv_flow_imp.id(84080328324143828)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.message.showPageSuccess(''Sortie Stock ligne(s) mise(s) \u00E0 jour.'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(84058519518143797)
,p_name=>unistr('Bo\00EEte de dialogue ferm\00E9e')
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(84058388947143797)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(84066939043143812)
,p_event_id=>wwv_flow_imp.id(84058519518143797)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(84058388947143797)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(84067389022143814)
,p_event_id=>wwv_flow_imp.id(84058519518143797)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.message.showPageSuccess(''Sortie Stock Detail ligne(s) mise(s) \u00E0 jour.'');'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(84080437732143828)
,p_name=>'Effectuez la recherche'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P802_SEARCH'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>'this.browserEvent.which === apex.jQuery.ui.keyCode.ENTER'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keypress'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(84082199561143829)
,p_event_id=>wwv_flow_imp.id(84080437732143828)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(84041937150143756)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(84082718734143829)
,p_event_id=>wwv_flow_imp.id(84080437732143828)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CANCEL_EVENT'
);
wwv_flow_imp.component_end;
end;
/
