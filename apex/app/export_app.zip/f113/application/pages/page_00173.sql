prompt --application/pages/page_00173
begin
--   Manifest
--     PAGE: 00173
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>173
,p_name=>'fiche inventaire vierge'
,p_alias=>'FICHE-INVENTAIRE-VIERGE'
,p_step_title=>'fiche inventaire vierge'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(282483617339161112)
,p_plug_name=>'Editiion fiche inventaire vierge'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>4
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(86178715406622931)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(282483617339161112)
,p_button_name=>'Editer_1'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Editer'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:174:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(86179442110622933)
,p_name=>'param'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P173_DATE_DEBUT,P173_DATE_FIN,P173_NUM_PV'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86179870635622934)
,p_event_id=>wwv_flow_imp.id(86179442110622933)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'nn varchar2(10);',
'nn1 varchar2(10);',
'begin',
'    if :p173_attrib not in (1,3)  then',
'       :p173_date_debut := sysdate;',
'       :p173_date_fin := sysdate;',
'    end if;',
'    nn := replace(:p173_date_debut,''/'');',
'    nn1 := replace(:p173_date_fin,''/'');',
'   PR_JVENTES(2,nn,nn1,:P173_NUM_PV);',
' ',
'    commit;',
'end;'))
,p_attribute_02=>'P173_DATE_DEBUT,P173_DATE_FIN,P173_ATTRIB,P173_NUM_PV'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(86180281457622934)
,p_name=>'attrib'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P173_ATTRIB'
,p_condition_element=>'P173_ATTRIB'
,p_triggering_condition_type=>'NOT_IN_LIST'
,p_triggering_expression=>'3,27'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86180856091622934)
,p_event_id=>wwv_flow_imp.id(86180281457622934)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  ',
'declare',
'',
'cursor c_pv is select num_point_vente from personnel p,affectation f',
'where p.matricule = f.matricule',
'and trim(profil_app)= v(''app_user'');',
'',
'r_pv c_pv%rowtype;',
'',
'begin',
'    -- :p173_date_debut := sysdate;',
'   --  :p173_date_fin := sysdate;',
'     open c_pv;',
'     fetch c_pv into r_pv;',
'     if c_pv%found then',
'         :P173_NUM_PV:= r_pv.num_point_vente;',
'         ',
'     end if;',
'     close c_pv;',
'',
'  end;'))
,p_attribute_02=>'P173_ATTRIB,P173_NUM_PV'
,p_attribute_03=>'P173_NUM_PV'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86181286021622934)
,p_event_id=>wwv_flow_imp.id(86180281457622934)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P173_DATE_DEBUT,P173_DATE_FIN,P173_NUM_PV'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(86181718535622936)
,p_name=>'PARAMFACT'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P173_NUM_FACTURE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86182186453622936)
,p_event_id=>wwv_flow_imp.id(86181718535622936)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update parametres_etats set valeur_num = :P173_NUM_FACTURE',
'where trim(nom_parametre) = ''numero_facture''',
'and code_etat = 3;',
'',
'commit;'))
,p_attribute_02=>'P173_NUM_FACTURE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(86182609226622936)
,p_name=>'num_invt'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P173_NUM_INVENT'
,p_condition_element=>'P173_NUM_INVENT'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86183084863622936)
,p_event_id=>wwv_flow_imp.id(86182609226622936)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update parametres_etats set valeur_num = :P173_NUM_INVENT',
'where  code_etat = 4;',
'commit;'))
,p_attribute_02=>'P173_NUM_INVENT'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(86183494951622937)
,p_name=>'paramcommande'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P173_NUM_CMDE'
,p_condition_element=>'P173_NUM_CMDE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86183963565622937)
,p_event_id=>wwv_flow_imp.id(86183494951622937)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update parametres_etats set valeur_num = :P173_NUM_CMDE',
'where trim(nom_parametre) = ''num_cmde''',
'and code_etat = 5;',
'',
'commit;'))
,p_attribute_02=>'P173_NUM_CMDE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(86184421977622937)
,p_name=>'btton'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P173_NUM_PV'
,p_condition_element=>'P173_NUM_PV'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(86179153106622931)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'attrib'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'code_stat number;',
'',
'begin',
'    select code_statut_personnel into code_stat  from personnel',
'    where trim(profil_app) =v(''app_user'');',
'    if code_stat != 3 then',
'         update parametres_etats set valeur_date = sysdate',
'        where trim(nom_parametre) = ''date_debut''',
'        and code_etat = 2;',
'',
'        update parametres_etats set valeur_date = sysdate',
'        where trim(nom_parametre) = ''date_fin''',
'        and code_etat = 2;',
'   end if;',
'',
'commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>86179153106622931
);
wwv_flow_imp.component_end;
end;
/
