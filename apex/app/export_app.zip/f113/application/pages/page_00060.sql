prompt --application/pages/page_00060
begin
--   Manifest
--     PAGE: 00060
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>60
,p_name=>unistr('Stock g\00E9n\00E9ral')
,p_alias=>unistr('STOCK-G\00C9N\00C9RAL')
,p_step_title=>unistr('Stock g\00E9n\00E9ral')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(268167674011794768)
,p_plug_name=>unistr('Stock g\00E9n\00E9ral')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>5
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(268308609943532472)
,p_plug_name=>unistr('Stock g\00E9n\00E9ral')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>6
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select p.num_produit,f.code_famille,p.code_type_produit,p.designation_produit,fn_stockprdpv(num_produit,:P60_NUM_PV,:P60_DATE) qtestock,unite_mesure',
'from produits p, type_produit t,famille_produit f',
'where p.code_type_produit =t.code_type_produit',
'and f.code_famille = t.code_famille',
'and stockable =''O''',
'and t.code_type_produit = nvl(:P60_TYPE_PRODUIT,t.code_type_produit)',
'and f.code_famille = nvl(:P60_FAMILLE ,f.code_famille);',
''))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P60_NUM_PV,P60_TYPE_PRODUIT,P60_FAMILLE,P60_DATE'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(204494053846408688)
,p_name=>'UNITE_MESURE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UNITE_MESURE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Unite Mesure'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>40
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(268167213392794763)
,p_name=>'NUM_PRODUIT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NUM_PRODUIT'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(268167357378794764)
,p_name=>'CODE_FAMILLE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CODE_FAMILLE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>20
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(268167432946794765)
,p_name=>'CODE_TYPE_PRODUIT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'CODE_TYPE_PRODUIT'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(268167475182794766)
,p_name=>'DESIGNATION_PRODUIT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DESIGNATION_PRODUIT'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Designation Produit'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>true
,p_max_length=>280
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(268317224023648824)
,p_name=>'QTESTOCK'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QTESTOCK'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Qtestock'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>60
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
,p_format_mask=>'999G999G999G999G990D000'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(268167145557794762)
,p_internal_uid=>212994585102121793
,p_is_editable=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_show_nulls_as=>'-'
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>null
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(268312551753606953)
,p_interactive_grid_id=>wwv_flow_imp.id(268167145557794762)
,p_static_id=>'252151'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(268312629810606953)
,p_report_id=>wwv_flow_imp.id(268312551753606953)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(204553360515699077)
,p_view_id=>wwv_flow_imp.id(268312629810606953)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(204494053846408688)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(268313136199606955)
,p_view_id=>wwv_flow_imp.id(268312629810606953)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(268167213392794763)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(268313647488606957)
,p_view_id=>wwv_flow_imp.id(268312629810606953)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(268167357378794764)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(268314102275606958)
,p_view_id=>wwv_flow_imp.id(268312629810606953)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(268167432946794765)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(268314569958606960)
,p_view_id=>wwv_flow_imp.id(268312629810606953)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(268167475182794766)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(268326353382776555)
,p_view_id=>wwv_flow_imp.id(268312629810606953)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(268317224023648824)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85682472800069878)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(268167674011794768)
,p_button_name=>'Quitter'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Quitter'
,p_button_position=>'COPY'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85682869920069879)
,p_name=>'P60_PROFIL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(268167674011794768)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select code_statut_personnel  from personnel',
'    where trim(profil_app) =v(''app_user'');'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85683333310069879)
,p_name=>'P60_NUM_PV'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(268167674011794768)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Point de vente'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'POINT_VENTE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nom_point_vente as d,',
'       num_point_vente as r',
'  from point_vente where actif=''O''',
'order by 1'))
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85683715286069879)
,p_name=>'P60_DATE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(268167674011794768)
,p_use_cache_before_default=>'NO'
,p_item_default=>'select sysdate from dual;'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Date stock'
,p_format_mask=>'DD/MM/YYYY'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'appearance_and_behavior', 'MONTH-PICKER:YEAR-PICKER',
  'days_outside_month', 'VISIBLE',
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_on', 'FOCUS',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85684123322069881)
,p_name=>'P60_FAMILLE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(268167674011794768)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Famille produit'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'FAMILLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select libelle_famille as d,',
'       code_famille as r',
'  from famille_produit ',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Toutes les familles'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85684477788069881)
,p_name=>'P60_TYPE_PRODUIT'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(268167674011794768)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Type Produit'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TYPE_PRODUIT_STOCK'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select libelle_type_produit as d,',
'       code_type_produit as r',
'  from type_produit',
'  where code_type_produit in (select code_type_produit from produits where STOCKABLE =''O'')',
' order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Tous les type de produit'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85688277084069906)
,p_name=>'AffStock'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P60_NUM_PV,P60_TYPE_PRODUIT,P60_FAMILLE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85688671241069908)
,p_event_id=>wwv_flow_imp.id(85688277084069906)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(268308609943532472)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85689106623069908)
,p_name=>'date'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P60_DATE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85689627029069909)
,p_event_id=>wwv_flow_imp.id(85689106623069908)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(268308609943532472)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85689973873069909)
,p_name=>'APP'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P60_PROFIL'
,p_condition_element=>'P60_PROFIL'
,p_triggering_condition_type=>'NOT_EQUALS'
,p_triggering_expression=>'3'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85690521589069911)
,p_event_id=>wwv_flow_imp.id(85689973873069909)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_pv is select num_point_vente from personnel p,affectation f',
'where p.matricule = f.matricule',
'and trim(profil_app)= v(''app_user'');',
'',
'r_pv c_pv%rowtype;',
'',
'begin',
' ',
'     open c_pv;',
'     fetch c_pv into r_pv;',
'     if c_pv%found then',
'         :P60_NUM_PV:= r_pv.num_point_vente;',
'         ',
'     end if;',
'     close c_pv;',
'',
'  end;'))
,p_attribute_02=>'P60_NUM_PV'
,p_attribute_03=>'P60_NUM_PV'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85691045813069911)
,p_event_id=>wwv_flow_imp.id(85689973873069909)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P60_NUM_PV'
);
wwv_flow_imp.component_end;
end;
/
