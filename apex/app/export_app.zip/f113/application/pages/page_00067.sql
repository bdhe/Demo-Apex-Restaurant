prompt --application/pages/page_00067
begin
--   Manifest
--     PAGE: 00067
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>67
,p_name=>'Vacation'
,p_alias=>'VACATION'
,p_page_mode=>'MODAL'
,p_step_title=>'Vacation'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(266480098474443387)
,p_plug_name=>'Caisse'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(266509464349251226)
,p_name=>'Vacation actuelle'
,p_template=>4072358936313175081
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_grid_column_span=>6
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'TABLE'
,p_query_table=>'LOG_VACATION'
,p_query_where=>'num_vacation = :P67_NUM_VAC'
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'DATE_CONNEXION desc'
,p_include_rowid_column=>false
,p_header=>'<div style="height:200px;overflow:scroll;scrollbar-width:none;"> '
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P67_NUM_VAC'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83547964370648384)
,p_query_column_id=>1
,p_column_alias=>'NUM_VACATION'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83548368168648384)
,p_query_column_id=>2
,p_column_alias=>'CODE_UTILISATEUR'
,p_column_display_sequence=>2
,p_column_heading=>'Caissier(e)'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83548857084648386)
,p_query_column_id=>3
,p_column_alias=>'DATE_CONNEXION'
,p_column_display_sequence=>3
,p_column_heading=>'Heure'
,p_column_format=>'HH24:MI'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83549196360648386)
,p_query_column_id=>4
,p_column_alias=>'DATE_DECONNEXION'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(266510380300251236)
,p_name=>unistr('Vacations non clot\00FBr\00E9es')
,p_template=>4072358936313175081
,p_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  num_vacation id,num_vacation,DATEHEURE_DEBUT_VAC,DATEHEURE_FIN_VAC,MONTANT_ENCAISSE',
'from vacation',
'where trim(cloture) =''N''',
'and to_char(DATEHEURE_DEBUT_VAC,''ddmmyyyy'') != to_char(sysdate,''ddmmyyyy'')',
'and num_vacation != :p67_num_vac',
'and num_point_vente = :p67_num_pv',
'and num_espace_vente = :p67_num_espace',
'and num_caisse = :p67_num_caisse;',
''))
,p_header=>'<div style="height:200px;overflow:scroll;scrollbar-width: none;"> '
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P67_USER,P67_NUM_PV,P67_NUM_ESPACE,P67_NUM_CAISSE,P67_NUM_VAC'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83551908170648390)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>5
,p_column_heading=>'Id'
,p_column_link=>'f?p=&APP_ID.:86:&SESSION.::&DEBUG.:RP:P86_NUM_VACATION:#ID#'
,p_column_linktext=>'<span class="t-Icon fa fa fa-toggle-right affiche-note" aria-hidden="true"></span>'
,p_column_link_attr=>unistr('id=''#ID#'' class="affvacation t-Button t-Button--danger t-Button--simple t-Button--small" title="Cl\00F4turer vacationN\00B0  : #NUM_VACATION#"')
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83552303568648390)
,p_query_column_id=>2
,p_column_alias=>'NUM_VACATION'
,p_column_display_sequence=>1
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83552728007648392)
,p_query_column_id=>3
,p_column_alias=>'DATEHEURE_DEBUT_VAC'
,p_column_display_sequence=>2
,p_column_heading=>'Dateheure Debut Vac'
,p_column_format=>'DD-MON-YYYY HH24:MI:SS'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83553138524648392)
,p_query_column_id=>4
,p_column_alias=>'DATEHEURE_FIN_VAC'
,p_column_display_sequence=>3
,p_column_heading=>'Dateheure Fin Vac'
,p_column_format=>'DD-MON-YYYY HH24:MI:SS'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83553494499648392)
,p_query_column_id=>5
,p_column_alias=>'MONTANT_ENCAISSE'
,p_column_display_sequence=>4
,p_column_heading=>'Montant Encaisse'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(83544095947648361)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(266480098474443387)
,p_button_name=>'vacation'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Nouvelle vacation'
,p_button_position=>'COPY'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(83544560093648361)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(266480098474443387)
,p_button_name=>'Valider'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Valider'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:178:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(83544954015648362)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(266480098474443387)
,p_button_name=>'Quitter'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Quitter'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83545279103648369)
,p_name=>'P67_USER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(266480098474443387)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select matricule nom ',
'from personnel p',
'where trim(profil_app) = nvl(v(''app_user''), user);'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83545665993648372)
,p_name=>'P67_NUM_PV'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(266480098474443387)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.num_point_vente',
'from affectation a,personnel p,espace_vente e',
'where a.matricule = p.matricule',
'and a.num_espace_vente = e.num_espace_vente',
'and trim(profil_app) = nvl(v(''app_user''), user);'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83546076743648372)
,p_name=>'P67_NUM_ESPACE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(266480098474443387)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.num_espace_vente',
'from affectation a,personnel p,espace_vente e',
'where a.matricule = p.matricule',
'and a.num_espace_vente = e.num_espace_vente',
'and trim(profil_app) = nvl(v(''app_user''), user);'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83546511351648373)
,p_name=>'P67_NUM_CAISSE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(266480098474443387)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct num_caisse from affectation a,caisse c,personnel p',
'where a.matricule = c.matricule',
'and c.matricule = p.matricule',
'and trim(profil_app) = nvl(v(''app_user''), user);'))
,p_item_default_type=>'SQL_QUERY'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.num_caisse',
'from affectation a,personnel p,espace_vente e',
'where a.matricule = p.matricule',
'and a.num_espace_vente = e.num_espace_vente',
'and trim(profil_app) = nvl(v(''app_user''), user);'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83546893295648373)
,p_name=>'P67_ENCAISSE'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(266480098474443387)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(MONTANT_ENCAISSE,''999g999g999'') as mt',
'from vacation',
'where num_point_vente = :p67_num_pv',
'and num_espace_vente = :p67_num_espace',
'and num_caisse = :p67_num_caisse',
'and cloture = ''N'';'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Encaisse'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83547265574648375)
,p_name=>'P67_NUM_VAC'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(266480098474443387)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select num_vacation',
'from vacation',
'where  num_point_vente = :p67_num_pv',
'and num_espace_vente = :p67_num_espace',
'and num_caisse = :p67_num_caisse',
'and cloture = ''N'';'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83549641575648386)
,p_name=>'P67_DATE_DEBUT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(266509464349251226)
,p_prompt=>'Date Debut'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(DATEHEURE_DEBUT_VAC,''dd/mm/yyyy hh24:mi'') as date_debut',
'from vacation',
'where  num_point_vente = :p67_num_pv',
'and num_espace_vente = :p67_num_espace',
'and num_caisse = :p67_num_caisse',
'and cloture=''N'';'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>4
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83549994155648387)
,p_name=>'P67_ENC'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(266509464349251226)
,p_prompt=>'Encaisse'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(MONTANT_ENCAISSE,''999g999g999'') as mt',
'from vacation',
'where num_point_vente = :p67_num_pv',
'and num_espace_vente = :p67_num_espace',
'and num_caisse = :p67_num_caisse',
'and cloture = ''N'';'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83550450570648387)
,p_name=>'P67_MATRICULE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(266509464349251226)
,p_prompt=>'Ouverte par'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nom ',
'from vacation v,personnel p',
'where  v.matricule = p.matricule',
'and num_point_vente = :p67_num_pv',
'and num_espace_vente = :p67_num_espace',
'and num_caisse = :p67_num_caisse',
'and cloture = ''N'';'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83550796879648387)
,p_name=>'P67_CLOTURE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(266509464349251226)
,p_prompt=>unistr('Clotur\00E9')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select decode(CLOTURE,''O'',''Oui'',''N'',''Non'') as cloture',
'from vacation',
'where num_point_vente = :p67_num_pv',
'and num_espace_vente = :p67_num_espace',
'and num_caisse = :p67_num_caisse',
'and cloture = ''N'';'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83551255173648387)
,p_name=>'P67_DATE_FIN'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(266509464349251226)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(DATEHEURE_FIN_VAC,''dd/mm/yyyy hh24:mi'') as date_debut',
'from vacation',
'where num_point_vente = :p67_num_pv',
'and num_espace_vente = :p67_num_espace',
'and num_caisse = :p67_num_caisse',
'and cloture = ''N'';'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83553923845648394)
,p_name=>'P67_NUM_VACATION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(266510380300251236)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83554339692648436)
,p_name=>'CreeVAcation'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(83544095947648361)
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83554724373648437)
,p_event_id=>wwv_flow_imp.id(83554339692648436)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Etes vous s&#xFB;r de vouloir cr&#xE9;er une nouvelle vacation?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83555236593648437)
,p_event_id=>wwv_flow_imp.id(83554339692648436)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'numvac number;',
'begin',
'    select VACATION_NUM_VACATION_SEQ.nextval into numvac from dual;',
'    insert into vacation (NUM_VACATION  ,NUM_POINT_VENTE ,NUM_CAISSE ,NUM_EVENEMENT,MATRICULE,ETAT_VACATION,DATEHEURE_DEBUT_VAC,          ',
'    DATEHEURE_FIN_VAC,MONTANT_TOTAL_BONS,MONTANT_ENCAISSE ,ECART_VACATION,CLOTURE ,SOLDE_INITIAL_CAISSE ,CODE_UTILISATEUR,DATE_CREATION ,NUM_ESPACE_VENTE) ',
'    values(numvac,:p67_num_pv,:p67_num_caisse,null,:p67_user,0,sysdate,null,0,:p67_encaisse,0,''N'',:p67_encaisse,nvl(v(''app_user''), user),',
'           sysdate,:p67_num_espace);',
'    commit;',
'    :p67_num_vac := numvac;',
'end;'))
,p_attribute_02=>'P67_USER,P67_NUM_PV,P67_NUM_ESPACE,P67_ENCAISSE,P67_NUM_VAC,P67_NUM_CAISSE'
,p_attribute_03=>'P67_USER,P67_NUM_PV,P67_NUM_ESPACE,P67_ENCAISSE,P67_NUM_VAC'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83555717054648437)
,p_event_id=>wwv_flow_imp.id(83554339692648436)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P67_NUM_VACATION'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83556246051648439)
,p_event_id=>wwv_flow_imp.id(83554339692648436)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(266509464349251226)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83556704960648439)
,p_event_id=>wwv_flow_imp.id(83554339692648436)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P67_DATE_DEBUT'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83557096063648439)
,p_name=>'GestBoutons'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P67_NUM_VAC'
,p_condition_element=>'P67_NUM_VAC'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83557567145648440)
,p_event_id=>wwv_flow_imp.id(83557096063648439)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(83544095947648361)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83558065143648440)
,p_event_id=>wwv_flow_imp.id(83557096063648439)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(83544560093648361)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83558568790648440)
,p_event_id=>wwv_flow_imp.id(83557096063648439)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P67_ENCAISSE'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'0'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83559060954648442)
,p_event_id=>wwv_flow_imp.id(83557096063648439)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P67_ENCAISSE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83559569470648442)
,p_event_id=>wwv_flow_imp.id(83557096063648439)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(83544560093648361)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83559968530648442)
,p_name=>'VacationCloture'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P67_CLOTURE'
,p_condition_element=>'P67_CLOTURE'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Oui'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83560525568648442)
,p_event_id=>wwv_flow_imp.id(83559968530648442)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(83544560093648361)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83560925077648442)
,p_name=>'supptemp'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(83544560093648361)
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83561367227648444)
,p_event_id=>wwv_flow_imp.id(83560925077648442)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update bons set code_etat_bon = 1 where num_bon in (select num_bon from details_bon_temp',
'                                                   where trim(util_modif) = trim(nvl(v(''app_user''), user))) ; ',
'delete details_bon_temp where trim(util_modif) = trim(nvl(v(''app_user''), user));',
'commit;',
'delete bons_temp where trim(code_utilisateur) = trim(nvl(v(''app_user''), user));',
'insert into log_vacation values (:p67_num_vac,v(''app_user''),sysdate,null);',
'commit;'))
,p_attribute_02=>'P67_NUM_VAC'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83561781544648444)
,p_name=>'AffVacation'
,p_event_sequence=>50
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'a.affvacation'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83562313355648444)
,p_event_id=>wwv_flow_imp.id(83561781544648444)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P67_NUM_VACATION'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.id'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp.component_end;
end;
/
