prompt --application/pages/page_00706
begin
--   Manifest
--     PAGE: 00706
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>706
,p_name=>'Liste des type de caisse'
,p_alias=>'LISTE-DES-TYPE-DE-CAISSE'
,p_step_title=>'Liste des type de caisse'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(86488251992094873)
,p_plug_name=>'Etat 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>6
,p_query_type=>'TABLE'
,p_query_table=>'TYPE_CAISSE'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Etat 1'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(86488581763094873)
,p_name=>'Etat 1'
,p_max_row_count_message=>unistr('Le nombre maximal de lignes pour cet \00E9tat est de #MAX_ROW_COUNT# lignes. Appliquez un filtre pour r\00E9duire le nombre d''enregistrements dans votre requ\00EAte.')
,p_no_data_found_message=>unistr('Aucune donn\00E9e n''a \00E9t\00E9 trouv\00E9e.')
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:707:&SESSION.::&DEBUG.:RP:P707_CODE_TYPE_CAISSE:\#CODE_TYPE_CAISSE#\'
,p_detail_link_text=>'<span aria-label="Modifier"><span class="fa fa-edit" aria-hidden="true" title="Modifier"></span></span>'
,p_owner=>'BDHE'
,p_internal_uid=>31316021307421904
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86488683102094876)
,p_db_column_name=>'CODE_TYPE_CAISSE'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Code Type Caisse'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86489150955094878)
,p_db_column_name=>'LIB_TYPE_CAISSE'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>unistr('Libell\00E9')
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86489526814094879)
,p_db_column_name=>'ACTIF'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Actif'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(80976620147194334)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86489938090094879)
,p_db_column_name=>'DESCRIPTION'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Description'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86490272969094883)
,p_db_column_name=>'CODE_UTILISATEUR'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Code Utilisateur'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86490702908094884)
,p_db_column_name=>'DATE_CREATION'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Date Creation'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(86491622569096604)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'313191'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODE_TYPE_CAISSE:LIB_TYPE_CAISSE:ACTIF:DESCRIPTION:CODE_UTILISATEUR:DATE_CREATION'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(86491229319094886)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(86488251992094873)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Cr\00E9er')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:707:&SESSION.::&DEBUG.:707'
);
wwv_flow_imp.component_end;
end;
/
