prompt --application/pages/page_00015
begin
--   Manifest
--     PAGE: 00015
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>15
,p_name=>'Calc'
,p_alias=>'CALC'
,p_page_mode=>'MODAL'
,p_step_title=>'Calc'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'300'
,p_dialog_width=>'500'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(261727632075240592)
,p_plug_name=>unistr('Quantit\00E9')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81464854927392417)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(261727632075240592)
,p_button_name=>'un'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary:t-Button--gapLeft:t-Button--gapRight:t-Button--gapTop:t-Button--gapBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'     01     '
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81465200657392419)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(261727632075240592)
,p_button_name=>'deux'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary:t-Button--gapLeft:t-Button--gapRight:t-Button--gapTop:t-Button--gapBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'02'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81465603416392419)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(261727632075240592)
,p_button_name=>'trois'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary:t-Button--gapLeft:t-Button--gapRight:t-Button--gapTop:t-Button--gapBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'03'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81466027378392419)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(261727632075240592)
,p_button_name=>'quatre'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary:t-Button--gapLeft:t-Button--gapRight:t-Button--gapTop:t-Button--gapBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'04'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81466424617392419)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(261727632075240592)
,p_button_name=>'Cinq'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary:t-Button--gapLeft:t-Button--gapRight:t-Button--gapTop:t-Button--gapBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'05'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81466774393392420)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(261727632075240592)
,p_button_name=>'six'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary:t-Button--gapLeft:t-Button--gapRight:t-Button--gapTop:t-Button--gapBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'06'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81467225269392422)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(261727632075240592)
,p_button_name=>'sept'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary:t-Button--gapLeft:t-Button--gapRight:t-Button--gapTop:t-Button--gapBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'07'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81467621378392422)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(261727632075240592)
,p_button_name=>'huit'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary:t-Button--gapLeft:t-Button--gapRight:t-Button--gapTop:t-Button--gapBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'08'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81467964244392423)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(261727632075240592)
,p_button_name=>'neuf'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary:t-Button--gapLeft:t-Button--gapRight:t-Button--gapTop:t-Button--gapBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'09'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81468434049392423)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_imp.id(261727632075240592)
,p_button_name=>'Dix'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary:t-Button--gapLeft:t-Button--gapRight:t-Button--gapTop:t-Button--gapBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'10'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81468809138392423)
,p_button_sequence=>110
,p_button_plug_id=>wwv_flow_imp.id(261727632075240592)
,p_button_name=>'onze'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary:t-Button--gapLeft:t-Button--gapRight:t-Button--gapTop:t-Button--gapBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'11'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81469204087392425)
,p_button_sequence=>120
,p_button_plug_id=>wwv_flow_imp.id(261727632075240592)
,p_button_name=>'douze'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary:t-Button--gapLeft:t-Button--gapRight:t-Button--gapTop'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'12'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81469631150392425)
,p_button_sequence=>130
,p_button_plug_id=>wwv_flow_imp.id(261727632075240592)
,p_button_name=>'treize'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary:t-Button--gapLeft:t-Button--gapRight:t-Button--gapTop:t-Button--gapBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'13'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81470041033392425)
,p_button_sequence=>140
,p_button_plug_id=>wwv_flow_imp.id(261727632075240592)
,p_button_name=>'quatorze'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary:t-Button--gapLeft:t-Button--gapRight:t-Button--gapTop:t-Button--gapBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'14'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81470458776392426)
,p_button_sequence=>150
,p_button_plug_id=>wwv_flow_imp.id(261727632075240592)
,p_button_name=>'quinze'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary:t-Button--gapLeft:t-Button--gapRight:t-Button--gapTop:t-Button--gapBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'15'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81470837077392426)
,p_button_sequence=>160
,p_button_plug_id=>wwv_flow_imp.id(261727632075240592)
,p_button_name=>'seize'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary:t-Button--gapLeft:t-Button--gapRight:t-Button--gapTop:t-Button--gapBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'16'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81471201469392426)
,p_button_sequence=>170
,p_button_plug_id=>wwv_flow_imp.id(261727632075240592)
,p_button_name=>'dixsept'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary:t-Button--gapLeft:t-Button--gapRight:t-Button--gapTop:t-Button--gapBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'17'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81471615102392428)
,p_button_sequence=>180
,p_button_plug_id=>wwv_flow_imp.id(261727632075240592)
,p_button_name=>'dixhuit'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary:t-Button--gapLeft:t-Button--gapRight:t-Button--gapTop:t-Button--gapBottom'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'18'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81472034181392428)
,p_name=>'P15_NUM_PRODUIT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(261727632075240592)
,p_prompt=>'prd'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81472432240392429)
,p_name=>'P15_NUM_BON'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(261727632075240592)
,p_use_cache_before_default=>'NO'
,p_prompt=>'bon'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct d.num_bon nbon',
'from details_bon_temp d',
'where trim(d.code_utilisateur) = v(''app_user'');'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81472820875392431)
,p_name=>'P15_TOTAL'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(261727632075240592)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81473212600392433)
,p_name=>'P15_NOUVEAU'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(261727632075240592)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81473592264392433)
,p_name=>'P15_NUM_ESPACE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(261727632075240592)
,p_prompt=>'esp'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.num_espace_vente',
'from affectation a,personnel p,espace_vente e',
'where a.matricule = p.matricule',
'and a.num_espace_vente = e.num_espace_vente',
'and trim(profil_app) = nvl(v(''app_user''), user);'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81473985191392434)
,p_name=>'QTE1'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(81464854927392417)
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81474500362392436)
,p_event_id=>wwv_flow_imp.id(81473985191392434)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_prix is select valeur ',
'	from detail_produit',
'	where num_produit = :P15_NUM_PRODUIT',
'	and num_espace = :P15_NUM_ESPACE  --:button.num_espace',
'	and code_type_detail = 2;',
'r_prix c_prix%rowtype;',
'	',
'',
'cursor c_type_det is select code_type_famille from famille_produit x,type_produit y,produits z',
'where x.code_famille = y.code_famille',
'and y.code_type_produit = z.code_type_produit',
'and num_produit = :P15_NUM_PRODUIT;',
'',
'r_type_det c_type_det%rowtype;',
'',
'type_det char(1);',
'',
'prix number;',
'qte number;',
'',
'begin',
'    open c_type_det;',
'    fetch c_type_det into r_type_det;',
'    if c_type_det%found then',
'        type_det := r_type_det.code_type_famille;',
'     end if;',
'     close c_type_det;',
'     ',
'     open c_prix;',
'     fetch c_prix into r_prix;',
'     if c_prix%found then',
'        prix := r_prix.valeur;',
'      end if;',
'      close c_prix;',
'      ',
'    qte:=1;  ',
'    insert into details_bon_temp(NUM_DETAIL_BON,NUM_PRODUIT,NUM_BON,QTE_BON,PU_BON,QTE_RETOURNE,QTE_CONSIGNE,ETAT_DETAIL_BON,  ',
'            CODE_UTILISATEUR,DATE_CREATION,LIVRE,TYPE_DETAIL_BON,NUM_MENU,TOTAL,util_modif)',
'    values(seq_det_bon_temp.nextval,:P15_NUM_PRODUIT,:P15_NUM_BON,qte,prix,null,null,0,  ',
'            nvl(v(''app_user''), user),sysdate,0,type_det,null,prix*qte,v(''app_user''));',
'    commit;',
'   select sum(nvl(qte_bon,0)*nvl(pu_bon,0)) into :P15_TOTAL from details_bon_temp',
'   where trim(util_modif) = trim(v(''app_user''));',
'   ',
'   if nvl(:P12_NUM_BON,0)=0 then',
'      :p12_nouveau := 1;',
'   else',
'       if :p12_nouveau = 0 then',
'             :p12_nouveau := 1;',
'       else',
'             :p12_nouveau := 0;',
'       end if;',
'   end if;',
'      ',
'end;'))
,p_attribute_02=>'P15_NUM_PRODUIT,P15_NUM_ESPACE,P15_NUM_BON'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81475034729392437)
,p_event_id=>wwv_flow_imp.id(81473985191392434)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81475410219392437)
,p_name=>'QTE4'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(81466027378392419)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81475932661392439)
,p_event_id=>wwv_flow_imp.id(81475410219392437)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_prix is select valeur ',
'	from detail_produit',
'	where num_produit = :P15_NUM_PRODUIT',
'	and num_espace = :P15_NUM_ESPACE  --:button.num_espace',
'	and code_type_detail = 2;',
'r_prix c_prix%rowtype;',
'	',
'',
'cursor c_type_det is select code_type_famille from famille_produit x,type_produit y,produits z',
'where x.code_famille = y.code_famille',
'and y.code_type_produit = z.code_type_produit',
'and num_produit = :P15_NUM_PRODUIT;',
'',
'r_type_det c_type_det%rowtype;',
'',
'type_det char(1);',
'',
'prix number;qte number;',
'',
'begin',
'    open c_type_det;',
'    fetch c_type_det into r_type_det;',
'    if c_type_det%found then',
'        type_det := r_type_det.code_type_famille;',
'     end if;',
'     close c_type_det;',
'     ',
'     open c_prix;',
'     fetch c_prix into r_prix;',
'     if c_prix%found then',
'        prix := r_prix.valeur;',
'      end if;',
'      close c_prix;',
'      ',
'        ',
'    qte:=4;  ',
'    insert into details_bon_temp(NUM_DETAIL_BON,NUM_PRODUIT,NUM_BON,QTE_BON,PU_BON,QTE_RETOURNE,QTE_CONSIGNE,ETAT_DETAIL_BON,  ',
'            CODE_UTILISATEUR,DATE_CREATION,LIVRE,TYPE_DETAIL_BON,NUM_MENU,TOTAL,util_modif)',
'    values(seq_det_bon_temp.nextval,:P15_NUM_PRODUIT,:P15_NUM_BON,qte,prix,null,null,0,  ',
'            nvl(v(''app_user''), user),sysdate,0,type_det,null,prix*qte,v(''app_user''));',
'    commit;',
'   select sum(nvl(qte_bon,0)*nvl(pu_bon,0)) into :P15_TOTAL from details_bon_temp',
'   where trim(util_modif) = trim(v(''app_user''));',
'   if nvl(:P12_NUM_BON,0)=0 then',
'      :p12_nouveau := 1;',
'   else',
'       if :p12_nouveau = 0 then',
'             :p12_nouveau := 1;',
'       else',
'             :p12_nouveau := 0;',
'       end if;',
'   end if;',
'      ',
'end;',
''))
,p_attribute_02=>'P15_NUM_PRODUIT,P15_NUM_BON,P15_NUM_ESPACE,P15_TOTAL'
,p_attribute_03=>'P15_TOTAL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81476410700392440)
,p_event_id=>wwv_flow_imp.id(81475410219392437)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81476859736392440)
,p_name=>'QTE5'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(81466424617392419)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81477339260392442)
,p_event_id=>wwv_flow_imp.id(81476859736392440)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_prix is select valeur ',
'	from detail_produit',
'	where num_produit = :P15_NUM_PRODUIT',
'	and num_espace = :P15_NUM_ESPACE  --:button.num_espace',
'	and code_type_detail = 2;',
'r_prix c_prix%rowtype;',
'	',
'',
'cursor c_type_det is select code_type_famille from famille_produit x,type_produit y,produits z',
'where x.code_famille = y.code_famille',
'and y.code_type_produit = z.code_type_produit',
'and num_produit = :P15_NUM_PRODUIT;',
'',
'r_type_det c_type_det%rowtype;',
'',
'type_det char(1);',
'',
'prix number;qte number;',
'',
'begin',
'    open c_type_det;',
'    fetch c_type_det into r_type_det;',
'    if c_type_det%found then',
'        type_det := r_type_det.code_type_famille;',
'     end if;',
'     close c_type_det;',
'     ',
'     open c_prix;',
'     fetch c_prix into r_prix;',
'     if c_prix%found then',
'        prix := r_prix.valeur;',
'      end if;',
'      close c_prix;',
'      ',
'        ',
'   qte:=5;  ',
'    insert into details_bon_temp(NUM_DETAIL_BON,NUM_PRODUIT,NUM_BON,QTE_BON,PU_BON,QTE_RETOURNE,QTE_CONSIGNE,ETAT_DETAIL_BON,  ',
'            CODE_UTILISATEUR,DATE_CREATION,LIVRE,TYPE_DETAIL_BON,NUM_MENU,TOTAL,util_modif)',
'    values(seq_det_bon_temp.nextval,:P15_NUM_PRODUIT,:P15_NUM_BON,qte,prix,null,null,0,  ',
'            nvl(v(''app_user''), user),sysdate,0,type_det,null,prix*qte,v(''app_user''));',
'    commit;',
'   select sum(nvl(qte_bon,0)*nvl(pu_bon,0)) into :P15_TOTAL from details_bon_temp',
'   where trim(util_modif) = trim(v(''app_user''));',
'   if nvl(:P12_NUM_BON,0)=0 then',
'      :p12_nouveau := 1;',
'   else',
'       if :p12_nouveau = 0 then',
'             :p12_nouveau := 1;',
'       else',
'             :p12_nouveau := 0;',
'       end if;',
'   end if;',
'      ',
'end;',
''))
,p_attribute_02=>'P15_NUM_PRODUIT,P15_NUM_BON,P15_NUM_ESPACE,P15_TOTAL'
,p_attribute_03=>'P15_TOTAL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81477811244392442)
,p_event_id=>wwv_flow_imp.id(81476859736392440)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81478252824392444)
,p_name=>'QTE6'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(81466774393392420)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81478695449392445)
,p_event_id=>wwv_flow_imp.id(81478252824392444)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_prix is select valeur ',
'	from detail_produit',
'	where num_produit = :P15_NUM_PRODUIT',
'	and num_espace = :P15_NUM_ESPACE  --:button.num_espace',
'	and code_type_detail = 2;',
'r_prix c_prix%rowtype;',
'	',
'',
'cursor c_type_det is select code_type_famille from famille_produit x,type_produit y,produits z',
'where x.code_famille = y.code_famille',
'and y.code_type_produit = z.code_type_produit',
'and num_produit = :P15_NUM_PRODUIT;',
'',
'r_type_det c_type_det%rowtype;',
'',
'type_det char(1);',
'',
'prix number;qte number;',
'',
'begin',
'    open c_type_det;',
'    fetch c_type_det into r_type_det;',
'    if c_type_det%found then',
'        type_det := r_type_det.code_type_famille;',
'     end if;',
'     close c_type_det;',
'     ',
'     open c_prix;',
'     fetch c_prix into r_prix;',
'     if c_prix%found then',
'        prix := r_prix.valeur;',
'      end if;',
'      close c_prix;',
'      ',
'        ',
'    qte:=6;  ',
'    insert into details_bon_temp(NUM_DETAIL_BON,NUM_PRODUIT,NUM_BON,QTE_BON,PU_BON,QTE_RETOURNE,QTE_CONSIGNE,ETAT_DETAIL_BON,  ',
'            CODE_UTILISATEUR,DATE_CREATION,LIVRE,TYPE_DETAIL_BON,NUM_MENU,TOTAL,util_modif)',
'    values(seq_det_bon_temp.nextval,:P15_NUM_PRODUIT,:P15_NUM_BON,qte,prix,null,null,0,  ',
'            nvl(v(''app_user''), user),sysdate,0,type_det,null,prix*qte,v(''app_user''));',
'    commit;',
'   select sum(nvl(qte_bon,0)*nvl(pu_bon,0)) into :P15_TOTAL from details_bon_temp',
'   where trim(util_modif) = trim(v(''app_user''));',
'   if nvl(:P12_NUM_BON,0)=0 then',
'      :p12_nouveau := 1;',
'   else',
'       if :p12_nouveau = 0 then',
'             :p12_nouveau := 1;',
'       else',
'             :p12_nouveau := 0;',
'       end if;',
'   end if;',
'      ',
'end;',
''))
,p_attribute_02=>'P15_NUM_PRODUIT,P15_NUM_BON,P15_NUM_ESPACE,P15_TOTAL'
,p_attribute_03=>'P15_TOTAL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81479165510392445)
,p_event_id=>wwv_flow_imp.id(81478252824392444)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81479628434392447)
,p_name=>'QTE7'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(81467225269392422)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81480116961392447)
,p_event_id=>wwv_flow_imp.id(81479628434392447)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_prix is select valeur ',
'	from detail_produit',
'	where num_produit = :P15_NUM_PRODUIT',
'	and num_espace = :P15_NUM_ESPACE  --:button.num_espace',
'	and code_type_detail = 2;',
'r_prix c_prix%rowtype;',
'	',
'',
'cursor c_type_det is select code_type_famille from famille_produit x,type_produit y,produits z',
'where x.code_famille = y.code_famille',
'and y.code_type_produit = z.code_type_produit',
'and num_produit = :P15_NUM_PRODUIT;',
'',
'r_type_det c_type_det%rowtype;',
'',
'type_det char(1);',
'',
'prix number;qte number;',
'',
'begin',
'    open c_type_det;',
'    fetch c_type_det into r_type_det;',
'    if c_type_det%found then',
'        type_det := r_type_det.code_type_famille;',
'     end if;',
'     close c_type_det;',
'     ',
'     open c_prix;',
'     fetch c_prix into r_prix;',
'     if c_prix%found then',
'        prix := r_prix.valeur;',
'      end if;',
'      close c_prix;',
'      ',
'        ',
'    qte:=7;  ',
'    insert into details_bon_temp(NUM_DETAIL_BON,NUM_PRODUIT,NUM_BON,QTE_BON,PU_BON,QTE_RETOURNE,QTE_CONSIGNE,ETAT_DETAIL_BON,  ',
'            CODE_UTILISATEUR,DATE_CREATION,LIVRE,TYPE_DETAIL_BON,NUM_MENU,TOTAL,util_modif)',
'    values(seq_det_bon_temp.nextval,:P15_NUM_PRODUIT,:P15_NUM_BON,qte,prix,null,null,0,  ',
'            nvl(v(''app_user''), user),sysdate,0,type_det,null,prix*qte,v(''app_user''));',
'    commit;',
'   select sum(nvl(qte_bon,0)*nvl(pu_bon,0)) into :P15_TOTAL from details_bon_temp',
'   where trim(util_modif) = trim(v(''app_user''));',
'   if nvl(:P12_NUM_BON,0)=0 then',
'      :p12_nouveau := 1;',
'   else',
'       if :p12_nouveau = 0 then',
'             :p12_nouveau := 1;',
'       else',
'             :p12_nouveau := 0;',
'       end if;',
'   end if;',
'      ',
'end;',
''))
,p_attribute_02=>'P15_NUM_PRODUIT,P15_NUM_BON,P15_NUM_ESPACE,P15_TOTAL'
,p_attribute_03=>'P15_TOTAL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81480628392392448)
,p_event_id=>wwv_flow_imp.id(81479628434392447)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81480983133392450)
,p_name=>'QTE8'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(81467621378392422)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81481544291392450)
,p_event_id=>wwv_flow_imp.id(81480983133392450)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_prix is select valeur ',
'	from detail_produit',
'	where num_produit = :P15_NUM_PRODUIT',
'	and num_espace = :P15_NUM_ESPACE  --:button.num_espace',
'	and code_type_detail = 2;',
'r_prix c_prix%rowtype;',
'	',
'',
'cursor c_type_det is select code_type_famille from famille_produit x,type_produit y,produits z',
'where x.code_famille = y.code_famille',
'and y.code_type_produit = z.code_type_produit',
'and num_produit = :P15_NUM_PRODUIT;',
'',
'r_type_det c_type_det%rowtype;',
'',
'type_det char(1);',
'',
'prix number;qte number;',
'',
'begin',
'    open c_type_det;',
'    fetch c_type_det into r_type_det;',
'    if c_type_det%found then',
'        type_det := r_type_det.code_type_famille;',
'     end if;',
'     close c_type_det;',
'     ',
'     open c_prix;',
'     fetch c_prix into r_prix;',
'     if c_prix%found then',
'        prix := r_prix.valeur;',
'      end if;',
'      close c_prix;',
'      ',
'        ',
'    qte:=8;  ',
'    insert into details_bon_temp(NUM_DETAIL_BON,NUM_PRODUIT,NUM_BON,QTE_BON,PU_BON,QTE_RETOURNE,QTE_CONSIGNE,ETAT_DETAIL_BON,  ',
'            CODE_UTILISATEUR,DATE_CREATION,LIVRE,TYPE_DETAIL_BON,NUM_MENU,TOTAL,util_modif)',
'    values(seq_det_bon_temp.nextval,:P15_NUM_PRODUIT,:P15_NUM_BON,qte,prix,null,null,0,  ',
'            nvl(v(''app_user''), user),sysdate,0,type_det,null,prix*qte,v(''app_user''));',
'    commit;',
'   select sum(nvl(qte_bon,0)*nvl(pu_bon,0)) into :P15_TOTAL from details_bon_temp',
'   where trim(util_modif) = trim(v(''app_user''));',
'   if nvl(:P12_NUM_BON,0)=0 then',
'      :p12_nouveau := 1;',
'   else',
'       if :p12_nouveau = 0 then',
'             :p12_nouveau := 1;',
'       else',
'             :p12_nouveau := 0;',
'       end if;',
'   end if;',
'      ',
'end;',
''))
,p_attribute_02=>'P15_NUM_PRODUIT,P15_NUM_BON,P15_NUM_ESPACE,P15_TOTAL'
,p_attribute_03=>'P15_TOTAL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81482045393392451)
,p_event_id=>wwv_flow_imp.id(81480983133392450)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81482422374392451)
,p_name=>'QTE9'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(81467964244392423)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81482931832392453)
,p_event_id=>wwv_flow_imp.id(81482422374392451)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_prix is select valeur ',
'	from detail_produit',
'	where num_produit = :P15_NUM_PRODUIT',
'	and num_espace = :P15_NUM_ESPACE  --:button.num_espace',
'	and code_type_detail = 2;',
'r_prix c_prix%rowtype;',
'	',
'',
'cursor c_type_det is select code_type_famille from famille_produit x,type_produit y,produits z',
'where x.code_famille = y.code_famille',
'and y.code_type_produit = z.code_type_produit',
'and num_produit = :P15_NUM_PRODUIT;',
'',
'r_type_det c_type_det%rowtype;',
'',
'type_det char(1);',
'',
'prix number;qte number;',
'',
'begin',
'    open c_type_det;',
'    fetch c_type_det into r_type_det;',
'    if c_type_det%found then',
'        type_det := r_type_det.code_type_famille;',
'     end if;',
'     close c_type_det;',
'     ',
'     open c_prix;',
'     fetch c_prix into r_prix;',
'     if c_prix%found then',
'        prix := r_prix.valeur;',
'      end if;',
'      close c_prix;',
'      ',
'        ',
'   qte:=9;  ',
'    insert into details_bon_temp(NUM_DETAIL_BON,NUM_PRODUIT,NUM_BON,QTE_BON,PU_BON,QTE_RETOURNE,QTE_CONSIGNE,ETAT_DETAIL_BON,  ',
'            CODE_UTILISATEUR,DATE_CREATION,LIVRE,TYPE_DETAIL_BON,NUM_MENU,TOTAL,util_modif)',
'    values(seq_det_bon_temp.nextval,:P15_NUM_PRODUIT,:P15_NUM_BON,qte,prix,null,null,0,  ',
'            nvl(v(''app_user''), user),sysdate,0,type_det,null,prix*qte,v(''app_user''));',
'    commit;',
'   select sum(nvl(qte_bon,0)*nvl(pu_bon,0)) into :P15_TOTAL from details_bon_temp',
'   where trim(util_modif) = trim(v(''app_user''));',
'   if nvl(:P12_NUM_BON,0)=0 then',
'      :p12_nouveau := 1;',
'   else',
'       if :p12_nouveau = 0 then',
'             :p12_nouveau := 1;',
'       else',
'             :p12_nouveau := 0;',
'       end if;',
'   end if;',
'      ',
'end;',
''))
,p_attribute_02=>'P15_NUM_PRODUIT,P15_NUM_BON,P15_NUM_ESPACE,P15_TOTAL'
,p_attribute_03=>'P15_TOTAL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81483409902392454)
,p_event_id=>wwv_flow_imp.id(81482422374392451)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81483856226392456)
,p_name=>'QTE10'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(81468434049392423)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81484349260392458)
,p_event_id=>wwv_flow_imp.id(81483856226392456)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_prix is select valeur ',
'	from detail_produit',
'	where num_produit = :P15_NUM_PRODUIT',
'	and num_espace = :P15_NUM_ESPACE  --:button.num_espace',
'	and code_type_detail = 2;',
'r_prix c_prix%rowtype;',
'	',
'',
'cursor c_type_det is select code_type_famille from famille_produit x,type_produit y,produits z',
'where x.code_famille = y.code_famille',
'and y.code_type_produit = z.code_type_produit',
'and num_produit = :P15_NUM_PRODUIT;',
'',
'r_type_det c_type_det%rowtype;',
'',
'type_det char(1);',
'',
'prix number;qte number;',
'',
'begin',
'    open c_type_det;',
'    fetch c_type_det into r_type_det;',
'    if c_type_det%found then',
'        type_det := r_type_det.code_type_famille;',
'     end if;',
'     close c_type_det;',
'     ',
'     open c_prix;',
'     fetch c_prix into r_prix;',
'     if c_prix%found then',
'        prix := r_prix.valeur;',
'      end if;',
'      close c_prix;',
'      ',
'        ',
'    qte:=10;  ',
'    insert into details_bon_temp(NUM_DETAIL_BON,NUM_PRODUIT,NUM_BON,QTE_BON,PU_BON,QTE_RETOURNE,QTE_CONSIGNE,ETAT_DETAIL_BON,  ',
'            CODE_UTILISATEUR,DATE_CREATION,LIVRE,TYPE_DETAIL_BON,NUM_MENU,TOTAL,util_modif)',
'    values(seq_det_bon_temp.nextval,:P15_NUM_PRODUIT,:P15_NUM_BON,qte,prix,null,null,0,  ',
'            nvl(v(''app_user''), user),sysdate,0,type_det,null,prix*qte,v(''app_user''));',
'    commit;',
'   select sum(nvl(qte_bon,0)*nvl(pu_bon,0)) into :P15_TOTAL from details_bon_temp',
'   where trim(util_modif) = trim(v(''app_user''));',
'   if nvl(:P12_NUM_BON,0)=0 then',
'      :p12_nouveau := 1;',
'   else',
'       if :p12_nouveau = 0 then',
'             :p12_nouveau := 1;',
'       else',
'             :p12_nouveau := 0;',
'       end if;',
'   end if;',
'      ',
'end;',
''))
,p_attribute_02=>'P15_NUM_PRODUIT,P15_NUM_BON,P15_NUM_ESPACE,P15_TOTAL'
,p_attribute_03=>'P15_TOTAL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81484797309392459)
,p_event_id=>wwv_flow_imp.id(81483856226392456)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81485163717392461)
,p_name=>'QTE11'
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(81468809138392423)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81485698708392461)
,p_event_id=>wwv_flow_imp.id(81485163717392461)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_prix is select valeur ',
'	from detail_produit',
'	where num_produit = :P15_NUM_PRODUIT',
'	and num_espace = :P15_NUM_ESPACE  --:button.num_espace',
'	and code_type_detail = 2;',
'r_prix c_prix%rowtype;',
'	',
'',
'cursor c_type_det is select code_type_famille from famille_produit x,type_produit y,produits z',
'where x.code_famille = y.code_famille',
'and y.code_type_produit = z.code_type_produit',
'and num_produit = :P15_NUM_PRODUIT;',
'',
'r_type_det c_type_det%rowtype;',
'',
'type_det char(1);',
'',
'prix number;qte number;',
'',
'begin',
'    open c_type_det;',
'    fetch c_type_det into r_type_det;',
'    if c_type_det%found then',
'        type_det := r_type_det.code_type_famille;',
'     end if;',
'     close c_type_det;',
'     ',
'     open c_prix;',
'     fetch c_prix into r_prix;',
'     if c_prix%found then',
'        prix := r_prix.valeur;',
'      end if;',
'      close c_prix;',
'      ',
'        ',
'    qte:=11;  ',
'    insert into details_bon_temp(NUM_DETAIL_BON,NUM_PRODUIT,NUM_BON,QTE_BON,PU_BON,QTE_RETOURNE,QTE_CONSIGNE,ETAT_DETAIL_BON,  ',
'            CODE_UTILISATEUR,DATE_CREATION,LIVRE,TYPE_DETAIL_BON,NUM_MENU,TOTAL,util_modif)',
'    values(seq_det_bon_temp.nextval,:P15_NUM_PRODUIT,:P15_NUM_BON,qte,prix,null,null,0,  ',
'            nvl(v(''app_user''), user),sysdate,0,type_det,null,prix*qte,v(''app_user''));',
'    commit;',
'   select sum(nvl(qte_bon,0)*nvl(pu_bon,0)) into :P15_TOTAL from details_bon_temp',
'   where trim(util_modif) = trim(v(''app_user''));',
'   if nvl(:P12_NUM_BON,0)=0 then',
'      :p12_nouveau := 1;',
'   else',
'       if :p12_nouveau = 0 then',
'             :p12_nouveau := 1;',
'       else',
'             :p12_nouveau := 0;',
'       end if;',
'   end if;',
'      ',
'end;',
''))
,p_attribute_02=>'P15_NUM_PRODUIT,P15_NUM_BON,P15_NUM_ESPACE,P15_TOTAL'
,p_attribute_03=>'P15_TOTAL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81486231891392462)
,p_event_id=>wwv_flow_imp.id(81485163717392461)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81486484820392462)
,p_name=>'QTE12'
,p_event_sequence=>120
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(81469204087392425)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81486968589392464)
,p_event_id=>wwv_flow_imp.id(81486484820392462)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_prix is select valeur ',
'	from detail_produit',
'	where num_produit = :P15_NUM_PRODUIT',
'	and num_espace = :P15_NUM_ESPACE  --:button.num_espace',
'	and code_type_detail = 2;',
'r_prix c_prix%rowtype;',
'	',
'',
'cursor c_type_det is select code_type_famille from famille_produit x,type_produit y,produits z',
'where x.code_famille = y.code_famille',
'and y.code_type_produit = z.code_type_produit',
'and num_produit = :P15_NUM_PRODUIT;',
'',
'r_type_det c_type_det%rowtype;',
'',
'type_det char(1);',
'',
'prix number;qte number;',
'',
'begin',
'    open c_type_det;',
'    fetch c_type_det into r_type_det;',
'    if c_type_det%found then',
'        type_det := r_type_det.code_type_famille;',
'     end if;',
'     close c_type_det;',
'     ',
'     open c_prix;',
'     fetch c_prix into r_prix;',
'     if c_prix%found then',
'        prix := r_prix.valeur;',
'      end if;',
'      close c_prix;',
'      ',
'        ',
'    qte:=12;  ',
'    insert into details_bon_temp(NUM_DETAIL_BON,NUM_PRODUIT,NUM_BON,QTE_BON,PU_BON,QTE_RETOURNE,QTE_CONSIGNE,ETAT_DETAIL_BON,  ',
'            CODE_UTILISATEUR,DATE_CREATION,LIVRE,TYPE_DETAIL_BON,NUM_MENU,TOTAL,util_modif)',
'    values(seq_det_bon_temp.nextval,:P15_NUM_PRODUIT,:P15_NUM_BON,qte,prix,null,null,0,  ',
'            nvl(v(''app_user''), user),sysdate,0,type_det,null,prix*qte,v(''app_user''));',
'    commit;',
'   select sum(nvl(qte_bon,0)*nvl(pu_bon,0)) into :P15_TOTAL from details_bon_temp',
'   where trim(util_modif) = trim(v(''app_user''));',
'   if nvl(:P12_NUM_BON,0)=0 then',
'      :p12_nouveau := 1;',
'   else',
'       if :p12_nouveau = 0 then',
'             :p12_nouveau := 1;',
'       else',
'             :p12_nouveau := 0;',
'       end if;',
'   end if;',
'      ',
'end;',
''))
,p_attribute_02=>'P15_NUM_PRODUIT,P15_NUM_BON,P15_NUM_ESPACE,P15_TOTAL'
,p_attribute_03=>'P15_TOTAL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81487534113392465)
,p_event_id=>wwv_flow_imp.id(81486484820392462)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81487875328392465)
,p_name=>'QTE13'
,p_event_sequence=>130
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(81469631150392425)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81488427792392467)
,p_event_id=>wwv_flow_imp.id(81487875328392465)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_prix is select valeur ',
'	from detail_produit',
'	where num_produit = :P15_NUM_PRODUIT',
'	and num_espace = :P15_NUM_ESPACE  --:button.num_espace',
'	and code_type_detail = 2;',
'r_prix c_prix%rowtype;',
'	',
'',
'cursor c_type_det is select code_type_famille from famille_produit x,type_produit y,produits z',
'where x.code_famille = y.code_famille',
'and y.code_type_produit = z.code_type_produit',
'and num_produit = :P15_NUM_PRODUIT;',
'',
'r_type_det c_type_det%rowtype;',
'',
'type_det char(1);',
'',
'prix number;qte number;',
'',
'begin',
'    open c_type_det;',
'    fetch c_type_det into r_type_det;',
'    if c_type_det%found then',
'        type_det := r_type_det.code_type_famille;',
'     end if;',
'     close c_type_det;',
'     ',
'     open c_prix;',
'     fetch c_prix into r_prix;',
'     if c_prix%found then',
'        prix := r_prix.valeur;',
'      end if;',
'      close c_prix;',
'      ',
'        ',
'    qte:=13;  ',
'    insert into details_bon_temp(NUM_DETAIL_BON,NUM_PRODUIT,NUM_BON,QTE_BON,PU_BON,QTE_RETOURNE,QTE_CONSIGNE,ETAT_DETAIL_BON,  ',
'            CODE_UTILISATEUR,DATE_CREATION,LIVRE,TYPE_DETAIL_BON,NUM_MENU,TOTAL,util_modif)',
'    values(seq_det_bon_temp.nextval,:P15_NUM_PRODUIT,:P15_NUM_BON,qte,prix,null,null,0,  ',
'            nvl(v(''app_user''), user),sysdate,0,type_det,null,prix*qte,v(''app_user''));',
'    commit;',
'   select sum(nvl(qte_bon,0)*nvl(pu_bon,0)) into :P15_TOTAL from details_bon_temp',
'   where trim(util_modif) = trim(v(''app_user''));',
'   if nvl(:P12_NUM_BON,0)=0 then',
'      :p12_nouveau := 1;',
'   else',
'       if :p12_nouveau = 0 then',
'             :p12_nouveau := 1;',
'       else',
'             :p12_nouveau := 0;',
'       end if;',
'   end if;',
'      ',
'end;',
''))
,p_attribute_02=>'P15_NUM_PRODUIT,P15_NUM_BON,P15_NUM_ESPACE,P15_TOTAL'
,p_attribute_03=>'P15_TOTAL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81488909547392469)
,p_event_id=>wwv_flow_imp.id(81487875328392465)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81489270922392470)
,p_name=>'QTE14'
,p_event_sequence=>140
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(81470041033392425)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81489823438392470)
,p_event_id=>wwv_flow_imp.id(81489270922392470)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_prix is select valeur ',
'	from detail_produit',
'	where num_produit = :P15_NUM_PRODUIT',
'	and num_espace = :P15_NUM_ESPACE  --:button.num_espace',
'	and code_type_detail = 2;',
'r_prix c_prix%rowtype;',
'	',
'',
'cursor c_type_det is select code_type_famille from famille_produit x,type_produit y,produits z',
'where x.code_famille = y.code_famille',
'and y.code_type_produit = z.code_type_produit',
'and num_produit = :P15_NUM_PRODUIT;',
'',
'r_type_det c_type_det%rowtype;',
'',
'type_det char(1);',
'',
'prix number;qte number;',
'',
'begin',
'    open c_type_det;',
'    fetch c_type_det into r_type_det;',
'    if c_type_det%found then',
'        type_det := r_type_det.code_type_famille;',
'     end if;',
'     close c_type_det;',
'     ',
'     open c_prix;',
'     fetch c_prix into r_prix;',
'     if c_prix%found then',
'        prix := r_prix.valeur;',
'      end if;',
'      close c_prix;',
'      ',
'        ',
'    qte:=14;  ',
'    insert into details_bon_temp(NUM_DETAIL_BON,NUM_PRODUIT,NUM_BON,QTE_BON,PU_BON,QTE_RETOURNE,QTE_CONSIGNE,ETAT_DETAIL_BON,  ',
'            CODE_UTILISATEUR,DATE_CREATION,LIVRE,TYPE_DETAIL_BON,NUM_MENU,TOTAL,util_modif)',
'    values(seq_det_bon_temp.nextval,:P15_NUM_PRODUIT,:P15_NUM_BON,qte,prix,null,null,0,  ',
'            nvl(v(''app_user''), user),sysdate,0,type_det,null,prix*qte,v(''app_user''));',
'    commit;',
'   select sum(nvl(qte_bon,0)*nvl(pu_bon,0)) into :P15_TOTAL from details_bon_temp',
'   where trim(util_modif) = trim(v(''app_user''));',
'   if nvl(:P12_NUM_BON,0)=0 then',
'      :p12_nouveau := 1;',
'   else',
'       if :p12_nouveau = 0 then',
'             :p12_nouveau := 1;',
'       else',
'             :p12_nouveau := 0;',
'       end if;',
'   end if;',
'      ',
'end;',
''))
,p_attribute_02=>'P15_NUM_PRODUIT,P15_NUM_BON,P15_NUM_ESPACE,P15_TOTAL'
,p_attribute_03=>'P15_TOTAL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81490306646392472)
,p_event_id=>wwv_flow_imp.id(81489270922392470)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81490726673392472)
,p_name=>'QTE15'
,p_event_sequence=>150
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(81470458776392426)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81491180573392473)
,p_event_id=>wwv_flow_imp.id(81490726673392472)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_prix is select valeur ',
'	from detail_produit',
'	where num_produit = :P15_NUM_PRODUIT',
'	and num_espace = :P15_NUM_ESPACE  --:button.num_espace',
'	and code_type_detail = 2;',
'r_prix c_prix%rowtype;',
'	',
'',
'cursor c_type_det is select code_type_famille from famille_produit x,type_produit y,produits z',
'where x.code_famille = y.code_famille',
'and y.code_type_produit = z.code_type_produit',
'and num_produit = :P15_NUM_PRODUIT;',
'',
'r_type_det c_type_det%rowtype;',
'',
'type_det char(1);',
'',
'prix number;qte number;',
'',
'begin',
'    open c_type_det;',
'    fetch c_type_det into r_type_det;',
'    if c_type_det%found then',
'        type_det := r_type_det.code_type_famille;',
'     end if;',
'     close c_type_det;',
'     ',
'     open c_prix;',
'     fetch c_prix into r_prix;',
'     if c_prix%found then',
'        prix := r_prix.valeur;',
'      end if;',
'      close c_prix;',
'      ',
'        ',
'    qte:=15;  ',
'    insert into details_bon_temp(NUM_DETAIL_BON,NUM_PRODUIT,NUM_BON,QTE_BON,PU_BON,QTE_RETOURNE,QTE_CONSIGNE,ETAT_DETAIL_BON,  ',
'            CODE_UTILISATEUR,DATE_CREATION,LIVRE,TYPE_DETAIL_BON,NUM_MENU,TOTAL,util_modif)',
'    values(seq_det_bon_temp.nextval,:P15_NUM_PRODUIT,:P15_NUM_BON,qte,prix,null,null,0,  ',
'            nvl(v(''app_user''), user),sysdate,0,type_det,null,prix*qte,v(''app_user''));',
'    commit;',
'   select sum(nvl(qte_bon,0)*nvl(pu_bon,0)) into :P15_TOTAL from details_bon_temp',
'   where trim(util_modif) = trim(v(''app_user''));',
'   if nvl(:P12_NUM_BON,0)=0 then',
'      :p12_nouveau := 1;',
'   else',
'       if :p12_nouveau = 0 then',
'             :p12_nouveau := 1;',
'       else',
'             :p12_nouveau := 0;',
'       end if;',
'   end if;',
'      ',
'end;',
''))
,p_attribute_02=>'P15_NUM_PRODUIT,P15_NUM_BON,P15_NUM_ESPACE,P15_TOTAL'
,p_attribute_03=>'P15_TOTAL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81491707377392475)
,p_event_id=>wwv_flow_imp.id(81490726673392472)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81492158914392475)
,p_name=>'QTE16'
,p_event_sequence=>160
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(81470837077392426)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81492646834392476)
,p_event_id=>wwv_flow_imp.id(81492158914392475)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_prix is select valeur ',
'	from detail_produit',
'	where num_produit = :P15_NUM_PRODUIT',
'	and num_espace = :P15_NUM_ESPACE  --:button.num_espace',
'	and code_type_detail = 2;',
'r_prix c_prix%rowtype;',
'	',
'',
'cursor c_type_det is select code_type_famille from famille_produit x,type_produit y,produits z',
'where x.code_famille = y.code_famille',
'and y.code_type_produit = z.code_type_produit',
'and num_produit = :P15_NUM_PRODUIT;',
'',
'r_type_det c_type_det%rowtype;',
'',
'type_det char(1);',
'',
'prix number;qte number;',
'',
'begin',
'    open c_type_det;',
'    fetch c_type_det into r_type_det;',
'    if c_type_det%found then',
'        type_det := r_type_det.code_type_famille;',
'     end if;',
'     close c_type_det;',
'     ',
'     open c_prix;',
'     fetch c_prix into r_prix;',
'     if c_prix%found then',
'        prix := r_prix.valeur;',
'      end if;',
'      close c_prix;',
'      ',
'        ',
'    qte:=16;  ',
'    insert into details_bon_temp(NUM_DETAIL_BON,NUM_PRODUIT,NUM_BON,QTE_BON,PU_BON,QTE_RETOURNE,QTE_CONSIGNE,ETAT_DETAIL_BON,  ',
'            CODE_UTILISATEUR,DATE_CREATION,LIVRE,TYPE_DETAIL_BON,NUM_MENU,TOTAL,util_modif)',
'    values(seq_det_bon_temp.nextval,:P15_NUM_PRODUIT,:P15_NUM_BON,qte,prix,null,null,0,  ',
'            nvl(v(''app_user''), user),sysdate,0,type_det,null,prix*qte,v(''app_user''));',
'    commit;',
'   select sum(nvl(qte_bon,0)*nvl(pu_bon,0)) into :P15_TOTAL from details_bon_temp',
'   where trim(util_modif) = trim(v(''app_user''));',
'   if nvl(:P12_NUM_BON,0)=0 then',
'      :p12_nouveau := 1;',
'   else',
'       if :p12_nouveau = 0 then',
'             :p12_nouveau := 1;',
'       else',
'             :p12_nouveau := 0;',
'       end if;',
'   end if;',
'      ',
'end;',
''))
,p_attribute_02=>'P15_NUM_PRODUIT,P15_NUM_BON,P15_NUM_ESPACE,P15_TOTAL'
,p_attribute_03=>'P15_TOTAL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81493120737392476)
,p_event_id=>wwv_flow_imp.id(81492158914392475)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81493478790392478)
,p_name=>'QTE17'
,p_event_sequence=>170
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(81471201469392426)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81493967190392478)
,p_event_id=>wwv_flow_imp.id(81493478790392478)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_prix is select valeur ',
'	from detail_produit',
'	where num_produit = :P15_NUM_PRODUIT',
'	and num_espace = :P15_NUM_ESPACE  --:button.num_espace',
'	and code_type_detail = 2;',
'r_prix c_prix%rowtype;',
'	',
'',
'cursor c_type_det is select code_type_famille from famille_produit x,type_produit y,produits z',
'where x.code_famille = y.code_famille',
'and y.code_type_produit = z.code_type_produit',
'and num_produit = :P15_NUM_PRODUIT;',
'',
'r_type_det c_type_det%rowtype;',
'',
'type_det char(1);',
'',
'prix number;qte number;',
'',
'begin',
'    open c_type_det;',
'    fetch c_type_det into r_type_det;',
'    if c_type_det%found then',
'        type_det := r_type_det.code_type_famille;',
'     end if;',
'     close c_type_det;',
'     ',
'     open c_prix;',
'     fetch c_prix into r_prix;',
'     if c_prix%found then',
'        prix := r_prix.valeur;',
'      end if;',
'      close c_prix;',
'      ',
'        ',
'    qte:=17;  ',
'    insert into details_bon_temp(NUM_DETAIL_BON,NUM_PRODUIT,NUM_BON,QTE_BON,PU_BON,QTE_RETOURNE,QTE_CONSIGNE,ETAT_DETAIL_BON,  ',
'            CODE_UTILISATEUR,DATE_CREATION,LIVRE,TYPE_DETAIL_BON,NUM_MENU,TOTAL,util_modif)',
'    values(seq_det_bon_temp.nextval,:P15_NUM_PRODUIT,:P15_NUM_BON,qte,prix,null,null,0,  ',
'            nvl(v(''app_user''), user),sysdate,0,type_det,null,prix*qte,v(''app_user''));',
'    commit;',
'   select sum(nvl(qte_bon,0)*nvl(pu_bon,0)) into :P15_TOTAL from details_bon_temp',
'   where trim(util_modif) = trim(v(''app_user''));',
'   if nvl(:P12_NUM_BON,0)=0 then',
'      :p12_nouveau := 1;',
'   else',
'       if :p12_nouveau = 0 then',
'             :p12_nouveau := 1;',
'       else',
'             :p12_nouveau := 0;',
'       end if;',
'   end if;',
'      ',
'end;',
''))
,p_attribute_02=>'P15_NUM_PRODUIT,P15_NUM_BON,P15_NUM_ESPACE,P15_TOTAL'
,p_attribute_03=>'P15_TOTAL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81494466805392479)
,p_event_id=>wwv_flow_imp.id(81493478790392478)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81494899966392479)
,p_name=>'QTE18'
,p_event_sequence=>180
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(81471615102392428)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81495375400392481)
,p_event_id=>wwv_flow_imp.id(81494899966392479)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_prix is select valeur ',
'	from detail_produit',
'	where num_produit = :P15_NUM_PRODUIT',
'	and num_espace = :P15_NUM_ESPACE  --:button.num_espace',
'	and code_type_detail = 2;',
'r_prix c_prix%rowtype;',
'	',
'',
'cursor c_type_det is select code_type_famille from famille_produit x,type_produit y,produits z',
'where x.code_famille = y.code_famille',
'and y.code_type_produit = z.code_type_produit',
'and num_produit = :P15_NUM_PRODUIT;',
'',
'r_type_det c_type_det%rowtype;',
'',
'type_det char(1);',
'',
'prix number;qte number;',
'',
'begin',
'    open c_type_det;',
'    fetch c_type_det into r_type_det;',
'    if c_type_det%found then',
'        type_det := r_type_det.code_type_famille;',
'     end if;',
'     close c_type_det;',
'     ',
'     open c_prix;',
'     fetch c_prix into r_prix;',
'     if c_prix%found then',
'        prix := r_prix.valeur;',
'      end if;',
'      close c_prix;',
'      ',
'        ',
'    qte:=18;  ',
'    insert into details_bon_temp(NUM_DETAIL_BON,NUM_PRODUIT,NUM_BON,QTE_BON,PU_BON,QTE_RETOURNE,QTE_CONSIGNE,ETAT_DETAIL_BON,  ',
'            CODE_UTILISATEUR,DATE_CREATION,LIVRE,TYPE_DETAIL_BON,NUM_MENU,TOTAL,util_modif)',
'    values(seq_det_bon_temp.nextval,:P15_NUM_PRODUIT,:P15_NUM_BON,qte,prix,null,null,0,  ',
'            nvl(v(''app_user''), user),sysdate,0,type_det,null,prix*qte,v(''app_user''));',
'    commit;',
'   select sum(nvl(qte_bon,0)*nvl(pu_bon,0)) into :P15_TOTAL from details_bon_temp',
'   where trim(util_modif) = trim(v(''app_user''));',
'   if nvl(:P12_NUM_BON,0)=0 then',
'      :p12_nouveau := 1;',
'   else',
'       if :p12_nouveau = 0 then',
'             :p12_nouveau := 1;',
'       else',
'             :p12_nouveau := 0;',
'       end if;',
'   end if;',
'      ',
'end;',
''))
,p_attribute_02=>'P15_NUM_PRODUIT,P15_NUM_BON,P15_NUM_ESPACE,P15_TOTAL'
,p_attribute_03=>'P15_TOTAL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81495919814392483)
,p_event_id=>wwv_flow_imp.id(81494899966392479)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81496263633392483)
,p_name=>'QTE3'
,p_event_sequence=>190
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(81465603416392419)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81496793200392484)
,p_event_id=>wwv_flow_imp.id(81496263633392483)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_prix is select valeur ',
'	from detail_produit',
'	where num_produit = :P15_NUM_PRODUIT',
'	and num_espace = :P15_NUM_ESPACE  --:button.num_espace',
'	and code_type_detail = 2;',
'r_prix c_prix%rowtype;',
'	',
'',
'cursor c_type_det is select code_type_famille from famille_produit x,type_produit y,produits z',
'where x.code_famille = y.code_famille',
'and y.code_type_produit = z.code_type_produit',
'and num_produit = :P15_NUM_PRODUIT;',
'',
'r_type_det c_type_det%rowtype;',
'',
'type_det char(1);',
'',
'prix number;qte number;',
'',
'begin',
'    open c_type_det;',
'    fetch c_type_det into r_type_det;',
'    if c_type_det%found then',
'        type_det := r_type_det.code_type_famille;',
'     end if;',
'     close c_type_det;',
'     ',
'     open c_prix;',
'     fetch c_prix into r_prix;',
'     if c_prix%found then',
'        prix := r_prix.valeur;',
'      end if;',
'      close c_prix;',
'      ',
'        ',
'    qte:=3;  ',
'    insert into details_bon_temp(NUM_DETAIL_BON,NUM_PRODUIT,NUM_BON,QTE_BON,PU_BON,QTE_RETOURNE,QTE_CONSIGNE,ETAT_DETAIL_BON,  ',
'            CODE_UTILISATEUR,DATE_CREATION,LIVRE,TYPE_DETAIL_BON,NUM_MENU,TOTAL,util_modif)',
'    values(seq_det_bon_temp.nextval,:P15_NUM_PRODUIT,:P15_NUM_BON,qte,prix,null,null,0,  ',
'            nvl(v(''app_user''), user),sysdate,0,type_det,null,prix*qte,v(''app_user''));',
'    commit;',
'   select sum(nvl(qte_bon,0)*nvl(pu_bon,0)) into :P15_TOTAL from details_bon_temp',
'   where trim(util_modif) = trim(v(''app_user''));',
'   if nvl(:P12_NUM_BON,0)=0 then',
'      :p12_nouveau := 1;',
'   else',
'       if :p12_nouveau = 0 then',
'             :p12_nouveau := 1;',
'       else',
'             :p12_nouveau := 0;',
'       end if;',
'   end if;',
'      ',
'end;',
''))
,p_attribute_02=>'P15_NUM_PRODUIT,P15_NUM_BON,P15_NUM_ESPACE,P15_TOTAL'
,p_attribute_03=>'P15_TOTAL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81497269429392484)
,p_event_id=>wwv_flow_imp.id(81496263633392483)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81497732781392486)
,p_name=>'QTE2'
,p_event_sequence=>200
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(81465200657392419)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81498212550392486)
,p_event_id=>wwv_flow_imp.id(81497732781392486)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_prix is select valeur ',
'	from detail_produit',
'	where num_produit = :P15_NUM_PRODUIT',
'	and num_espace = :P15_NUM_ESPACE  --:button.num_espace',
'	and code_type_detail = 2;',
'r_prix c_prix%rowtype;',
'	',
'',
'cursor c_type_det is select code_type_famille from famille_produit x,type_produit y,produits z',
'where x.code_famille = y.code_famille',
'and y.code_type_produit = z.code_type_produit',
'and num_produit = :P15_NUM_PRODUIT;',
'',
'r_type_det c_type_det%rowtype;',
'',
'type_det char(1);',
'',
'prix number;qte number;',
'',
'begin',
'    open c_type_det;',
'    fetch c_type_det into r_type_det;',
'    if c_type_det%found then',
'        type_det := r_type_det.code_type_famille;',
'     end if;',
'     close c_type_det;',
'     ',
'     open c_prix;',
'     fetch c_prix into r_prix;',
'     if c_prix%found then',
'        prix := r_prix.valeur;',
'      end if;',
'      close c_prix;',
'      ',
'        ',
'    qte:=2;  ',
'    insert into details_bon_temp(NUM_DETAIL_BON,NUM_PRODUIT,NUM_BON,QTE_BON,PU_BON,QTE_RETOURNE,QTE_CONSIGNE,ETAT_DETAIL_BON,  ',
'            CODE_UTILISATEUR,DATE_CREATION,LIVRE,TYPE_DETAIL_BON,NUM_MENU,TOTAL,util_modif)',
'    values(seq_det_bon_temp.nextval,:P15_NUM_PRODUIT,:P15_NUM_BON,qte,prix,null,null,0,  ',
'            nvl(v(''app_user''), user),sysdate,0,type_det,null,prix*qte,v(''app_user''));',
'    commit;',
'   select sum(nvl(qte_bon,0)*nvl(pu_bon,0)) into :P15_TOTAL from details_bon_temp',
'   where trim(util_modif) = trim(v(''app_user''));',
'   if nvl(:P12_NUM_BON,0)=0 then',
'      :p12_nouveau := 1;',
'   else',
'       if :p12_nouveau = 0 then',
'             :p12_nouveau := 1;',
'       else',
'             :p12_nouveau := 0;',
'       end if;',
'   end if;',
'      ',
'end;',
''))
,p_attribute_02=>'P15_NUM_PRODUIT,P15_NUM_ESPACE,P15_NUM_BON,P15_TOTAL'
,p_attribute_03=>'P15_TOTAL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81498720056392487)
,p_event_id=>wwv_flow_imp.id(81497732781392486)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp.component_end;
end;
/
