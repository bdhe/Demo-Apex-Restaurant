prompt --application/pages/page_00106
begin
--   Manifest
--     PAGE: 00106
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>106
,p_name=>'Quantites'
,p_alias=>'QUANTITES'
,p_page_mode=>'MODAL'
,p_step_title=>'Quantites'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.r-qte{',
'    text-align: center;',
'    font-size: 30px;',
'    color: blue;',
'    ',
'}',
'',
'.card-unselected {',
'   height:80%;',
'   border-style:none;',
'}',
'.card-selected {',
'   height:100%;',
'   border-style:none;',
'   box-shadow: 5px 10px 8px #888888;',
'}',
'.a-CardView-items{',
'  padding:10px;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'800'
,p_dialog_width=>'1200'
,p_page_component_map=>'23'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(112570428820028090)
,p_plug_name=>'Options'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>5
,p_plug_header=>'<div style="height:550px;overflow:scroll;scrollbar-width: none;">  '
,p_plug_footer=>'</div>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(114197664885720266)
,p_plug_name=>'Desc'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(337875615020315840)
,p_plug_name=>unistr('Quantit\00E9s')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2072724515482255512
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select QTE ID,QTE',
'  from QUANTITE',
'  where qte <=24',
'  AND nvl(:P106_PAYE,''N'') != ''O''',
' order by qte'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P106_PAYE'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(55265880113807153)
,p_region_id=>wwv_flow_imp.id(337875615020315840)
,p_layout_type=>'GRID'
,p_grid_column_count=>3
,p_title_adv_formatting=>false
,p_title_column_name=>'QTE'
,p_title_css_classes=>'r-qte'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(55266040707807154)
,p_card_id=>wwv_flow_imp.id(55265880113807153)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
,p_link_attributes=>'data-action=select data-value=&ID.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81787835007531723)
,p_name=>'P106_P_COMBO_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(112570428820028090)
,p_use_cache_before_default=>'NO'
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select max(c.num_produit_combo) from produits p, produits_combo c',
'where p.num_produit = c.num_produit_combo',
'and c.num_produit = :P106_NUM_PRODUIT',
'and code_type_produit_combo = 1'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Choix 1'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select designation_produit,c.num_produit_combo from produits p, produits_combo c',
'where p.num_produit = c.num_produit_combo',
'and c.num_produit = :P106_NUM_PRODUIT',
'and code_type_produit_combo = 1',
'order by c.num_produit_combo desc'))
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81788214305531729)
,p_name=>'P106_P_COMBO_2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(112570428820028090)
,p_use_cache_before_default=>'NO'
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select max(c.num_produit_combo) from produits p, produits_combo c',
'where p.num_produit = c.num_produit_combo',
'and c.num_produit = :P106_NUM_PRODUIT',
'and code_type_produit_combo = 2'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Choix 2'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select designation_produit,c.num_produit_combo from produits p, produits_combo c',
'where p.num_produit = c.num_produit_combo',
'and c.num_produit = :P106_NUM_PRODUIT',
'and code_type_produit_combo = 2',
'order by c.num_produit_combo desc'))
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81788566834531729)
,p_name=>'P106_P_COMBO_3'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(112570428820028090)
,p_use_cache_before_default=>'NO'
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select max(c.num_produit_combo) from produits p, produits_combo c',
'where p.num_produit = c.num_produit_combo',
'and c.num_produit = :P106_NUM_PRODUIT',
'and code_type_produit_combo = 3'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Choix 3'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select designation_produit,c.num_produit_combo from produits p, produits_combo c',
'where p.num_produit = c.num_produit_combo',
'and c.num_produit = :P106_NUM_PRODUIT',
'and code_type_produit_combo = 3',
'order by c.num_produit_combo desc'))
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81789046569531731)
,p_name=>'P106_P_COMBO_4'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(112570428820028090)
,p_use_cache_before_default=>'NO'
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select max(c.num_produit_combo) from produits p, produits_combo c',
'where p.num_produit = c.num_produit_combo',
'and c.num_produit = :P106_NUM_PRODUIT',
'and code_type_produit_combo = 4'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Choix 4'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select designation_produit,c.num_produit_combo from produits p, produits_combo c',
'where p.num_produit = c.num_produit_combo',
'and c.num_produit = :P106_NUM_PRODUIT',
'and code_type_produit_combo = 4',
'order by c.num_produit_combo desc'))
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81789446142531731)
,p_name=>'P106_P_COMBO_5'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(112570428820028090)
,p_use_cache_before_default=>'NO'
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select max(c.num_produit_combo) from produits p, produits_combo c',
'where p.num_produit = c.num_produit_combo',
'and c.num_produit = :P106_NUM_PRODUIT',
'and code_type_produit_combo = 5'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Choix 5'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select designation_produit,c.num_produit_combo from produits p, produits_combo c',
'where p.num_produit = c.num_produit_combo',
'and c.num_produit = :P106_NUM_PRODUIT',
'and code_type_produit_combo = 5',
'order by c.num_produit_combo desc'))
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81789823948531731)
,p_name=>'P106_P_COMBO_6'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(112570428820028090)
,p_use_cache_before_default=>'NO'
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select max(c.num_produit_combo) from produits p, produits_combo c',
'where p.num_produit = c.num_produit_combo',
'and c.num_produit = :P106_NUM_PRODUIT',
'and code_type_produit_combo = 6'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Choix 6'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select designation_produit,c.num_produit_combo from produits p, produits_combo c',
'where p.num_produit = c.num_produit_combo',
'and c.num_produit = :P106_NUM_PRODUIT',
'and code_type_produit_combo = 6',
'order by c.num_produit_combo desc'))
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81790198246531733)
,p_name=>'P106_P_COMBO_7'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(112570428820028090)
,p_use_cache_before_default=>'NO'
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select max(c.num_produit_combo) from produits p, produits_combo c',
'where p.num_produit = c.num_produit_combo',
'and c.num_produit = :P106_NUM_PRODUIT',
'and code_type_produit_combo = 7'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Choix 7'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select designation_produit,c.num_produit_combo from produits p, produits_combo c',
'where p.num_produit = c.num_produit_combo',
'and c.num_produit = :P106_NUM_PRODUIT',
'and code_type_produit_combo = 7',
'order by c.num_produit_combo desc'))
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81790580737531734)
,p_name=>'P106_P_COMBO_8'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(112570428820028090)
,p_use_cache_before_default=>'NO'
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select max(c.num_produit_combo) from produits p, produits_combo c',
'where p.num_produit = c.num_produit_combo',
'and c.num_produit = :P106_NUM_PRODUIT',
'and code_type_produit_combo = 8'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Choix 8'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select designation_produit,c.num_produit_combo from produits p, produits_combo c',
'where p.num_produit = c.num_produit_combo',
'and c.num_produit = :P106_NUM_PRODUIT',
'and code_type_produit_combo = 8',
'order by c.num_produit_combo desc'))
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81791056670531734)
,p_name=>'P106_P_COMBO_9'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(112570428820028090)
,p_use_cache_before_default=>'NO'
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select max(c.num_produit_combo) from produits p, produits_combo c',
'where p.num_produit = c.num_produit_combo',
'and c.num_produit = :P106_NUM_PRODUIT',
'and code_type_produit_combo = 9'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Choix 9'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select designation_produit,c.num_produit_combo from produits p, produits_combo c',
'where p.num_produit = c.num_produit_combo',
'and c.num_produit = :P106_NUM_PRODUIT',
'and code_type_produit_combo = 9',
'order by c.num_produit_combo desc'))
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81791374155531734)
,p_name=>'P106_P_COMBO_10'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(112570428820028090)
,p_use_cache_before_default=>'NO'
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select max(c.num_produit_combo) from produits p, produits_combo c',
'where p.num_produit = c.num_produit_combo',
'and c.num_produit = :P106_NUM_PRODUIT',
'and code_type_produit_combo = 10'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Choix 10'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select designation_produit,c.num_produit_combo from produits p, produits_combo c',
'where p.num_produit = c.num_produit_combo',
'and c.num_produit = :P106_NUM_PRODUIT',
'and code_type_produit_combo = 10',
'order by c.num_produit_combo desc'))
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81792087246531736)
,p_name=>'P106_DESCRIPTION'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(114197664885720266)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select trim(designation_produit) ||'' : ''|| trim(description)   as lib from produits',
'where num_produit = :P106_NUM_PRODUIT;'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81794664394531742)
,p_name=>'P106_NUM_PRODUIT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(337875615020315840)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81795133148531744)
,p_name=>'P106_NUM_BON'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(337875615020315840)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct d.num_bon nbon',
'from details_bon_temp d',
'where trim(d.util_modif) = trim(v(''app_user''))'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81795536694531744)
,p_name=>'P106_PAYE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(337875615020315840)
,p_use_cache_before_default=>'NO'
,p_source=>'select paye from bons where num_bon=:P106_NUM_BON'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81795905211531744)
,p_name=>'P106_TOTAL'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(337875615020315840)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81796262898531745)
,p_name=>'P106_NOUVEAU'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(337875615020315840)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81796720342531745)
,p_name=>'P106_NUM_ESPACE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(337875615020315840)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.num_espace_vente',
'from affectation a,personnel p,espace_vente e',
'where a.matricule = p.matricule',
'and a.num_espace_vente = e.num_espace_vente',
'and trim(profil_app) = nvl(v(''app_user''), user);'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81797132228531747)
,p_name=>'P106_QTE'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(337875615020315840)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81797959706531748)
,p_name=>'Get selected card'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'[data-action=''select'']'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81798432224531748)
,p_event_id=>wwv_flow_imp.id(81797959706531748)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P106_QTE'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.dataset.value'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81798878965531748)
,p_event_id=>wwv_flow_imp.id(81797959706531748)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'begin',
'    pr_insert_bon_temp(:P106_NUM_PRODUIT,:P106_NUM_ESPACE,:P106_NUM_BON, :P106_QTE,v(''app_user''),',
'                            :P106_P_COMBO_1,:P106_P_COMBO_2 ,:P106_P_COMBO_3 ,:P106_P_COMBO_4,',
'                            :P106_P_COMBO_5,:P106_P_COMBO_6,:P106_P_COMBO_7 ,:P106_P_COMBO_8 ,',
'                            :P106_P_COMBO_9 ,:P106_P_COMBO_10 );',
' end;',
'',
''))
,p_attribute_02=>'P106_NUM_PRODUIT,P106_NUM_ESPACE,P106_NUM_BON,P106_QTE,P106_P_COMBO_3,P106_P_COMBO_2,P106_P_COMBO_1,P106_P_COMBO_4,P106_P_COMBO_5,P106_P_COMBO_6,P106_P_COMBO_7,P106_P_COMBO_8,P106_P_COMBO_9,P106_P_COMBO_10'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81799415340531750)
,p_event_id=>wwv_flow_imp.id(81797959706531748)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81799939916531750)
,p_event_id=>wwv_flow_imp.id(81797959706531748)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81800327953531751)
,p_name=>'cache'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P106_P_COMBO_3'
,p_condition_element=>'P106_P_COMBO_3'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81800821037531751)
,p_event_id=>wwv_flow_imp.id(81800327953531751)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P106_P_COMBO_3'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81801165439531751)
,p_name=>'cc'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P106_P_COMBO_2'
,p_condition_element=>'P106_P_COMBO_2'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81801726765531753)
,p_event_id=>wwv_flow_imp.id(81801165439531751)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P106_P_COMBO_2'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81802127080531753)
,p_name=>'c'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P106_P_COMBO_1'
,p_condition_element=>'P106_P_COMBO_1'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81802617768531753)
,p_event_id=>wwv_flow_imp.id(81802127080531753)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P106_P_COMBO_1'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81803032299531754)
,p_name=>'New'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P106_P_COMBO_4'
,p_condition_element=>'P106_P_COMBO_4'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81803520008531754)
,p_event_id=>wwv_flow_imp.id(81803032299531754)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P106_P_COMBO_4'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81803892081531754)
,p_name=>'New_1'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P106_P_COMBO_5'
,p_condition_element=>'P106_P_COMBO_5'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81804403684531756)
,p_event_id=>wwv_flow_imp.id(81803892081531754)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P106_P_COMBO_5'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81804859187531756)
,p_name=>'New_2'
,p_event_sequence=>90
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P106_P_COMBO_6'
,p_condition_element=>'P106_P_COMBO_6'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81805261373531756)
,p_event_id=>wwv_flow_imp.id(81804859187531756)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P106_P_COMBO_6'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81805737018531758)
,p_name=>'New_3'
,p_event_sequence=>100
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P106_P_COMBO_7'
,p_condition_element=>'P106_P_COMBO_7'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81806176806531758)
,p_event_id=>wwv_flow_imp.id(81805737018531758)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P106_P_COMBO_7'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81806611907531758)
,p_name=>'New_4'
,p_event_sequence=>110
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P106_P_COMBO_8'
,p_condition_element=>'P106_P_COMBO_8'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81807084328531759)
,p_event_id=>wwv_flow_imp.id(81806611907531758)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P106_P_COMBO_8'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81807511869531759)
,p_name=>'New_5'
,p_event_sequence=>120
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P106_P_COMBO_9'
,p_condition_element=>'P106_P_COMBO_9'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81807961453531761)
,p_event_id=>wwv_flow_imp.id(81807511869531759)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P106_P_COMBO_9'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81808380559531761)
,p_name=>'New_6'
,p_event_sequence=>130
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P106_P_COMBO_10'
,p_condition_element=>'P106_P_COMBO_10'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81808885367531761)
,p_event_id=>wwv_flow_imp.id(81808380559531761)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P106_P_COMBO_10'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(81797510769531747)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Extras'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'p_num_produit number;',
'',
'nb number;',
'begin',
'    nb := APEX_APPLICATION.G_F01.COUNT;',
'    --insert into trace_extras values(nb,0,0);',
'    FOR I in 1..APEX_APPLICATION.G_F01.COUNT LOOP',
'        ',
'        p_num_produit := to_number(APEX_APPLICATION.G_F01(i));       ',
'        pr_insert_bon_temp(p_num_produit,:P106_NUM_ESPACE,:P106_NUM_BON, :P106_QTE,v(''app_user''), 0,0,0,0,0,0,0,0,0,0 );      ',
'    END LOOP;',
'    commit;',
' end;',
'',
'',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>81797510769531747
);
wwv_flow_imp.component_end;
end;
/
