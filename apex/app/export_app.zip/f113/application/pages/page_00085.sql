prompt --application/pages/page_00085
begin
--   Manifest
--     PAGE: 00085
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>85
,p_name=>'Produits'
,p_alias=>'PRODUITS'
,p_step_title=>'Produits'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'ON'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'table.apexir_WORKSHEET_CUSTOM td {',
'border-right: none !important;',
'}',
'table.a-IRR-detailViewTable {width:100%;}',
'table.reportDetail {width:100%;}'))
,p_step_template=>4072355960268175073
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_help_text=>'No help is available for this page.'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7604393308200731511)
,p_plug_name=>'Products'
,p_region_name=>'productsIRR'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select p.num_produit,',
'       p.designation_produit, ',
'       p.code_type_produit, ',
'       p.stockable, ',
'       fn_stockprdpv(p.num_produit,0,sysdate) Stock,',
'       unite_mesure,',
'       p.actif,',
'       p.num_produit img, ',
'       apex_util.prepare_url(p_url=>''f?p=''||:app_id||'':88:''||:app_session||''::::P88_NUM_PRODUIT,P88_BRANCH:''||p.num_produit||'',''||3,p_dialog=> ''null'') icon_link,',
'       decode(nvl(dbms_lob.getlength(p.product_image),0),0,null,',
'       ''<img alt="''||apex_escape.html_attribute(p.designation_produit)||''" title="''||apex_escape.html_attribute(p.designation_produit)',
'              ||''" style="border: 4px solid #CCC; -moz-border-radius: 4px; -webkit-border-radius: 4px;" ''',
'              ||''src="''||apex_util.get_blob_file_src(''P88_PRODUCT_IMAGE'',p.num_produit)||''" height="75" width="75" />'') detail_img,',
'       decode(nvl(dbms_lob.getlength(p.product_image),0),0,null,',
'       apex_util.get_blob_file_src(''P88_PRODUCT_IMAGE'',p.num_produit))',
'       detail_img_no_style',
'from produits p',
'where num_produit !=0',
'order by code_type_produit',
'',
'--fn_stockprdpv(p.num_produit,0) Qte,'))
,p_plug_source_type=>'NATIVE_IR'
,p_plug_query_show_nulls_as=>' - '
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(7604393392989731511)
,p_name=>'Products'
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows. Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_allow_save_rpt_public=>'Y'
,p_allow_report_categories=>'N'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_notify=>'Y'
,p_show_calendar=>'N'
,p_download_formats=>'HTML:CSV'
,p_enable_mail_download=>'N'
,p_icon_view_enabled_yn=>'Y'
,p_icon_view_link_column=>'ICON_LINK'
,p_icon_view_img_src_column=>'DETAIL_IMG_NO_STYLE'
,p_icon_view_label_column=>'NUM_PRODUIT'
,p_icon_view_img_attr_text=>'width="75" height="75"'
,p_icon_view_columns_per_row=>5
,p_detail_view_enabled_yn=>'Y'
,p_detail_view_before_rows=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<style>',
'table.apexir_WORKSHEET_CUSTOM { border: none !important; -moz-box-shadow: none; box-shadow: none; -webkit-box-shadow: none; }',
'.apexir_WORKSHEET_DATA td {border-bottom: none !important;}',
'table.reportDetail td {',
'        padding: 2px 4px !important;',
'	border: none !important;',
'	font: 11px/16px Arial, sans-serif;',
'	}',
'	table.reportDetail td.separator {',
'		background: #F0F0F0 !important;',
'		padding: 0 !important;',
'		height: 1px !important;',
'padding: 0;',
'		line-height: 2px !important;',
'overflow: hidden;',
'		}',
'table.reportDetail td h1 {margin: 0 !important}',
'table.reportDetail td img {margin-top: 8px; border: 4px solid #CCC; -moz-border-radius: 4px; -webkit-border-radius: 4px;}',
'</style>',
'<table class="reportDetail">'))
,p_detail_view_for_each_row=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<tr>',
'<td rowspan="5" valign="top"><img width="75" height="75" src="#DETAIL_IMG_NO_STYLE#" alt="#PRODUCT_NAME#"></td>',
'<td colspan="6"><h1><a href="#ICON_LINK#"><strong>#PRODUCT_NAME#</strong></a></h1></td>',
'</tr>',
'<tr>',
'<td><strong>#CATEGORY_LABEL#:</strong></td><td>#CATEGORY#</td>',
'<td><strong>#PRODUCT_AVAIL_LABEL#:</strong></td><td>#PRODUCT_AVAIL#</td>',
'<td><strong>#LAST_DATE_SOLD_LABEL#:</strong></td><td>#LAST_DATE_SOLD#</td>',
'</tr>',
'<tr>',
'<td align="left"><strong>#PRODUCT_DESCRIPTION_LABEL#:</strong></td><td colspan="5" >#PRODUCT_DESCRIPTION#</td>',
'</tr>',
'<tr>',
'<td style="padding-bottom: 0px;"><strong>#LIST_PRICE_LABEL#</strong></td>',
'<td style="padding-bottom: 0px;"><strong>#UNITS_LABEL#</strong></td>',
'<td style="padding-bottom: 0px;"><strong>#SALES_LABEL#</strong></td>',
'<td style="padding-bottom: 0px;"><strong>#CUSTOMERS_LABEL#</strong></td>',
'</tr>',
'<tr>',
'<td style="padding-top: 0px;">#LIST_PRICE#</td>',
'<td style="padding-top: 0px;">#UNITS#</td>',
'<td style="padding-top: 0px;">#SALES#</td>',
'<td style="padding-top: 0px;">#CUSTOMERS#</td>',
'</tr>',
'<tr><td colspan="7" class="separator">&nbsp;</td></tr>'))
,p_detail_view_after_rows=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<tr><td colspan="7" class="separator"></td></tr>',
'</table>'))
,p_owner=>'DPEAKE'
,p_internal_uid=>7549220832534058542
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(82086064326685062)
,p_db_column_name=>'IMG'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Image'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'IMAGE:DEMO_PRODUCT_INFO:PRODUCT_IMAGE:PRODUCT_ID::MIMETYPE:FILENAME:IMAGE_LAST_UPDATE::inline:'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(82086507497685062)
,p_db_column_name=>'ICON_LINK'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Icon Link'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(82086886124685064)
,p_db_column_name=>'DETAIL_IMG'
,p_display_order=>13
,p_column_identifier=>'M'
,p_column_label=>'Image'
,p_allow_filtering=>'N'
,p_allow_highlighting=>'N'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(82087351816685064)
,p_db_column_name=>'DETAIL_IMG_NO_STYLE'
,p_display_order=>14
,p_column_identifier=>'N'
,p_column_label=>'Detail Img No Style'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(82085759577685061)
,p_db_column_name=>'STOCKABLE'
,p_display_order=>54
,p_column_identifier=>'T'
,p_column_label=>'Stockable'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(80976620147194334)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(82085286360685061)
,p_db_column_name=>'NUM_PRODUIT'
,p_display_order=>84
,p_column_identifier=>'Q'
,p_column_label=>'Num Produit'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(82087742436685065)
,p_db_column_name=>'DESIGNATION_PRODUIT'
,p_display_order=>94
,p_column_identifier=>'V'
,p_column_label=>'Designation Produit'
,p_column_link=>'f?p=&APP_ID.:88:&SESSION.::&DEBUG.:RP:P88_NUM_PRODUIT,P88_BRANCH:#NUM_PRODUIT#,3'
,p_column_linktext=>'#DESIGNATION_PRODUIT#'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(82088112192685065)
,p_db_column_name=>'CODE_TYPE_PRODUIT'
,p_display_order=>104
,p_column_identifier=>'W'
,p_column_label=>'Type Produit'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(80978610833194342)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(82088555237685067)
,p_db_column_name=>'STOCK'
,p_display_order=>114
,p_column_identifier=>'X'
,p_column_label=>'Stock principal'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G990D00'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(82084860979685037)
,p_db_column_name=>'UNITE_MESURE'
,p_display_order=>124
,p_column_identifier=>'Z'
,p_column_label=>'Unite Mesure'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(82088896683685067)
,p_db_column_name=>'ACTIF'
,p_display_order=>134
,p_column_identifier=>'Y'
,p_column_label=>'Actif'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'CENTER'
,p_rpt_named_lov=>wwv_flow_imp.id(80976620147194334)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(7604394697472732266)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_type=>'REPORT'
,p_report_alias=>'347543'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_display_rows=>15
,p_report_columns=>'DETAIL_IMG::NUM_PRODUITABLE:DESIGNATION_PRODUIT:CODE_TYPE_PRODUIT:STOCK:ACTIF:UNITE_MESURE'
,p_sort_column_1=>'PRODUCT_NAME'
,p_sort_direction_1=>'ASC'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(82089558251685095)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(7604393308200731511)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Cr\00E9er')
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:88:&SESSION.::&DEBUG.:6:P88_BRANCH:3'
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(82089923503685097)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(7604393308200731511)
,p_button_name=>'RESET'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Reset'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:&APP_PAGE_ID.:&SESSION.::&DEBUG.:&APP_PAGE_ID.,RIR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(82093136078685170)
,p_branch_name=>'Go To Page 6'
,p_branch_action=>'f?p=&FLOW_ID.:6:&SESSION.::&DEBUG.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(82089558251685095)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(82090319662685162)
,p_name=>'Create Product - Dialog Closed actions'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(82089558251685095)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(82090811053685164)
,p_event_id=>wwv_flow_imp.id(82090319662685162)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(7604393308200731511)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(82091188068685165)
,p_name=>'Product Report - Dialog Closed actions'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(7604393308200731511)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(82091719873685167)
,p_event_id=>wwv_flow_imp.id(82091188068685165)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(7604393308200731511)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(82092126135685167)
,p_name=>'Fix icon view of Products IRR'
,p_event_sequence=>30
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(82092656074685167)
,p_event_id=>wwv_flow_imp.id(82092126135685167)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''table.a-IRR-iconViewTable td'').attr(''align'',''middle'');'
);
wwv_flow_imp.component_end;
end;
/
