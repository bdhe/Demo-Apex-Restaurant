prompt --application/pages/page_00012
begin
--   Manifest
--     PAGE: 00012
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>12
,p_name=>'Comptoir'
,p_alias=>'COMPTOIR'
,p_step_title=>'Comptoir'
,p_allow_duplicate_submissions=>'N'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_css_file_urls=>'#APP_IMAGES#resto.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Scroll Results Only in Side Column */',
'.t-Body-side {',
'    display: flex;',
'    flex-direction: column;',
'    overflow: hidden;',
'}',
'.search-results {',
'    flex: 1;',
'    overflow: auto;',
'}',
'/* Format Search Region */',
'.search-region {',
'    border-bottom: 1px solid rgba(0,0,0,.1);',
'    flex-shrink: 0;',
'}',
'.total {',
'    height: 100px',
'}'))
,p_step_template=>2526643373347724467
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(233046040465873240)
,p_plug_name=>'Infos Vacation'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>30
,p_plug_grid_column_span=>4
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(234366762718593963)
,p_name=>'Encours Bons'
,p_template=>4501440665235496320
,p_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select rowid,num_bon id1,num_bon id,num_bon,decode(code_traitement,''S'',to_char(num_table),num_ticket) wtable,date_bon,montant_bon,num_espace_vente,',
'livre,paye,code_utilisateur,code_etat_bon,date_creation',
'from bons',
'where paye=''N'' ',
'and facture =''N''',
'and code_etat_bon in (1,2)',
'and num_espace_vente = :P12_NUMESPACE',
'order by num_bon ;  '))
,p_header=>'  <div style="height:350px;overflow:scroll"> '
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P12_NUMESPACE'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81364026703375947)
,p_query_column_id=>1
,p_column_alias=>'ROWID'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81364386215375948)
,p_query_column_id=>2
,p_column_alias=>'ID1'
,p_column_display_sequence=>12
,p_column_heading=>'Suppr.'
,p_column_link=>'#'
,p_column_linktext=>'<span class="t-Icon fa fa-trash-o" aria-hidden="true"></span>'
,p_column_link_attr=>'id=''#ID#'' class="deleteB t-Button t-Button--danger t-Button--simple t-Button--small" title="Supprimer : #NUM_BON#"'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81364793260375948)
,p_query_column_id=>3
,p_column_alias=>'ID'
,p_column_display_sequence=>13
,p_column_heading=>'Select.'
,p_column_link=>'#'
,p_column_linktext=>'<span class="t-Icon fa fa-toggle-up affbons-note" aria-hidden="true"></span>'
,p_column_link_attr=>'id=''#ID#'' class="affbons t-Button t-Button--danger t-Button--simple t-Button--small" title="Selectionner Bons: #NUM_BON#"'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81365195739375950)
,p_query_column_id=>4
,p_column_alias=>'NUM_BON'
,p_column_display_sequence=>2
,p_column_heading=>unistr('N\00B0 Bon')
,p_column_html_expression=>'<span style="display:block; width:50px"><h5>#NUM_BON#</h5></span>'
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81365584082375951)
,p_query_column_id=>5
,p_column_alias=>'WTABLE'
,p_column_display_sequence=>3
,p_column_heading=>'Table/Ref'
,p_column_html_expression=>'<span style="display:block; width:60px"><h5>#WTABLE#</h5></span>'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81365978363375953)
,p_query_column_id=>6
,p_column_alias=>'DATE_BON'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81366389594375953)
,p_query_column_id=>7
,p_column_alias=>'MONTANT_BON'
,p_column_display_sequence=>5
,p_column_heading=>'Montant '
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_html_expression=>'<span style="display:block; width:100px"><h5>#MONTANT_BON#</h5></span>'
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81366813506375954)
,p_query_column_id=>8
,p_column_alias=>'NUM_ESPACE_VENTE'
,p_column_display_sequence=>4
,p_column_heading=>'Espace Vente'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(81019840160213400)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81367169485375954)
,p_query_column_id=>9
,p_column_alias=>'LIVRE'
,p_column_display_sequence=>6
,p_column_heading=>unistr('Livr\00E9')
,p_column_alignment=>'CENTER'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(80976620147194334)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81367625285375956)
,p_query_column_id=>10
,p_column_alias=>'PAYE'
,p_column_display_sequence=>7
,p_column_heading=>unistr('Pay\00E9')
,p_column_alignment=>'CENTER'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(80976620147194334)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81367982299375956)
,p_query_column_id=>11
,p_column_alias=>'CODE_UTILISATEUR'
,p_column_display_sequence=>8
,p_column_heading=>'Emetteur'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81368425346375958)
,p_query_column_id=>12
,p_column_alias=>'CODE_ETAT_BON'
,p_column_display_sequence=>9
,p_column_heading=>'Etat Bon'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(81311737542361267)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81368762496375958)
,p_query_column_id=>13
,p_column_alias=>'DATE_CREATION'
,p_column_display_sequence=>11
,p_column_heading=>unistr('Cr\00E9e \00E0 ')
,p_column_format=>'HH24:MI'
,p_column_html_expression=>'<span style="display:block; width:40px"><h5>#DATE_CREATION#</h5></span>'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(261539216039316055)
,p_name=>'FamilleMaster'
,p_template=>3371237801798025892
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors:t-BadgeList--small:t-BadgeList--dash:t-BadgeList--cols'
,p_display_point=>'REGION_POSITION_02'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*select "CODE_FAMILLE",',
'    null link_class,',
'    apex_page.get_url(p_items => ''P12_CODE_FAMILLE'', p_values => "CODE_FAMILLE") link,',
'    null icon_class,',
'    null link_attr,',
'    null icon_color_class,',
'    case when nvl(:P12_CODE_FAMILLE,''0'') = "CODE_FAMILLE"',
'      then ''is-active'' ',
'      else '' ''',
'    end list_class,',
'    substr("LIBELLE_FAMILLE", 1, 10)||( case when length("LIBELLE_FAMILLE") > 10 then ''...'' end ) list_title,',
'    substr("CODE_FAMILLE", 1, 10)||( case when length("CODE_FAMILLE") > 10 then ''...'' end ) list_text,',
'    null list_badge',
'from "FAMILLE_PRODUIT" x',
'where x."ACTIF" =''O''',
'order by "CODE_FAMILLE"*/',
'',
'select code_famille ID,code_famille,',
'       libelle_famille',
'       from famille_produit',
'       where ACTIF =''O'''))
,p_header=>'  '
,p_lazy_loading=>false
,p_query_row_template=>2104643962563030528
,p_query_num_rows=>6
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81340251422375889)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>3
,p_column_link=>'#'
,p_column_linktext=>'#LIBELLE_FAMILLE#'
,p_column_link_attr=>'id=''#ID#'' class="famille " title=" "'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81340644315375890)
,p_query_column_id=>2
,p_column_alias=>'CODE_FAMILLE'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81340969325375890)
,p_query_column_id=>3
,p_column_alias=>'LIBELLE_FAMILLE'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(261541294102316057)
,p_name=>' produit type'
,p_template=>3371237801798025892
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-BadgeList--small:t-BadgeList--dash:t-BadgeList--cols'
,p_display_point=>'REGION_POSITION_02'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*select "CODE_TYPE_PRODUIT",',
'    null link_class,',
'    apex_page.get_url(p_items => ''P12_CODE_TYPE_PRODUIT'', p_values => "CODE_TYPE_PRODUIT") link,',
'    null icon_class,',
'    null link_attr,',
'    null icon_color_class,',
'    case when nvl(:P12_CODE_TYPE_PRODUIT,''0'') = "CODE_TYPE_PRODUIT"',
'      then ''is-active'' ',
'      else '' ''',
'    end list_class,',
'    substr("LIBELLE_TYPE_PRODUIT", 1, 50)||( case when length("LIBELLE_TYPE_PRODUIT") > 50 then ''...'' end ) list_title,',
'    substr("CODE_TYPE_PRODUIT", 1, 50)||( case when length("CODE_TYPE_PRODUIT") > 50 then ''...'' end ) list_text,',
'    null list_badge',
'from "TYPE_PRODUIT" x',
'where (:P12_SEARCH is null',
'        or upper(x."LIBELLE_TYPE_PRODUIT") like ''%''||upper(:P12_SEARCH)||''%''',
'        or upper(x."CODE_TYPE_PRODUIT") like ''%''||upper(:P12_SEARCH)||''%''',
'    )',
'and x."ACTIF" =''O''',
'and x."CODE_FAMILLE" = :P12_CODE_FAMILLE',
'order by "CODE_TYPE_PRODUIT"*/',
'',
'select code_type_produit ID,code_type_produit,',
'       LIBELLE_TYPE_PRODUIT',
'       from TYPE_PRODUIT',
'       where ACTIF =''O''',
'       and CODE_FAMILLE = :P12_FAMILLE',
'order by libelle_type_produit'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P12_CODE_FAMILLE,P12_FAMILLE'
,p_lazy_loading=>false
,p_query_row_template=>2104643962563030528
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81342094560375894)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>3
,p_column_link=>'#'
,p_column_linktext=>'#LIBELLE_TYPE_PRODUIT#'
,p_column_link_attr=>'id=''#ID#'' class="typeprd" title=" "'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81342469725375894)
,p_query_column_id=>2
,p_column_alias=>'CODE_TYPE_PRODUIT'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81342959602375895)
,p_query_column_id=>3
,p_column_alias=>'LIBELLE_TYPE_PRODUIT'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(261556730490316069)
,p_name=>'Produits'
,p_template=>4501440665235496320
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-BadgeList--small:t-BadgeList--dash:t-BadgeList--cols:t-Report--hideNoPagination'
,p_new_grid_row=>false
,p_grid_column_span=>6
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUM_PRODUIT ID,NUM_PRODUIT,',
'       DESIGNATION_PRODUIT,description',
'       from PRODUITS',
'where "CODE_TYPE_PRODUIT" = :P12_TYPE_PRODUIT',
'and actif = ''O''',
'order by designation_produit',
''))
,p_header=>'    <div title= "Produits" style="height:400px;overflow:scroll">    '
,p_footer=>'</div>  '
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P12_TYPE_PRODUIT'
,p_lazy_loading=>false
,p_query_row_template=>2104643962563030528
,p_query_num_rows=>1000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'Aucun produit pour ce type de produit'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_prn_format=>'PDF'
,p_prn_output_link_text=>'Print'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width_units=>'PERCENTAGE'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81344381820375900)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>3
,p_column_link=>'f?p=&APP_ID.:106:&SESSION.::&DEBUG.::P106_NUM_PRODUIT,P106_NUM_ESPACE:#ID#,&P12_NUM_ESPACE.'
,p_column_linktext=>'#DESIGNATION_PRODUIT#'
,p_column_link_attr=>'id=''#ID#'' class="affiche" title="#DESCRIPTION#"'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81344781610375901)
,p_query_column_id=>2
,p_column_alias=>'NUM_PRODUIT'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81345220854375901)
,p_query_column_id=>3
,p_column_alias=>'DESIGNATION_PRODUIT'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81345607443375903)
,p_query_column_id=>4
,p_column_alias=>'DESCRIPTION'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(261599945654224033)
,p_plug_name=>'Bon'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'REGION_POSITION_08'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(261600882004224042)
,p_name=>unistr('D\00E9tailsbon')
,p_template=>4501440665235496320
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select d.ROWID,d.num_detail_bon ID,d.num_detail_bon,d.num_bon,substr(designation_produit,1,30) ||( case when length(designation_produit) > 30 then ''...'' end ) designation_produit,d.qte_bon,d.pu_bon,d.code_utilisateur,d.livre,d.total ',
'from details_bon_temp d,produits p',
'where d.num_produit = p.num_produit',
'and trim(d.util_modif) = trim(v(''app_user''))',
'order by d.num_detail_bon;'))
,p_header=>'   <div style="height:400px;overflow:scroll"> '
,p_footer=>'</div>  '
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P12_NUM_VACATION'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>1000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81355010569375925)
,p_query_column_id=>1
,p_column_alias=>'ROWID'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81355436401375925)
,p_query_column_id=>2
,p_column_alias=>'ID'
,p_column_display_sequence=>11
,p_column_heading=>'Suppr.'
,p_column_link=>'#'
,p_column_linktext=>'<span class="t-Icon fa fa-trash-o" aria-hidden="true"></span>'
,p_column_link_attr=>'id=''#ID#'' class="delete t-Button t-Button--danger t-Button--simple t-Button--small" title="Supprimer : #DESIGNATION_PRODUIT#"'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81355810350375926)
,p_query_column_id=>3
,p_column_alias=>'NUM_DETAIL_BON'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81356258292375928)
,p_query_column_id=>4
,p_column_alias=>'NUM_BON'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81356659746375929)
,p_query_column_id=>5
,p_column_alias=>'DESIGNATION_PRODUIT'
,p_column_display_sequence=>6
,p_column_heading=>'Designation '
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span style="display:block; width:300px"><h5>#DESIGNATION_PRODUIT#</h5></span>',
''))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81357036782375929)
,p_query_column_id=>6
,p_column_alias=>'QTE_BON'
,p_column_display_sequence=>7
,p_column_heading=>'Qte '
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_html_expression=>'<span style="display:block; width:40px"><h5>#QTE_BON#</h5></span>'
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81357455534375931)
,p_query_column_id=>7
,p_column_alias=>'PU_BON'
,p_column_display_sequence=>8
,p_column_heading=>'Pu '
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_html_expression=>'<span style="display:block; width:70px"><h5>#PU_BON#</h5></span>'
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81357848896375931)
,p_query_column_id=>8
,p_column_alias=>'CODE_UTILISATEUR'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81358242799375933)
,p_query_column_id=>9
,p_column_alias=>'LIVRE'
,p_column_display_sequence=>9
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81358659342375933)
,p_query_column_id=>10
,p_column_alias=>'TOTAL'
,p_column_display_sequence=>10
,p_column_heading=>'Total'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span style="display:block; width:90px"><h5>#TOTAL#</h5></span>',
''))
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81347103999375908)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(261599945654224033)
,p_button_name=>'Sortie_stock'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary:t-Button--gapLeft'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Sortie stock'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:121:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81347530880375908)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(261599945654224033)
,p_button_name=>'OperationsC'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary:t-Button--gapLeft'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>unistr('Op\00E9rations de caisse')
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:104:&SESSION.::&DEBUG.::P104_NUM_VAC:&P12_NUM_VACATION.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81347956667375909)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(261599945654224033)
,p_button_name=>'RefreshEncours'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary:t-Button--gapLeft'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>unistr('Rafra\00EEchir')
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81348264436375911)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(261599945654224033)
,p_button_name=>'Effacer'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Effacer'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81348709485375911)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(261599945654224033)
,p_button_name=>'Don'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Don'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:77:&SESSION.::&DEBUG.:RP:P77_NUM_BON,P77_QTE:&P12_NUM_BON.,0'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81349130060375911)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(261599945654224033)
,p_button_name=>'Enregistrer'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Enregistrer'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81349464790375912)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(261599945654224033)
,p_button_name=>'Imprimer'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary:t-Button--gapLeft'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Imprimer'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:82:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81349890922375912)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(261599945654224033)
,p_button_name=>'Regler'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Regler'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.:RP,6:P6_MT_ARRONDI,P6_RELIQUAT,P6_ARRONDI,P6_MONTANT_REMISE:&P12_ZERO.,&P12_ZERO.,&P12_ZERO.,&P12_ZERO.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81350311267375914)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_imp.id(261599945654224033)
,p_button_name=>'Cloture'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary:t-Button--gapLeft'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cloture'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:86:&SESSION.::&DEBUG.:RP,86:P86_NUM_VACATION:&P12_NUM_VACATION.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81341435563375890)
,p_name=>'P12_CODE_FAMILLE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(261539216039316055)
,p_use_cache_before_default=>'NO'
,p_item_default=>'6'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81343328370375897)
,p_name=>'P12_FAMILLE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(261541294102316057)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81343704718375897)
,p_name=>'P12_TYPEPRD'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(261541294102316057)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81346013148375904)
,p_name=>'P12_NUM_PRD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(261556730490316069)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81346375350375906)
,p_name=>'P12_TYPE_PRODUIT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(261556730490316069)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81350683805375915)
,p_name=>'P12_NUM_BON'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(261599945654224033)
,p_prompt=>unistr('N\00B0Bon')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81351137433375915)
,p_name=>'P12_CLIENT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(261599945654224033)
,p_item_default=>'1'
,p_prompt=>'Client'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'CLIENT'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nom_clt as d,',
'       num_clt as r',
'  from client',
' order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81351479369375917)
,p_name=>'P12_SURPLACE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(261599945654224033)
,p_use_cache_before_default=>'NO'
,p_item_default=>'S'
,p_prompt=>'Surp/Emporter'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'SURPLACE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select LIBELLE as d,',
'       CODE_TYPE_CONSO as r',
'  from type_conso',
' order by 1'))
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81351910008375917)
,p_name=>'P12_TABLE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(261599945654224033)
,p_item_default=>'1'
,p_prompt=>unistr('N\00B0Table')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TABLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select num_table as d,',
'       num_table as r',
'  from tables',
' order by 1'))
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81352358104375919)
,p_name=>'P12_TICKET'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(261599945654224033)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('R\00E9f\00E9rence')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81352714618375919)
,p_name=>'P12_NBPERS'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(261599945654224033)
,p_use_cache_before_default=>'NO'
,p_item_default=>'1'
,p_prompt=>'Nb Pers.'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TABLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select num_table as d,',
'       num_table as r',
'  from tables',
' order by 1'))
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81353134952375919)
,p_name=>'P12_ZERO'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(261599945654224033)
,p_item_default=>'0'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81353460654375920)
,p_name=>'P12_MODIF'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(261599945654224033)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81353942254375922)
,p_name=>'P12_VERIF'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(261599945654224033)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81354335841375923)
,p_name=>'P12_VERIF_REF'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(261599945654224033)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81359013489375934)
,p_name=>'12_P20_DELETE_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(261600882004224042)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81359417498375934)
,p_name=>'P12_TOTAL'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(261600882004224042)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81359794118375936)
,p_name=>'P12_TOTAL_AFF'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(261600882004224042)
,p_prompt=>'Total '
,p_format_mask=>'FML999G999G999G999G990D00'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'Style="text-align: right; font-size: 30px;font-weight: bold"'
,p_colspan=>12
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81360527988375937)
,p_name=>'P12_DATE_VACATION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(233046040465873240)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Date '
,p_format_mask=>'DD/MM/YYYY'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.DATEHEURE_DEBUT_VAC ',
'from vacation v,affectation a,personnel p',
'where v.num_espace_vente = a.num_espace_vente',
'and a.matricule = p.matricule',
'and cloture = ''N''',
'and trim(p.profil_app) = trim(nvl(v(''app_user''), user));'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81360930398375939)
,p_name=>'P12_PV'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(233046040465873240)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Point de vente'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pv.nom_point_vente',
'from affectation a,personnel p,espace_vente e,point_vente pv',
'where a.matricule = p.matricule',
'and a.num_espace_vente = e.num_espace_vente',
'and e.num_point_vente = pv.num_point_vente',
'and trim(profil_app) = nvl(v(''app_user''), user);'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81361344990375940)
,p_name=>'P12_ESPACE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(233046040465873240)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Espace de vente'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.nom_espace',
'from affectation a,personnel p,espace_vente e',
'where a.matricule = p.matricule',
'and a.num_espace_vente = e.num_espace_vente',
'and trim(profil_app) = nvl(v(''app_user''), user);'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81361753876375942)
,p_name=>'P12_USER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(233046040465873240)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Utilisateur'
,p_source=>'select v(''app_user'') from dual;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81362122500375942)
,p_name=>'P12_NUM_PV'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(233046040465873240)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.num_point_vente',
'from affectation a,personnel p,espace_vente e',
'where a.matricule = p.matricule',
'and a.num_espace_vente = e.num_espace_vente',
'and trim(profil_app) = nvl(v(''app_user''), user);'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81362498623375944)
,p_name=>'P12_NUMESPACE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(233046040465873240)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.num_espace_vente',
'from affectation a,personnel p,espace_vente e',
'where a.matricule = p.matricule',
'and a.num_espace_vente = e.num_espace_vente',
'and trim(profil_app) = nvl(v(''app_user''), user);'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81362957781375944)
,p_name=>'P12_NUM_VACATION'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(233046040465873240)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('N\00B0 Vacation')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select num_vacation',
'from vacation',
'where  num_point_vente = :p12_num_pv',
'and num_espace_vente = :P12_NUMESPACE',
'and cloture = ''N'';'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81363278888375945)
,p_name=>'P12_NOUVEAU'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(233046040465873240)
,p_use_cache_before_default=>'NO'
,p_item_default=>'3'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81369255363375959)
,p_name=>'P12_NUM_BON_TEMP'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(234366762718593963)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81369570080375959)
,p_name=>'P12_NUM_ESPACE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(234366762718593963)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.num_espace_vente',
'from vacation v',
'where to_char(DATEHEURE_DEBUT_VAC,''ddmmyyyy'') = to_char(sysdate,''ddmmyyyy'')',
'and trim(v.code_utilisateur) = trim(nvl(v(''app_user''), user));'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81405179767376009)
,p_name=>'Refresh on Dialog Close'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(261556730490316069)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81405721306376009)
,p_event_id=>wwv_flow_imp.id(81405179767376009)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(261556730490316069)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81406234410376009)
,p_event_id=>wwv_flow_imp.id(81405179767376009)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(261600882004224042)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81406684131376009)
,p_event_id=>wwv_flow_imp.id(81405179767376009)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if nvl(:P12_NUM_BON,0) =0 then',
'    select sum(nvl(qte_bon,0)*nvl(pu_bon,0)) into :P12_TOTAL from details_bon_temp',
'    where trim(util_modif) = nvl(v(''app_user''), user);',
'else ',
'    select sum(nvl(qte_bon,0)*nvl(pu_bon,0)) into :P12_TOTAL from details_bon_temp',
'     where num_bon = :P12_NUM_BON;',
'end if;'))
,p_attribute_02=>'P12_TOTAL,P12_NUM_BON'
,p_attribute_03=>'P12_TOTAL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81407095316376011)
,p_name=>'SUPPDETBON'
,p_event_sequence=>180
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'a.delete'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81407648550376011)
,p_event_id=>wwv_flow_imp.id(81407095316376011)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Etes vous s&#xFB;r de vouloir supprimer cette ligne?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81408094525376011)
,p_event_id=>wwv_flow_imp.id(81407095316376011)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P20_DELETE_ID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.id'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81408593529376011)
,p_event_id=>wwv_flow_imp.id(81407095316376011)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'nb number;',
'begin',
'  ',
'      select nvl(count(*),0) into nb from details_bon_temp',
'      where num_bon = :p12_num_bon',
'      and trim(util_modif) = trim(v(''app_user''));',
'      delete from details_bon_temp',
'      where num_detail_bon = :P20_DELETE_ID',
'      and trim(util_modif) = trim(v(''app_user''));',
'      if nvl(:p12_num_bon,0) > 0 then',
'          ',
'          delete from details_bon',
'          where num_detail_bon = :P20_DELETE_ID and num_bon = :p12_num_bon ;',
'          if nb = 1 then',
'             update bons set code_etat_bon = 3',
'             where num_bon = :p12_num_bon ;',
'          end if;',
'       end if;',
'  ',
'  commit;',
'  select sum(nvl(qte_bon,0)*nvl(pu_bon,0)) into :P12_TOTAL from details_bon_temp',
'  where trim(util_modif)=trim(v(''app_user''));',
'',
'end;',
'  '))
,p_attribute_02=>'P20_DELETE_ID,P12_NUM_BON,P12_TOTAL'
,p_attribute_03=>'P12_TOTAL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81409142791376012)
,p_event_id=>wwv_flow_imp.id(81407095316376011)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(261600882004224042)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81409517697376012)
,p_name=>'SUPPBON'
,p_event_sequence=>190
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'a.deleteB'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81409992868376012)
,p_event_id=>wwv_flow_imp.id(81409517697376012)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Etes vous s&#xFB;r de vouloir annuler ce bon?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81410482884376012)
,p_event_id=>wwv_flow_imp.id(81409517697376012)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_NUM_BON_TEMP'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.id'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81411059613376012)
,p_event_id=>wwv_flow_imp.id(81409517697376012)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_bon is select code_etat_bon from bons',
'where num_bon = :P12_NUM_BON_TEMP;',
'r_bon c_bon%rowtype;',
'',
'nb number;',
'begin',
'open c_bon;',
'  fetch c_bon into r_bon;',
'  if c_bon%found then',
'    if r_bon.code_etat_bon = 1 then',
'     update bons set code_etat_bon = 3',
'     where num_bon = :P12_NUM_BON_TEMP; ',
'    end if;',
'   end if;',
'   close c_bon;',
'end;',
'  '))
,p_attribute_02=>'P12_NUM_BON_TEMP'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81411527069376014)
,p_event_id=>wwv_flow_imp.id(81409517697376012)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(234366762718593963)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81411868324376014)
,p_name=>'AffBons'
,p_event_sequence=>200
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'a.affbons'
,p_condition_element=>'P12_NUM_BON'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81412430275376014)
,p_event_id=>wwv_flow_imp.id(81411868324376014)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Veuillez effacer le bon courant avant!'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81412885568376014)
,p_event_id=>wwv_flow_imp.id(81411868324376014)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_NUM_BON_TEMP'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.id'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81413399572376015)
,p_event_id=>wwv_flow_imp.id(81411868324376014)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'cursor c_bon is select code_etat_bon from bons',
'where num_bon = :P12_NUM_BON_TEMP;',
'r_bon c_bon%rowtype;',
'',
'begin',
' if nvl(:p12_num_bon,0) != 0 then',
'    update bons set code_etat_bon = 1',
'    where num_bon = :p12_num_bon;',
'  end if;',
'',
'  open c_bon;',
'  fetch c_bon into r_bon;',
'  if c_bon%found then',
'    if r_bon.code_etat_bon = 1 then',
'          delete details_bon_temp  where trim(util_modif) = v(''app_user'');',
'          insert into details_bon_temp',
'          select NUM_DETAIL_BON,NUM_PRODUIT ,NUM_BON,QTE_BON,PU_BON,QTE_RETOURNE,QTE_CONSIGNE,ETAT_DETAIL_BON,',
'            v(''app_user'') ,DATE_CREATION ,LIVRE,TYPE_DETAIL_BON,NUM_MENU,QTE_BON*PU_BON,v(''app_user'')',
'            from details_bon',
'          where num_bon = :P12_NUM_BON_TEMP;',
'',
'            update bons set code_etat_bon = 2,montant_bon = (select sum(qte_bon*pu_bon) from details_bon  where num_bon = :P12_NUM_BON_TEMP )',
'            where num_bon = :P12_NUM_BON_TEMP;',
'',
'          :p12_num_bon := :P12_NUM_BON_TEMP;',
'',
'           select num_clt,num_table,code_traitement,CONSIGATION,num_ticket into :p12_client,:p12_table,:p12_surplace,:p12_nbpers,:p12_ticket',
'          from bons',
'          where num_bon = :P12_NUM_BON_TEMP;',
'          :P12_modif := 0;',
'    else',
'          :p12_modif :=1;',
'    end if;',
'  end if;',
'  close c_bon;',
'      ',
'      --:p12_nouveau := 0;',
'      ',
'             commit;',
'',
'end;',
'  '))
,p_attribute_02=>'P12_NUM_BON_TEMP,P12_NOUVEAU,P12_CLIENT,P12_TABLE,P12_SURPLACE,P12_NBPERS,P12_NUM_BON,P12_TICKET,P12_MODIF'
,p_attribute_03=>'P12_NUM_BON,P12_CLIENT,P12_SURPLACE,P12_NBPERS,P12_TABLE,P12_NOUVEAU,P12_TICKET,P12_MODIF'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81413867708376015)
,p_event_id=>wwv_flow_imp.id(81411868324376014)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nvl(sum(pu_bon*qte_bon),0) into :P12_TOTAL from details_bon_temp',
'where trim(util_modif) = trim(v(''app_user''));'))
,p_attribute_02=>'P12_TOTAL'
,p_attribute_03=>'P12_TOTAL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81414377876376015)
,p_event_id=>wwv_flow_imp.id(81411868324376014)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(261600882004224042)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81414951017376015)
,p_event_id=>wwv_flow_imp.id(81411868324376014)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(234366762718593963)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81415301794376017)
,p_name=>'CreerBon'
,p_event_sequence=>210
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'a.affiche'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81415852897376017)
,p_event_id=>wwv_flow_imp.id(81415301794376017)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_NUM_PRD'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.id'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81416265128376017)
,p_event_id=>wwv_flow_imp.id(81415301794376017)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_bon is select * from bons_temp',
'where trim(code_utilisateur) = trim(nvl(v(''app_user''), user));',
'',
'r_bon c_bon%rowtype;',
'',
'',
'begin',
'    open c_bon;',
'    fetch c_bon into r_bon;',
'    if c_bon%notfound then',
'       insert into bons_temp',
'       values(:p12_num_bon/*NUM_BON*/ ,:p12_table/*NUM_TABLE*/,:p12_client/*NUM_CLT*/,:p12_num_espace/*NUM_ESPACE_VENTE*/,',
'              :p12_num_vacation/*NUM_VACATION*/,:p12_total/*MONTANT_BON*/,:p12_surplace/*CODE_TRAITEMENT*/,v(''app_user''),:p12_nbpers);',
'    end if;',
'    close c_bon;',
'    :P12_NOUVEAU:=3;',
'end;',
'       '))
,p_attribute_02=>'P12_NOUVEAU,P12_NUM_BON,P12_CLIENT,P12_SURPLACE,P12_NBPERS'
,p_attribute_03=>'P12_TOTAL,P12_NOUVEAU'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81416766494376017)
,p_event_id=>wwv_flow_imp.id(81415301794376017)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(261600882004224042)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81417185672376019)
,p_name=>'Effacer'
,p_event_sequence=>220
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(81348264436375911)
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81417756404376019)
,p_event_id=>wwv_flow_imp.id(81417185672376019)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  if nvl(:p12_num_bon,0) != 0 then',
'    update bons set code_etat_bon = 1',
'    where num_bon = :p12_num_bon;',
'  end if;',
'   ',
'   delete bons_temp',
'    where trim(code_utilisateur) = nvl(v(''app_user''), user);',
'    delete details_bon_temp',
'    where trim(util_modif) = nvl(v(''app_user''), user);',
'    commit;',
'',
'',
'    commit;',
'    select 0 into :P12_TOTAL  from dual;',
'    select null into :P12_NUM_BON  from dual;',
'',
'   ',
'    :P12_NOUVEAU :=3;',
'  '))
,p_attribute_02=>'P12_TOTAL,P12_NUM_BON,P12_NOUVEAU'
,p_attribute_03=>'P12_TOTAL,P12_NUM_BON,P12_NOUVEAU'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81418241849376019)
,p_event_id=>wwv_flow_imp.id(81417185672376019)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(261600882004224042)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81418697637376019)
,p_event_id=>wwv_flow_imp.id(81417185672376019)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(234366762718593963)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81419220395376020)
,p_event_id=>wwv_flow_imp.id(81417185672376019)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_CLIENT'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81419745742376020)
,p_event_id=>wwv_flow_imp.id(81417185672376019)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_TABLE'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81420193496376020)
,p_event_id=>wwv_flow_imp.id(81417185672376019)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_NBPERS'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81420699084376020)
,p_event_id=>wwv_flow_imp.id(81417185672376019)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_SURPLACE'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'S'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81421130313376020)
,p_name=>'majbontemp'
,p_event_sequence=>230
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(81349130060375911)
,p_condition_element=>'P12_VERIF_REF'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'0'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81421560510376022)
,p_event_id=>wwv_flow_imp.id(81421130313376020)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Veuillez renseigner la r&#xE9;f&#xE9;rence pour le bon &#xE0; emporter !'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81422109927376022)
,p_event_id=>wwv_flow_imp.id(81421130313376020)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete bons_temp;',
'insert into bons_temp values(:P12_NUM_BON,:p12_table,:p12_client,:P12_NUM_PV,:p12_nbpers,:p12_total,:p12_surplace,v(''app_user''),0);',
'commit;',
'',
'declare',
'',
'cursor c_bon is select nvl(num_bon,0) num_bon from details_bon_temp',
'where trim(code_utilisateur) = nvl(v(''app_user''), user);',
'',
'r_bon c_bon%rowtype;',
'',
'numbon number;',
'mat number := fn_matricule(v(''app_user''));',
'',
'begin',
'      if nvl(:P12_TOTAL,0) > 0 then',
'               if nvl(:P12_NUM_BON,0) = 0 then',
'                   select BONS_NUM_BON_SEQ.nextval into numbon from dual;',
'                   insert into bons ',
'                   values(numbon/*NUM_BON*/ ,1/*CODE_ETAT_BON*/,:P12_TABLE/*NUM_TABLE*/,:P12_CLIENT/*NUM_CLT*/,:p12_ticket/*NUM_TICKET*/,',
'                          mat/*MATRICULE*/,null/*NUM_FACTURE*/,:P12_NUMESPACE/*NUM_ESPACE_VENTE*/,     ',
'                          NULL/*NUM_CMDE_CLT*/,:P12_NUM_VACATION/*NUM_VACATION*/,:p12_date_vacation/*DATE_BON*/,:P12_TOTAL/*MONTANT_BON*/,',
'                          null/*MONTANT_CONSIGNATION*/,''N''/*LIVRE*/,''N''/*PAYE*/,''N''/*FACTURE*/,',
'                          :P12_NBPERS/*CONSIGATION*/,null/*OBSERVATION*/,:P12_SURPLACE/*CODE_TRAITEMENT*/,nvl(v(''app_user''), user)/*CODE_UTILISATEUR*/,sysdate/*DATE_CREATION*/,1,null);',
'                   insert into details_bon select NUM_DETAIL_BON,NUM_PRODUIT,numbon,QTE_BON,PU_BON,QTE_RETOURNE,QTE_CONSIGNE,ETAT_DETAIL_BON,  ',
'                    CODE_UTILISATEUR,DATE_CREATION,LIVRE,TYPE_DETAIL_BON,NUM_MENU',
'                    from details_bon_temp',
'                    where trim(util_modif) = trim(nvl(v(''app_user''), user));',
'                    delete details_bon_temp',
'                    where trim(util_modif) = trim(nvl(v(''app_user''), user));',
'                else',
'                     update bons',
'                     set num_table = :P12_TABLE,num_clt = :P12_CLIENT,num_espace_vente = :P12_NUMESPACE,code_utilisateur =v(''app_user''),',
'                     num_vacation = :P12_NUM_VACATION,montant_bon = :P12_TOTAL,code_traitement = :P12_SURPLACE,code_etat_bon = 1,num_ticket =:p12_ticket,consigation = :P12_NBPERS ',
'                     where num_bon = :P12_NUM_BON;',
'                     delete details_bon',
'                     where num_bon = :P12_NUM_BON;',
'                     insert into details_bon select NUM_DETAIL_BON,NUM_PRODUIT,:P12_NUM_BON,QTE_BON,PU_BON,QTE_RETOURNE,QTE_CONSIGNE,ETAT_DETAIL_BON,  ',
'                     v(''app_user''),DATE_CREATION,LIVRE,TYPE_DETAIL_BON,NUM_MENU',
'                     from details_bon_temp',
'                     where trim(util_modif) = trim(nvl(v(''app_user''), user));',
'                     delete details_bon_temp',
'                     where trim(util_modif) = trim(nvl(v(''app_user''), user));',
'                end if;',
'            end if;',
'       ',
'       commit;',
'       :P12_TOTAL :=0;:P12_NOUVEAU :=3;',
'end;',
'       ',
'                  '))
,p_attribute_02=>'P12_NUM_BON_TEMP,P12_TABLE,P12_CLIENT,P12_NBPERS,P12_TOTAL,P12_SURPLACE,P12_NUM_BON,P12_NOUVEAU,P12_DATE_VACATION,P12_NUM_VACATION,P12_TICKET,P12_NUMESPACE'
,p_attribute_03=>'P12_NUM_BON,P12_NOUVEAU'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81422631620376022)
,p_event_id=>wwv_flow_imp.id(81421130313376020)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Bon enregistr&#xE9; avec succ&#xE8;s'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81423105559376023)
,p_event_id=>wwv_flow_imp.id(81421130313376020)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(261600882004224042)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81423626819376023)
,p_event_id=>wwv_flow_imp.id(81421130313376020)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(234366762718593963)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81424139024376023)
,p_event_id=>wwv_flow_imp.id(81421130313376020)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_TOTAL'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'0'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81424624355376023)
,p_event_id=>wwv_flow_imp.id(81421130313376020)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_NUM_BON'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81425133031376025)
,p_event_id=>wwv_flow_imp.id(81421130313376020)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_CLIENT'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81425606074376025)
,p_event_id=>wwv_flow_imp.id(81421130313376020)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_TABLE'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81426083314376025)
,p_event_id=>wwv_flow_imp.id(81421130313376020)
,p_event_result=>'TRUE'
,p_action_sequence=>90
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_SURPLACE'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'S'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81426569341376025)
,p_event_id=>wwv_flow_imp.id(81421130313376020)
,p_event_result=>'TRUE'
,p_action_sequence=>100
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_NBPERS'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81427029642376026)
,p_name=>'GestbuttonNouveau1'
,p_event_sequence=>260
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P12_NOUVEAU'
,p_condition_element=>'P12_NOUVEAU'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81427494479376026)
,p_event_id=>wwv_flow_imp.id(81427029642376026)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(81349130060375911)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81427992349376026)
,p_event_id=>wwv_flow_imp.id(81427029642376026)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(81348709485375911)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81428516539376028)
,p_event_id=>wwv_flow_imp.id(81427029642376026)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(81349890922375912)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81370691414375964)
,p_name=>'GestbuttonNouveau3'
,p_event_sequence=>270
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P12_NOUVEAU'
,p_condition_element=>'P12_NOUVEAU'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'3'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81371234155375965)
,p_event_id=>wwv_flow_imp.id(81370691414375964)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(81349130060375911)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81371690730375967)
,p_event_id=>wwv_flow_imp.id(81370691414375964)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(81349890922375912)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81372083149375967)
,p_name=>'GestbuttonNouveau0'
,p_event_sequence=>280
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P12_NOUVEAU'
,p_condition_element=>'P12_NOUVEAU'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'0'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81372580288375969)
,p_event_id=>wwv_flow_imp.id(81372083149375967)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(81348709485375911)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81373129594375969)
,p_event_id=>wwv_flow_imp.id(81372083149375967)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(81349130060375911)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81373572637375970)
,p_event_id=>wwv_flow_imp.id(81372083149375967)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(81349890922375912)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81374027522375970)
,p_name=>'GestBoutonTotal'
,p_event_sequence=>290
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P12_TOTAL'
,p_condition_element=>'P12_TOTAL'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'0'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81374516064375970)
,p_event_id=>wwv_flow_imp.id(81374027522375970)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'begin',
'    if nvl(:P12_NUM_BON,0)=0 then',
'          :p12_nouveau := 1;',
'    else',
'           if :p12_nouveau = 3 then',
'                 :p12_nouveau :=0;',
'           else',
'                 :p12_nouveau :=1;',
'           end if;',
'    end if;',
' end;'))
,p_attribute_02=>'P12_NUM_BON,P12_NOUVEAU'
,p_attribute_03=>'P12_NOUVEAU'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81374970100375972)
,p_event_id=>wwv_flow_imp.id(81374027522375970)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(81349130060375911)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81375546670375972)
,p_event_id=>wwv_flow_imp.id(81374027522375970)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(81349464790375912)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81376002179375973)
,p_event_id=>wwv_flow_imp.id(81374027522375970)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(81349464790375912)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81376497232375973)
,p_event_id=>wwv_flow_imp.id(81374027522375970)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'select to_char(:p12_total,''999G999G999G999G990'') || '' FCFA'' into :p12_total_aff from dual;'
,p_attribute_02=>'P12_TOTAL,P12_TOTAL_AFF'
,p_attribute_03=>'P12_TOTAL_AFF'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81376970999375973)
,p_event_id=>wwv_flow_imp.id(81374027522375970)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'select to_char(:p12_total,''999G999G999G999G990'') || '' FCFA'' into :p12_total_aff from dual;'
,p_attribute_02=>'P12_TOTAL,P12_TOTAL_AFF'
,p_attribute_03=>'P12_TOTAL_AFF'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81377418576375975)
,p_name=>'RefreshREgler'
,p_event_sequence=>300
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(81349890922375912)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81377909539375975)
,p_event_id=>wwv_flow_imp.id(81377418576375975)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(261600882004224042)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81378422419375975)
,p_event_id=>wwv_flow_imp.id(81377418576375975)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(261600882004224042)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81378937561375976)
,p_event_id=>wwv_flow_imp.id(81377418576375975)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(234366762718593963)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81379369165375976)
,p_event_id=>wwv_flow_imp.id(81377418576375975)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_TOTAL'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'0'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81379862470375978)
,p_event_id=>wwv_flow_imp.id(81377418576375975)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_NUM_BON'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81380442806375978)
,p_event_id=>wwv_flow_imp.id(81377418576375975)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_CLIENT'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81380935567375979)
,p_event_id=>wwv_flow_imp.id(81377418576375975)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_CLIENT,P12_TABLE'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81381425746375979)
,p_event_id=>wwv_flow_imp.id(81377418576375975)
,p_event_result=>'TRUE'
,p_action_sequence=>90
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_SURPLACE'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'S'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81381928730375979)
,p_event_id=>wwv_flow_imp.id(81377418576375975)
,p_event_result=>'TRUE'
,p_action_sequence=>100
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_NBPERS'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81382444202375981)
,p_event_id=>wwv_flow_imp.id(81377418576375975)
,p_event_result=>'TRUE'
,p_action_sequence=>110
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_NOUVEAU'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'3'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81382791775375981)
,p_name=>'RefreshdetailsDon'
,p_event_sequence=>310
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(81348709485375911)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81383261759375981)
,p_event_id=>wwv_flow_imp.id(81382791775375981)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(261600882004224042)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81383765155375983)
,p_event_id=>wwv_flow_imp.id(81382791775375981)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_NOUVEAU'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81384176024375983)
,p_name=>'Famille'
,p_event_sequence=>320
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'a.famille'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81384681338375983)
,p_event_id=>wwv_flow_imp.id(81384176024375983)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_CODE_FAMILLE'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.id'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81385148417375984)
,p_name=>'AffectationPcodefamille'
,p_event_sequence=>330
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P12_CODE_FAMILLE'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81385570965375984)
,p_event_id=>wwv_flow_imp.id(81385148417375984)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
':p12_famille := :p12_code_famille;',
'select code_type_produit into :P12_TYPE_PRODUIT from type_produit',
'where code_famille = :p12_code_famille',
'and rownum = 1;',
'end;'))
,p_attribute_02=>'P12_CODE_FAMILLE,P12_FAMILLE,P12_TYPEPRD,P12_TYPE_PRODUIT'
,p_attribute_03=>'P12_FAMILLE,P12_TYPE_PRODUIT'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81386078549375986)
,p_event_id=>wwv_flow_imp.id(81385148417375984)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(261541294102316057)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81386478332375986)
,p_name=>'TYPEPRDPRD'
,p_event_sequence=>340
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'a.typeprd'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81387018218375986)
,p_event_id=>wwv_flow_imp.id(81386478332375986)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_TYPE_PRODUIT'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.id'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81387502653375987)
,p_event_id=>wwv_flow_imp.id(81386478332375986)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(261556730490316069)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81387947312375987)
,p_name=>'REfreshPrd'
,p_event_sequence=>350
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P12_TYPEPRD'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81388375032375987)
,p_event_id=>wwv_flow_imp.id(81387947312375987)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(261556730490316069)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81388826230375989)
,p_name=>'SurplaceChange'
,p_event_sequence=>360
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P12_SURPLACE'
,p_condition_element=>'P12_SURPLACE'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'E'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81389275435375989)
,p_event_id=>wwv_flow_imp.id(81388826230375989)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_NBPERS'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81389824068375990)
,p_event_id=>wwv_flow_imp.id(81388826230375989)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_NBPERS'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81390293072375990)
,p_event_id=>wwv_flow_imp.id(81388826230375989)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_TICKET'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81390811393375990)
,p_event_id=>wwv_flow_imp.id(81388826230375989)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_TICKET'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81391303212375992)
,p_event_id=>wwv_flow_imp.id(81388826230375989)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_TICKET'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81391844968375992)
,p_event_id=>wwv_flow_imp.id(81388826230375989)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_TABLE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81392314007375994)
,p_event_id=>wwv_flow_imp.id(81388826230375989)
,p_event_result=>'FALSE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_TABLE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81392843045375995)
,p_event_id=>wwv_flow_imp.id(81388826230375989)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P12_VERIF_REF :=0;',
'if :P12_SURPLACE = ''E'' and nvl(:P12_TICKET,''0'') =''0''  then',
'    :P12_VERIF_REF :=1;',
'end if;'))
,p_attribute_02=>'P12_SURPLACE,P12_TICKET,P12_VERIF_REF'
,p_attribute_03=>'P12_VERIF_REF'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81393253294375995)
,p_name=>'ClearAll'
,p_event_sequence=>370
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(81350311267375914)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81393687537375995)
,p_event_id=>wwv_flow_imp.id(81393253294375995)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(261556730490316069)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81394252316375997)
,p_event_id=>wwv_flow_imp.id(81393253294375995)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(234366762718593963)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81394640865375997)
,p_name=>'Init code famille'
,p_event_sequence=>380
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexbeforepagesubmit'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81395152471375998)
,p_event_id=>wwv_flow_imp.id(81394640865375997)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_CODE_FAMILLE'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'6'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81395596352375998)
,p_event_id=>wwv_flow_imp.id(81394640865375997)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(261556730490316069)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81396088648376000)
,p_event_id=>wwv_flow_imp.id(81394640865375997)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_TYPEPRD'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'17'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81396654317376000)
,p_event_id=>wwv_flow_imp.id(81394640865375997)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(261556730490316069)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81397046987376000)
,p_name=>'Inittypeprd'
,p_event_sequence=>390
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexbeforepagesubmit'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81397481362376001)
,p_event_id=>wwv_flow_imp.id(81397046987376000)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_TYPEPRD'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'17'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81398012126376001)
,p_event_id=>wwv_flow_imp.id(81397046987376000)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_TYPEPRD'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'17'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81398387042376001)
,p_name=>'refreshDetailBon'
,p_event_sequence=>400
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(261600882004224042)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81398931982376003)
,p_event_id=>wwv_flow_imp.id(81398387042376001)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(261600882004224042)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81399315281376003)
,p_name=>'RefreshProduits'
,p_event_sequence=>410
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P12_TYPE_PRODUIT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81399785993376003)
,p_event_id=>wwv_flow_imp.id(81399315281376003)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(261556730490316069)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81400220534376004)
,p_name=>'initTotal'
,p_event_sequence=>420
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81400702792376004)
,p_event_id=>wwv_flow_imp.id(81400220534376004)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_TOTAL'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'0'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81401217289376004)
,p_event_id=>wwv_flow_imp.id(81400220534376004)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P12_NOUVEAU'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'3'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81401654683376006)
,p_name=>'RefreshEncoursDA'
,p_event_sequence=>430
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(81347956667375909)
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81402103519376006)
,p_event_id=>wwv_flow_imp.id(81401654683376006)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update bons set code_etat_bon = 1 ',
'where code_etat_bon = 2 and num_bon  not in (select num_bon from details_bon_temp);',
''))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81402599928376006)
,p_event_id=>wwv_flow_imp.id(81401654683376006)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(234366762718593963)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81403046931376008)
,p_name=>'RefreshRecu'
,p_event_sequence=>440
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P12_NUM_BON'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81403417908376008)
,p_name=>'BonEnModif'
,p_event_sequence=>450
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P12_MODIF'
,p_condition_element=>'P12_MODIF'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81403899991376008)
,p_event_id=>wwv_flow_imp.id(81403417908376008)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Bon actuellement en modification !'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81404291415376008)
,p_name=>'verifREf'
,p_event_sequence=>460
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P12_TICKET'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81404853330376008)
,p_event_id=>wwv_flow_imp.id(81404291415376008)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P12_VERIF_REF :=0;',
'if :P12_SURPLACE = ''E'' and nvl(:P12_TICKET,''0'') =''0''  then',
'    :P12_VERIF_REF :=1;',
'end if;'))
,p_attribute_02=>'P12_SURPLACE,P12_TICKET,P12_VERIF_REF'
,p_attribute_03=>'P12_VERIF_REF'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(81369966749375962)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SuppDetBtemp'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update bons set code_etat_bon = 1 where num_bon in (select num_bon from details_bon_temp',
'                                                   where trim(util_modif) = trim(nvl(v(''app_user''), user))) ; ',
'delete details_bon_temp where trim(util_modif) = trim(nvl(v(''app_user''), user));',
'commit;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>81369966749375962
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(81370264913375964)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SupprimerDetail_temp'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nvl(NUM_BON,null) ,nvl(NUM_TABLE,1),nvl(NUM_CLT,1),nvl(CODE_TRAITEMENT,''S''),nvl(NB_PERS,1)      ',
'into :p12_num_bon,:p12_table,:p12_client,:p12_surplace,:p12_nbpers',
'from bons_temp',
'where trim(code_utilisateur) =v(''app_user'');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>81370264913375964
);
wwv_flow_imp.component_end;
end;
/
