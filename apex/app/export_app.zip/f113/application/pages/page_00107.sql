prompt --application/pages/page_00107
begin
--   Manifest
--     PAGE: 00107
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>107
,p_name=>'Demande appro'
,p_alias=>'DEMANDE-APPRO'
,p_step_title=>'Demande appro'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(203834007654870718)
,p_name=>'Produits'
,p_template=>4072358936313175081
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_grid_column_span=>5
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUM_PRODUIT ID,NUM_produit,unite_mesure,:P107_NUM_APPROA num_appro,',
'       DESIGNATION_PRODUIT',
'  from PRODUITS',
'  where stockable = ''O''',
'  and nvl(:P107_NUM_APPROA,0) > 0',
'  and trim(code_style) =''N''',
'  and CODE_TYPE_PRODUIT = nvl(:P107_TYPE_PRODUIT_PDR,CODE_TYPE_PRODUIT)',
'  order by DESIGNATION_PRODUIT asc;'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P107_NUM_APPROA,P107_TYPE_PRODUIT_PDR'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85021715992531900)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>4
,p_column_heading=>'Selection'
,p_column_link=>'f?p=&APP_ID.:116:&SESSION.::&DEBUG.::P116_NUM_PRODUIT,P116_NUMERO_APPRO:#ID#,#NUM_APPRO#'
,p_column_linktext=>'<span class="t-Icon fa fa-toggle-right affbons-note" aria-hidden="true"></span>'
,p_column_link_attr=>'id=''#ID#'' class="affbons t-Button t-Button--danger t-Button--simple t-Button--small" title="Selectionner produit : #NUM_PRODUIT#"'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85022105863531901)
,p_query_column_id=>2
,p_column_alias=>'NUM_PRODUIT'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85022534501531901)
,p_query_column_id=>3
,p_column_alias=>'UNITE_MESURE'
,p_column_display_sequence=>3
,p_column_heading=>'Unite Mesure'
,p_column_html_expression=>'<span style="display:block; width:90px"><h5>#UNITE_MESURE#</h5></span>'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85022864382531901)
,p_query_column_id=>4
,p_column_alias=>'NUM_APPRO'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85023316275531901)
,p_query_column_id=>5
,p_column_alias=>'DESIGNATION_PRODUIT'
,p_column_display_sequence=>2
,p_column_heading=>unistr('D\00E9signation')
,p_column_html_expression=>'<span style="display:block; width:350px"><h5>#DESIGNATION_PRODUIT#</h5></span>'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(242827088821801994)
,p_plug_name=>'Point de vente'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>3
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(242827338705801997)
,p_name=>'Approvisionnement'
,p_parent_plug_id=>wwv_flow_imp.id(242827088821801994)
,p_template=>4072358936313175081
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUM_APPRO,',
'       LIBELLE,',
'       CODE_TYPE_APPRO,',
'       NUM_POINT_VENTED,',
'       NUM_POINT_VENTEA,',
'       DATE_APPRO,',
'       CODE_UTILISATEUR,',
'       DATE_CREATION,',
'       CODE_ETAT',
'  from APPRO',
'  where num_appro = :P107_NUM_APPROA',
'and code_etat = 0'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P107_NUM_APPROA'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85028668800531909)
,p_query_column_id=>1
,p_column_alias=>'NUM_APPRO'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85029105244531909)
,p_query_column_id=>2
,p_column_alias=>'LIBELLE'
,p_column_display_sequence=>2
,p_column_heading=>'Libelle'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85029528752531911)
,p_query_column_id=>3
,p_column_alias=>'CODE_TYPE_APPRO'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85029900996531911)
,p_query_column_id=>4
,p_column_alias=>'NUM_POINT_VENTED'
,p_column_display_sequence=>4
,p_column_heading=>'Point de vente principal'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(81104181522273040)
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85030360048531911)
,p_query_column_id=>5
,p_column_alias=>'NUM_POINT_VENTEA'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85030755392531912)
,p_query_column_id=>6
,p_column_alias=>'DATE_APPRO'
,p_column_display_sequence=>6
,p_column_heading=>'Date '
,p_column_format=>'DD/MM/YYYY'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85031091205531914)
,p_query_column_id=>7
,p_column_alias=>'CODE_UTILISATEUR'
,p_column_display_sequence=>7
,p_column_heading=>'Emetteur'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85031497197531914)
,p_query_column_id=>8
,p_column_alias=>'DATE_CREATION'
,p_column_display_sequence=>8
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85031922076531914)
,p_query_column_id=>9
,p_column_alias=>'CODE_ETAT'
,p_column_display_sequence=>9
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(242830027842802023)
,p_plug_name=>unistr('D\00E9tails')
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUM_DETAIL_APPRO ,',
'        NUM_APPRO,',
'        NUM_PRODUIT ,',
'        QTE ,unite_mesure',
'from details_appro',
'where num_appro = :P107_NUM_APPROA',
'and type_produit = nvl(:P107_TYPE_PRODUIT,type_produit)'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P107_NUMERO_APPRO,P107_TYPE_PRODUIT,P107_NUM_APPROA'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(203530391339663336)
,p_name=>'UNITE_MESURE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UNITE_MESURE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Unite Mesure'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>90
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>10
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(203837344466870751)
,p_name=>'menu'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>40
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(203837435834870752)
,p_name=>'selector'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>50
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'enable_multi_select', 'Y',
  'hide_control', 'N',
  'show_select_all', 'Y')).to_clob
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(243988756120711075)
,p_name=>'NUM_DETAIL_APPRO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NUM_DETAIL_APPRO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(243988858353711076)
,p_name=>'NUM_APPRO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NUM_APPRO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>60
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(243989002384711077)
,p_name=>'NUM_PRODUIT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NUM_PRODUIT'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Produit'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(81557789633430934)
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(243989075839711078)
,p_name=>'QTE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QTE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('Qt\00E9')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>80
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
,p_format_mask=>'999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(243988637926711074)
,p_internal_uid=>188816077471038105
,p_is_editable=>true
,p_edit_operations=>'u:d'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_show_nulls_as=>'-'
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>false
,p_show_toolbar=>true
,p_toolbar_buttons=>'SAVE'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>false
,p_define_chart_view=>false
,p_enable_download=>false
,p_download_formats=>null
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
' function(config) {',
'        let $             = apex.jQuery,',
'            toolbarData   = $.apex.interactiveGrid.copyDefaultToolbar(),',
'            addrowAction  = toolbarData.toolbarFind("selection-add-row"),',
'            saveAction    = toolbarData.toolbarFind("save"),',
'            editAction    = toolbarData.toolbarFind("edit");',
'         ',
'        addrowAction.icon = "icon-ig-add-row";',
'        addrowAction.iconBeforeLabel = true;',
'        addrowAction.hot = true;',
'        saveAction.label = "Enregistrer";',
'        saveAction.iconBeforeLabel = true;',
'        saveAction.icon ="icon-ig-save-as";',
'        saveAction.hot = true;',
'        editAction.label = "Modifier";',
'        config.toolbarData = toolbarData;',
'        return config;',
'    }'))
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(243994248737723569)
,p_interactive_grid_id=>wwv_flow_imp.id(243988637926711074)
,p_static_id=>'252207'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(243994374514723571)
,p_report_id=>wwv_flow_imp.id(243994248737723569)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(203817341920447944)
,p_view_id=>wwv_flow_imp.id(243994374514723571)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(203530391339663336)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(203930836663800279)
,p_view_id=>wwv_flow_imp.id(243994374514723571)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(203837344466870751)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(243994839380723574)
,p_view_id=>wwv_flow_imp.id(243994374514723571)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(243988756120711075)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(243995371941723576)
,p_view_id=>wwv_flow_imp.id(243994374514723571)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(243988858353711076)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(243995916835723577)
,p_view_id=>wwv_flow_imp.id(243994374514723571)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(243989002384711077)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(243996432598723580)
,p_view_id=>wwv_flow_imp.id(243994374514723571)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(243989075839711078)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85024849190531904)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(242827088821801994)
,p_button_name=>'Nouveau'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Cr\00E9er')
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85025231619531904)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(242827088821801994)
,p_button_name=>'Efface'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Effacer'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85025632196531904)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(242827088821801994)
,p_button_name=>'Supprimer'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Supprimer'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85026026829531904)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(242827088821801994)
,p_button_name=>'Quitter'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Quitter'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85023715557531903)
,p_name=>'P107_TYPE_PRODUIT_PDR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(203834007654870718)
,p_prompt=>'Type produit'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TYPE_PRODUIT_STOCK'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select libelle_type_produit as d,',
'       code_type_produit as r',
'  from type_produit',
'  where code_type_produit in (select code_type_produit from produits where STOCKABLE =''O'')',
' order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Tous'
,p_cHeight=>1
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85024061279531903)
,p_name=>'P107_NUMAPPRO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(203834007654870718)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85026408836531906)
,p_name=>'P107_NUM_PV'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(242827088821801994)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.num_point_vente',
'from affectation a,personnel p,espace_vente e',
'where a.matricule = p.matricule',
'and a.num_espace_vente = e.num_espace_vente',
'and trim(profil_app) = v(''app_user'');'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85026800337531906)
,p_name=>'P107_NOM_PV'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(242827088821801994)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Point de vente'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pv.nom_point_vente',
'from affectation a,personnel p,espace_vente e,point_vente pv',
'where a.matricule = p.matricule',
'and a.num_espace_vente = e.num_espace_vente',
'and pv.num_point_vente = e.num_point_vente',
'and trim(profil_app) = nvl(v(''app_user''), user);'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85027169659531906)
,p_name=>'P107_TYPE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(242827088821801994)
,p_use_cache_before_default=>'NO'
,p_item_default=>'1'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC2:Nouveau;1,Modification;2'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85027601903531908)
,p_name=>'P107_NUM_APPROA'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(242827088821801994)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85027999988531908)
,p_name=>'P107_NUMERO_APPRO'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(242827088821801994)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Selectionnez un N\00B0 Appro pour modifiaction')
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(num_appro) ||''-''|| trim(libelle) as lib,num_appro ',
'from appro',
'where code_etat = 0',
'--and code_type_appro = 3',
'and num_point_ventea = (select e.num_point_vente from affectation a,personnel p,espace_vente e where a.matricule = p.matricule and a.num_espace_vente = e.num_espace_vente and trim(profil_app) = v(''app_user''))',
'order by num_appro desc',
''))
,p_cSize=>30
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'DIALOG',
  'fetch_on_search', 'N',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85036113220531922)
,p_name=>'P107_TYPE_PRODUIT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(242830027842802023)
,p_prompt=>'Type produit'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TYPE_PRODUIT_STOCK'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select libelle_type_produit as d,',
'       code_type_produit as r',
'  from type_produit',
'  where code_type_produit in (select code_type_produit from produits where STOCKABLE =''O'')',
' order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Tous'
,p_cHeight=>1
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85036934723531923)
,p_name=>'demande'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(85024849190531904)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85037403039531925)
,p_event_id=>wwv_flow_imp.id(85036934723531923)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'num_pv number;',
'num_appro number;',
'type_appro number;',
'begin',
' ',
'  select e.num_point_vente into num_pv from affectation a,personnel p,espace_vente e where a.matricule = p.matricule and a.num_espace_vente = e.num_espace_vente and trim(profil_app) = v(''app_user'');',
'  --if num_pv = 0 then ',
'      type_appro := 1; ',
'   --else ',
'      -- type_appro:=3; ',
'   --end if;',
'  select seq_appro.nextval into num_appro from dual;',
unistr('  insert into appro values(num_appro/*NUM_APPRO*/,''Demande d''''appro point de vente N\00B0 ''|| to_char(num_appro)/*LIBELLE*/,type_appro/*CODE_TYPE_APPRO*/,0/*NUM_POINT_VENTED*/,num_pv/*NUM_POINT_VENTEA*/,'),
'                           sysdate/*DATE_APPRO*/,v(''app_user'')/*CODE_UTILISATEUR */,sysdate/*DATE_CREATION*/,0/*CODE_ETAT*/,null );',
'   /*insert into details_appro select seq_num_detail_appro.nextval,num_appro,num_produit,0 ,code_type_produit,unite_mesure,0',
'   from produits',
'   where code_type_produit  in (select code_type_produit from type_produit where code_famille in (5,10,9))',
'   and stockable = ''O''; */',
'   :P107_NUMERO_APPRO := num_appro;:P107_NUM_APPROA:= num_appro;',
'   :P107_NUMAPPRO := num_appro;',
'   commit;',
'end;',
'',
''))
,p_attribute_02=>'P107_NUMERO_APPRO,P107_NUM_APPROA,P107_NUMAPPRO'
,p_attribute_03=>'P107_NUMERO_APPRO,P107_NUM_APPROA,P107_NUMAPPRO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85037874469531926)
,p_event_id=>wwv_flow_imp.id(85036934723531923)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(242827338705801997)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85038435644531926)
,p_event_id=>wwv_flow_imp.id(85036934723531923)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(242830027842802023)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85038867964531926)
,p_event_id=>wwv_flow_imp.id(85036934723531923)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(203834007654870718)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85039281354531928)
,p_name=>'type'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P107_TYPE_PRODUIT'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85039835621531928)
,p_event_id=>wwv_flow_imp.id(85039281354531928)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(242830027842802023)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85040166277531929)
,p_name=>'afficher'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P107_NUM_APPROA'
,p_condition_element=>'P107_NUM_APPROA'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85040680804531929)
,p_event_id=>wwv_flow_imp.id(85040166277531929)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(242827338705801997)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85041238155531931)
,p_event_id=>wwv_flow_imp.id(85040166277531929)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(242830027842802023)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85041658233531931)
,p_name=>'modif'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P107_NUMERO_APPRO'
,p_condition_element=>'P107_NUM_APPROA'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85042091023531933)
,p_event_id=>wwv_flow_imp.id(85041658233531931)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Vous devez effacer l&#x27;approvisionnement courant avant !'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85042600073531933)
,p_event_id=>wwv_flow_imp.id(85041658233531931)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>':P107_NUM_APPROA := :P107_NUMERO_APPRO;'
,p_attribute_02=>'P107_NUM_APPROA,P107_NUMERO_APPRO'
,p_attribute_03=>'P107_NUM_APPROA'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85043132011531934)
,p_event_id=>wwv_flow_imp.id(85041658233531931)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(242827338705801997)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85043628028531934)
,p_event_id=>wwv_flow_imp.id(85041658233531931)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(242830027842802023)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85044149986531934)
,p_event_id=>wwv_flow_imp.id(85041658233531931)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(203834007654870718)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85044468801531936)
,p_name=>'effacer'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(85025231619531904)
,p_condition_element=>'P107_NUM_APPROA'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85044971613531936)
,p_event_id=>wwv_flow_imp.id(85044468801531936)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P107_NUM_APPROA'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85045539316531936)
,p_event_id=>wwv_flow_imp.id(85044468801531936)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P107_NUMERO_APPRO'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85045991250531937)
,p_event_id=>wwv_flow_imp.id(85044468801531936)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(242827338705801997)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85046538781531937)
,p_event_id=>wwv_flow_imp.id(85044468801531936)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(242830027842802023)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85046889810531939)
,p_name=>'qte'
,p_event_sequence=>70
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(203834007654870718)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85047457795531939)
,p_event_id=>wwv_flow_imp.id(85046889810531939)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(242830027842802023)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85047807292531939)
,p_name=>'typeprd'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P107_TYPE_PRODUIT_PDR'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85048332154531940)
,p_event_id=>wwv_flow_imp.id(85047807292531939)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(203834007654870718)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85048665959531940)
,p_name=>'supp'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(85025632196531904)
,p_condition_element=>'P107_NUM_APPROA'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85049219013531940)
,p_event_id=>wwv_flow_imp.id(85048665959531940)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Etes-vous s&#xFB;rs de vouloir supprimer cette demande ?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85049670340531940)
,p_event_id=>wwv_flow_imp.id(85048665959531940)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete details_appro where num_appro = :P107_NUM_APPROA;',
'delete appro where num_appro = :P107_NUM_APPROA;',
'commit;'))
,p_attribute_02=>'P107_NUM_APPROA'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85050252300531940)
,p_event_id=>wwv_flow_imp.id(85048665959531940)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P107_NUM_APPROA'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85050716374531942)
,p_event_id=>wwv_flow_imp.id(85048665959531940)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P107_NUMERO_APPRO'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85051191901531942)
,p_event_id=>wwv_flow_imp.id(85048665959531940)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(242827338705801997)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85051667472531942)
,p_event_id=>wwv_flow_imp.id(85048665959531940)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(242830027842802023)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85052125517531942)
,p_name=>'action'
,p_event_sequence=>100
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P107_TYPE'
,p_condition_element=>'P107_TYPE'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85052644828531944)
,p_event_id=>wwv_flow_imp.id(85052125517531942)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(85024849190531904)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85053099757531944)
,p_event_id=>wwv_flow_imp.id(85052125517531942)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(85024849190531904)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85053632474531944)
,p_event_id=>wwv_flow_imp.id(85052125517531942)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P107_NUMERO_APPRO'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85054090517531945)
,p_event_id=>wwv_flow_imp.id(85052125517531942)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P107_NUMERO_APPRO'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85054645630531945)
,p_event_id=>wwv_flow_imp.id(85052125517531942)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P107_NUM_APPROA'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85055080787531945)
,p_event_id=>wwv_flow_imp.id(85052125517531942)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P107_NUM_APPROA'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85055657960531945)
,p_event_id=>wwv_flow_imp.id(85052125517531942)
,p_event_result=>'FALSE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P107_NUMERO_APPRO'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85056154941531947)
,p_event_id=>wwv_flow_imp.id(85052125517531942)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P107_NUMERO_APPRO'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85056589417531947)
,p_event_id=>wwv_flow_imp.id(85052125517531942)
,p_event_result=>'FALSE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(242827338705801997)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85057070534531947)
,p_event_id=>wwv_flow_imp.id(85052125517531942)
,p_event_result=>'FALSE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(242830027842802023)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85057579649531948)
,p_event_id=>wwv_flow_imp.id(85052125517531942)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(242827338705801997)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85058072030531948)
,p_event_id=>wwv_flow_imp.id(85052125517531942)
,p_event_result=>'TRUE'
,p_action_sequence=>90
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(242830027842802023)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(85036534766531923)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(242830027842802023)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>unistr('D\00E9tails - Enregistrer les donn\00E9es de grille interactive')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>85036534766531923
);
wwv_flow_imp.component_end;
end;
/
