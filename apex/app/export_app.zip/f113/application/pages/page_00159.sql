prompt --application/pages/page_00159
begin
--   Manifest
--     PAGE: 00159
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>159
,p_name=>'Tableau de bord new'
,p_alias=>'TABLEAU-DE-BORD-NEW'
,p_step_title=>'Tableau de bord new'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'04'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(113626673621056454)
,p_plug_name=>'Courbe valeur moyenne  bon'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>80
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(83459561470499704)
,p_region_id=>wwv_flow_imp.id(113626673621056454)
,p_chart_type=>'line'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(83461325086499711)
,p_chart_id=>wwv_flow_imp.id(83459561470499704)
,p_seq=>10
,p_name=>'Ventes'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  to_char(date_creation,''ddmmyyyy'') dd,sum(montant_bon)/count(*) v ',
'from bons b',
'where    FN_DATE_NUM(b.date_creation) between nvl(FN_DATE_NUM(:P159_DATE_DEBUT),FN_DATE_NUM(b.date_creation)) and nvl(FN_DATE_NUM(:P159_DATE_FIN),FN_DATE_NUM(b.date_creation))',
'    and b.num_espace_vente in (select num_espace_vente from espace_vente where num_point_vente =:P159_POINT_VENTE)',
'group by to_char(date_creation,''ddmmyyyy'');'))
,p_max_row_count=>20
,p_ajax_items_to_submit=>'P159_DATE_DEBUT,P159_DATE_FIN,P159_POINT_VENTE'
,p_items_value_column_name=>'V'
,p_items_label_column_name=>'DD'
,p_color=>'#8E8E93'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(83460100469499708)
,p_chart_id=>wwv_flow_imp.id(83459561470499704)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'FRANCS CFA'
,p_title_font_family=>'Arial'
,p_title_font_style=>'normal'
,p_title_font_size=>'20'
,p_title_font_color=>'#000000'
,p_format_scaling=>'thousand'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'on'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(83460750608499709)
,p_chart_id=>wwv_flow_imp.id(83459561470499704)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_title=>'DATE'
,p_title_font_family=>'Arial'
,p_title_font_style=>'normal'
,p_title_font_size=>'20'
,p_title_font_color=>'#000000'
,p_format_scaling=>'thousand'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(113627274664056460)
,p_plug_name=>'Courbe temps moyen  bon'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>90
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(83462568622499715)
,p_region_id=>wwv_flow_imp.id(113627274664056460)
,p_chart_type=>'line'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(83464282574499715)
,p_chart_id=>wwv_flow_imp.id(83462568622499715)
,p_seq=>10
,p_name=>'Ventes'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select date_temps,tm',
'from temps_moyen_bon ',
'where  numero_tb= :P159_TB'))
,p_max_row_count=>20
,p_ajax_items_to_submit=>'P159_DATE_DEBUT,P159_DATE_FIN,P159_POINT_VENTE,P159_TB'
,p_items_value_column_name=>'TM'
,p_items_label_column_name=>'DATE_TEMPS'
,p_color=>'#8E8E93'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(83463153765499715)
,p_chart_id=>wwv_flow_imp.id(83462568622499715)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_title=>'DATE'
,p_title_font_family=>'Arial'
,p_title_font_style=>'normal'
,p_title_font_size=>'20'
,p_title_font_color=>'#000000'
,p_format_scaling=>'thousand'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(83463757953499715)
,p_chart_id=>wwv_flow_imp.id(83462568622499715)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'TEMPS (minutes)'
,p_title_font_family=>'Arial'
,p_title_font_style=>'normal'
,p_title_font_size=>'20'
,p_title_font_color=>'#000000'
,p_format_scaling=>'thousand'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'on'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(114026939702022120)
,p_plug_name=>'Average count by DoW (Ingrediants)'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>60
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(83465571650499717)
,p_region_id=>wwv_flow_imp.id(114026939702022120)
,p_chart_type=>'bar'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(83467284800499719)
,p_chart_id=>wwv_flow_imp.id(83465571650499717)
,p_seq=>10
,p_name=>'Nombre'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select heure,sum(moyenne) from average_count_dow_ing',
'where jour = nvl(:P159_JOUR,jour)',
'and num_produit = nvl(:P159_PRODUIT_1,num_produit)',
'and jour = nvl(:P159_JOUR_1_1,jour)',
'and numero_tb= :P159_TB',
'group by heure',
'order by heure',
''))
,p_max_row_count=>20
,p_ajax_items_to_submit=>'P159_DATE_DEBUT,P159_DATE_FIN,P159_POINT_VENTE,P159_JOUR_1_1,P159_PRODUIT_1'
,p_items_value_column_name=>'SUM(MOYENNE)'
,p_group_name_column_name=>'HEURE'
,p_group_short_desc_column_name=>'HEURE'
,p_items_label_column_name=>'HEURE'
,p_color=>'#FFCC00'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(83466730928499719)
,p_chart_id=>wwv_flow_imp.id(83465571650499717)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'MOYENNE'
,p_title_font_family=>'Arial'
,p_title_font_style=>'normal'
,p_title_font_size=>'20'
,p_title_font_color=>'#000000'
,p_format_scaling=>'thousand'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(83466109571499719)
,p_chart_id=>wwv_flow_imp.id(83465571650499717)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_title=>'HEURE'
,p_title_font_family=>'Arial'
,p_title_font_style=>'normal'
,p_title_font_size=>'20'
,p_title_font_color=>'#291B29'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_tick_label_font_color=>'#0C2787'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152583698984495748)
,p_plug_name=>'Average sales by DoW'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(83468984302499722)
,p_region_id=>wwv_flow_imp.id(152583698984495748)
,p_chart_type=>'bar'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(83470672501499723)
,p_chart_id=>wwv_flow_imp.id(83468984302499722)
,p_seq=>10
,p_name=>'Ventes'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select heure,sum(moyenne) from average_sale_dow',
'where jour = nvl(:P159_JOUR,jour)',
'and  numero_tb= :P159_TB',
'group by heure',
'order by heure;',
''))
,p_max_row_count=>20
,p_ajax_items_to_submit=>'P159_DATE_DEBUT,P159_DATE_FIN,P159_POINT_VENTE,P159_JOUR,P159_TB'
,p_items_value_column_name=>'SUM(MOYENNE)'
,p_items_label_column_name=>'HEURE'
,p_color=>'#E36E14'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(83470077443499723)
,p_chart_id=>wwv_flow_imp.id(83468984302499722)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_title=>'HEURE'
,p_title_font_family=>'Arial'
,p_title_font_style=>'normal'
,p_title_font_size=>'20'
,p_title_font_color=>'#000000'
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(83469557649499722)
,p_chart_id=>wwv_flow_imp.id(83468984302499722)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'FRANCS CFA'
,p_title_font_family=>'Arial'
,p_title_font_style=>'normal'
,p_title_font_size=>'20'
,p_title_font_color=>'#000000'
,p_format_scaling=>'thousand'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(152584446683495756)
,p_plug_name=>'Average count by DoW (Produits)'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(83472429645499725)
,p_region_id=>wwv_flow_imp.id(152584446683495756)
,p_chart_type=>'bar'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(83474151869499728)
,p_chart_id=>wwv_flow_imp.id(83472429645499725)
,p_seq=>10
,p_name=>'Nombre'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select heure,sum(moyenne) from average_count_dow',
'where jour = nvl(:P159_JOUR,jour)',
'and num_produit = nvl(:P159_PRODUIT,num_produit)',
'and jour = nvl(:P159_JOUR_1,jour)',
'and   numero_tb= :P159_TB',
'group by heure',
'order by heure',
''))
,p_max_row_count=>20
,p_ajax_items_to_submit=>'P159_DATE_DEBUT,P159_DATE_FIN,P159_POINT_VENTE,P159_JOUR_1,P159_PRODUIT,P159_TB'
,p_items_value_column_name=>'SUM(MOYENNE)'
,p_group_name_column_name=>'HEURE'
,p_group_short_desc_column_name=>'HEURE'
,p_items_label_column_name=>'HEURE'
,p_color=>'#14E38A'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(83473537053499726)
,p_chart_id=>wwv_flow_imp.id(83472429645499725)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'MOYENNE'
,p_title_font_family=>'Arial'
,p_title_font_style=>'normal'
,p_title_font_size=>'20'
,p_title_font_color=>'#000000'
,p_format_scaling=>'thousand'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(83472960321499726)
,p_chart_id=>wwv_flow_imp.id(83472429645499725)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_title=>'HEURE'
,p_title_font_family=>'Arial'
,p_title_font_style=>'normal'
,p_title_font_size=>'20'
,p_title_font_color=>'#291B29'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'min'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_tick_label_font_color=>'#0C2787'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(308363200386525889)
,p_plug_name=>'Courbe des ventes par mois'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>70
,p_plug_new_grid_row=>false
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(83475855968499729)
,p_region_id=>wwv_flow_imp.id(308363200386525889)
,p_chart_type=>'line'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(83477476541499731)
,p_chart_id=>wwv_flow_imp.id(83475855968499729)
,p_seq=>10
,p_name=>'Ventes'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  to_number(to_char(date_bon,''yyyymm'')) mois, sum(pu_bon*qte_bon) value ',
'from details_bon d,bons b',
'where d.date_creation between nvl(:P159_DATE_DEBUT,d.date_creation) and nvl(:P159_DATE_FIN,d.date_creation)',
'and b.num_bon =d.num_bon',
'and b.num_espace_vente in (select num_espace_vente from espace_vente where num_point_vente =:P159_POINT_VENTE)',
'group by  to_number(to_char(date_bon,''yyyymm''))',
'order by  to_number(to_char(date_bon,''yyyymm''));'))
,p_max_row_count=>20
,p_ajax_items_to_submit=>'P159_DATE_DEBUT,P159_DATE_FIN,P159_POINT_VENTE'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'MOIS'
,p_color=>'#8E8E93'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(83476900493499729)
,p_chart_id=>wwv_flow_imp.id(83475855968499729)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_title=>'MOIS'
,p_title_font_family=>'Arial'
,p_title_font_style=>'normal'
,p_title_font_size=>'20'
,p_title_font_color=>'#000000'
,p_format_scaling=>'thousand'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(83476323565499729)
,p_chart_id=>wwv_flow_imp.id(83475855968499729)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'FRANCS CFA'
,p_title_font_family=>'Arial'
,p_title_font_style=>'normal'
,p_title_font_size=>'20'
,p_title_font_color=>'#000000'
,p_format_scaling=>'thousand'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'on'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(308365813615525892)
,p_plug_name=>'Type de consommation'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(83478380771499731)
,p_region_id=>wwv_flow_imp.id(308365813615525892)
,p_chart_type=>'donut'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_value_format_scaling=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(83478893327499733)
,p_chart_id=>wwv_flow_imp.id(83478380771499731)
,p_seq=>10
,p_name=>'Type conso'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  code_traitement Type_consommation, sum(pu_bon*qte_bon) value ',
'from details_bon d,bons b',
'where  FN_DATE_NUM(b.date_creation) between nvl(FN_DATE_NUM(:P159_DATE_DEBUT),FN_DATE_NUM(b.date_creation)) and nvl(FN_DATE_NUM(:P159_DATE_FIN),FN_DATE_NUM(b.date_creation))',
'and b.num_bon =d.num_bon',
'and b.num_espace_vente in (select num_espace_vente from espace_vente where num_point_vente =:P159_POINT_VENTE)',
'group by code_traitement',
'order by code_traitement'))
,p_max_row_count=>20
,p_ajax_items_to_submit=>'P159_DATE_DEBUT,P159_DATE_FIN,P159_POINT_VENTE'
,p_items_value_column_name=>'VALUE'
,p_items_label_column_name=>'TYPE_CONSOMMATION'
,p_items_short_desc_column_name=>'TYPE_CONSOMMATION'
,p_custom_column_name=>'TYPE_CONSOMMATION'
,p_items_label_rendered=>true
,p_items_label_position=>'outsideSlice'
,p_items_label_display_as=>'ALL'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(308367318953525893)
,p_plug_name=>'Top 10 produits'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_location=>null
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(83479699526499733)
,p_region_id=>wwv_flow_imp.id(308367318953525893)
,p_chart_type=>'bar'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'horizontal'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(83481447196499734)
,p_chart_id=>wwv_flow_imp.id(83479699526499733)
,p_seq=>10
,p_name=>'Vente'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select montant, libelle from top_vente',
'where numero_tb= :P159_TB;'))
,p_max_row_count=>20
,p_ajax_items_to_submit=>'P159_DATE_DEBUT,P159_DATE_FIN,P159_POINT_VENTE,P159_TB'
,p_items_value_column_name=>'MONTANT'
,p_group_name_column_name=>'MONTANT'
,p_group_short_desc_column_name=>'LIBELLE'
,p_items_label_column_name=>'LIBELLE'
,p_items_short_desc_column_name=>'MONTANT'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
,p_items_label_display_as=>'PERCENT'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(83480848096499734)
,p_chart_id=>wwv_flow_imp.id(83479699526499733)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_title=>'FRANCS CFA'
,p_title_font_family=>'Arial'
,p_title_font_style=>'normal'
,p_title_font_size=>'20'
,p_format_scaling=>'thousand'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(83480173484499734)
,p_chart_id=>wwv_flow_imp.id(83479699526499733)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_title=>'PRODUITS'
,p_title_font_family=>'Arial'
,p_title_font_style=>'normal'
,p_title_font_size=>'20'
,p_title_font_color=>'#000000'
,p_format_scaling=>'thousand'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(308813009057634632)
,p_plug_name=>unistr('Param\00E8tres')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>4
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(83482290986499736)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(308813009057634632)
,p_button_name=>'Calculer'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Calculer'
,p_button_position=>'BOTTOM'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83461895542499714)
,p_name=>'P159_VALEUR_MOYENNE_BON'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(113626673621056454)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Valeur Moyenne Bon'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>3
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83464890108499717)
,p_name=>'P159_TEMPS_MOYEN_BON'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(113627274664056460)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Temps Moyen Bon'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_colspan=>3
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83467895816499720)
,p_name=>'P159_JOUR_1_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(114026939702022120)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Jour de la semaine'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select libelle,jour from semaine order by jour'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_colspan=>3
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83468337714499720)
,p_name=>'P159_PRODUIT_1'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(114026939702022120)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Produit'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'INGREDIENT'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select trim(designation_produit) || ''(''|| trim(unite_mesure)||'')'' as d,',
'       num_produit as r',
'  from produits',
'  where code_type_produit in (select code_type_produit from type_produit where code_famille in (9,10))',
'  order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83471334534499723)
,p_name=>'P159_JOUR'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(152583698984495748)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Jour de la semaine'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select libelle,jour from semaine order by jour'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_colspan=>3
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83471700966499725)
,p_name=>'P159_MOYENNE_JOUR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(152583698984495748)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Moyenne Jour'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83474671112499728)
,p_name=>'P159_JOUR_1'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(152584446683495756)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Jour de la semaine'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'select libelle,jour from semaine order by jour'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_colspan=>3
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83475088907499728)
,p_name=>'P159_PRODUIT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(152584446683495756)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Produit'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'POINT_VENTE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nom_point_vente as d,',
'       num_point_vente as r',
'  from point_vente where actif=''O''',
'order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83482687000499736)
,p_name=>'P159_PROFIL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(308813009057634632)
,p_use_cache_before_default=>'NO'
,p_item_default=>'select code_statut_personnel from personnel where trim(profil_app)=v(''app_user'');'
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83483114095499737)
,p_name=>'P159_CHOIX'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(308813009057634632)
,p_item_default=>'2'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:Nouveau tableau de bord;1,Tableau de bord existant;2'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83483544303499737)
,p_name=>'P159_TB'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(308813009057634632)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Tableau de bord'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>'select libelle,numero_tb from tableau_bord'
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'DIALOG',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83483870610499737)
,p_name=>'P159_POINT_VENTE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(308813009057634632)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Point de vente'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'POINT_VENTE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nom_point_vente as d,',
'       num_point_vente as r',
'  from point_vente where actif=''O''',
'order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83484322056499739)
,p_name=>'P159_DATE_DEBUT'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(308813009057634632)
,p_prompt=>'Date Debut'
,p_format_mask=>'DD/MM/YYYY'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'appearance_and_behavior', 'MONTH-PICKER:YEAR-PICKER',
  'days_outside_month', 'VISIBLE',
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_on', 'FOCUS',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83484699466499739)
,p_name=>'P159_DATE_FIN'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(308813009057634632)
,p_prompt=>'Date Fin'
,p_format_mask=>'DD/MM/YYYY'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'appearance_and_behavior', 'MONTH-PICKER:YEAR-PICKER',
  'days_outside_month', 'VISIBLE',
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_on', 'FOCUS',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(83485233216499740)
,p_validation_name=>'VERIFDATE'
,p_validation_sequence=>10
,p_validation=>':p159_date_debut < :p159_date_fin'
,p_validation2=>'SQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>unistr('La date de d\00E9but doit \00EAtre ant\00E9rieure \00E0 la date de fin')
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_imp.id(83484322056499739)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83485467394499740)
,p_name=>'Reflesh'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(83482290986499736)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83485968588499740)
,p_event_id=>wwv_flow_imp.id(83485467394499740)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(308363200386525889)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83486515373499740)
,p_event_id=>wwv_flow_imp.id(83485467394499740)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'//execute spinner',
'var spinner = apex.util.showSpinner();'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83487039841499742)
,p_event_id=>wwv_flow_imp.id(83485467394499740)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    val number;',
'    num_tb number(10);',
'    ',
'    cursor c_tb is select * from tableau_bord',
'    where num_point_vente = :P159_POINT_VENTE',
'    and FN_DATE_NUM(date_debut) = FN_DATE_NUM(:P159_DATE_DEBUT)',
'    and FN_DATE_NUM(date_fin) = FN_DATE_NUM(:P159_DATE_FIN);',
'    ',
'    r_tb c_tb%rowtype;',
'    ',
'begin',
'    open c_tb;',
'    fetch c_tb into r_tb;',
'    if c_tb%found then',
'        delete top_vente where numero_tb = r_tb.numero_tb;',
'        delete temps_moyen_bon where numero_tb = r_tb.numero_tb;',
'        delete average_sale_dow where numero_tb =  r_tb.numero_tb;',
'        delete average_count_dow where numero_tb = r_tb.numero_tb;',
'        delete average_count_dow_ing where numero_tb =  r_tb.numero_tb;',
'        delete temps_moyen_bon where numero_tb = r_tb.numero_tb;',
'     end if;',
'     close c_tb;',
'        ',
'     select seq_tb.nextval into num_tb from dual;',
'     ',
'     pr_init_tb(v(''app_session'') ,:P159_DATE_DEBUT ,:P159_DATE_FIN,:P159_POINT_VENTE,num_tb);',
'     :P159_TB :=num_tb;',
'    select  round(sum(montant_bon)/count(*)) into val ',
'    from bons b',
'    where  FN_DATE_NUM(b.date_creation) between nvl(FN_DATE_NUM(:P159_DATE_DEBUT),FN_DATE_NUM(b.date_creation)) and nvl(FN_DATE_NUM(:P159_DATE_FIN),FN_DATE_NUM(b.date_creation))',
'    and b.num_espace_vente in (select num_espace_vente from espace_vente where num_point_vente =:P159_POINT_VENTE);',
'    ',
'    :P159_VALEUR_MOYENNE_BON := to_char(val,''999G999G999G999G999G999G990'');',
'   ',
'    select FN_TEMPS_MOYEN(:P159_DATE_DEBUT, :P159_DATE_FIN, :P159_POINT_VENTE) INTO val from dual;',
'    ',
'    :P159_TEMPS_MOYEN_BON:= to_char(val,''999G999G999G999G999G999G990'');',
'end;'))
,p_attribute_02=>'P159_POINT_VENTE,P159_DATE_DEBUT,P159_DATE_FIN,P159_VALEUR_MOYENNE_BON,P159_TEMPS_MOYEN_BON,P159_TB'
,p_attribute_03=>'P159_VALEUR_MOYENNE_BON,P159_TEMPS_MOYEN_BON,P159_TB'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83487502226499742)
,p_event_id=>wwv_flow_imp.id(83485467394499740)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'//remove spinner',
'$("#apex_wait_overlay").remove();',
'$(".u-Processing").remove();'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83488048439499742)
,p_event_id=>wwv_flow_imp.id(83485467394499740)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(308365813615525892)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83488520642499742)
,p_event_id=>wwv_flow_imp.id(83485467394499740)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(152583698984495748)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83488985589499744)
,p_event_id=>wwv_flow_imp.id(83485467394499740)
,p_event_result=>'TRUE'
,p_action_sequence=>100
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(152584446683495756)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83489525309499744)
,p_event_id=>wwv_flow_imp.id(83485467394499740)
,p_event_result=>'TRUE'
,p_action_sequence=>120
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(308367318953525893)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83489997106499744)
,p_event_id=>wwv_flow_imp.id(83485467394499740)
,p_event_result=>'TRUE'
,p_action_sequence=>140
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(113626673621056454)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83490486263499744)
,p_event_id=>wwv_flow_imp.id(83485467394499740)
,p_event_result=>'TRUE'
,p_action_sequence=>160
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(113627274664056460)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83491007934499745)
,p_event_id=>wwv_flow_imp.id(83485467394499740)
,p_event_result=>'TRUE'
,p_action_sequence=>180
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(114026939702022120)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83491429633499745)
,p_name=>'APP'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P159_PROFIL'
,p_condition_element=>'P159_PROFIL'
,p_triggering_condition_type=>'NOT_EQUALS'
,p_triggering_expression=>'3'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83492379440499745)
,p_event_id=>wwv_flow_imp.id(83491429633499745)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_pv is select num_point_vente from personnel p,affectation f',
'where p.matricule = f.matricule',
'and trim(profil_app)= v(''app_user'');',
'',
'r_pv c_pv%rowtype;',
'',
'begin',
'  if :P159_PROFIL !=3 then',
'     open c_pv;',
'     fetch c_pv into r_pv;',
'     if c_pv%found then',
'         :P159_POINT_VENTE := r_pv.num_point_vente;',
'     end if;',
'     close c_pv;',
'  end if;',
'  end;'))
,p_attribute_02=>'P159_POINT_VENTE,P159_PROFIL'
,p_attribute_03=>'P159_POINT_VENTE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83492917345499747)
,p_event_id=>wwv_flow_imp.id(83491429633499745)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P159_POINT_VENTE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83491941277499745)
,p_event_id=>wwv_flow_imp.id(83491429633499745)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P159_POINT_VENTE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83493316161499747)
,p_name=>'refjoour'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P159_JOUR'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83493844933499748)
,p_event_id=>wwv_flow_imp.id(83493316161499747)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(152583698984495748)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83494320389499748)
,p_event_id=>wwv_flow_imp.id(83493316161499747)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare ',
'',
'nb number;',
'total number;',
'moy number;',
'',
'cursor c_tot is select sum(moyenne) t from average_sale_dow',
'where jour = :P159_JOUR',
'and numero_session=v(''app_session'');',
' r_tot c_tot%rowtype;',
' ',
'',
'',
'',
'begin',
'    open c_tot;',
'    fetch c_tot into r_tot;',
'    if c_tot%found then',
'       total := r_tot.t;',
'    end if;',
'    ',
'   ',
'    ',
'    moy :=nvl(total,0);',
'    ',
'    :P159_MOYENNE_JOUR :=  to_char(moy,''999G999G999G999G999G999G990'');',
'    ',
'    ',
'end;',
''))
,p_attribute_02=>'P159_JOUR,P159_MOYENNE_JOUR'
,p_attribute_03=>'P159_MOYENNE_JOUR'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83494714830499748)
,p_name=>'refj'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P159_JOUR_1,P159_PRODUIT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83495168634499748)
,p_event_id=>wwv_flow_imp.id(83494714830499748)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(152584446683495756)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83495627622499748)
,p_name=>'New'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P159_JOUR_1_1,P159_PRODUIT_1'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83496097556499750)
,p_event_id=>wwv_flow_imp.id(83495627622499748)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(114026939702022120)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83496464186499750)
,p_name=>'New_2'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P159_POINT_VENTE,P159_DATE_DEBUT,P159_DATE_FIN'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83496982751499750)
,p_event_id=>wwv_flow_imp.id(83496464186499750)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(308365813615525892)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83497545595499750)
,p_event_id=>wwv_flow_imp.id(83496464186499750)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(308363200386525889)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83498014349499751)
,p_event_id=>wwv_flow_imp.id(83496464186499750)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(113626673621056454)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83498519635499751)
,p_event_id=>wwv_flow_imp.id(83496464186499750)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(152584446683495756)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83498962813499751)
,p_event_id=>wwv_flow_imp.id(83496464186499750)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(114026939702022120)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83499540652499751)
,p_event_id=>wwv_flow_imp.id(83496464186499750)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(152583698984495748)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83500040869499753)
,p_event_id=>wwv_flow_imp.id(83496464186499750)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(308367318953525893)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83500540948499753)
,p_event_id=>wwv_flow_imp.id(83496464186499750)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(113627274664056460)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83500941912499753)
,p_name=>'choix'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P159_CHOIX'
,p_condition_element=>'P159_CHOIX'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83501387000499754)
,p_event_id=>wwv_flow_imp.id(83500941912499753)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P159_POINT_VENTE,P159_DATE_DEBUT,P159_DATE_FIN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83501948859499754)
,p_event_id=>wwv_flow_imp.id(83500941912499753)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P159_POINT_VENTE,P159_DATE_DEBUT,P159_DATE_FIN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83502400191499754)
,p_event_id=>wwv_flow_imp.id(83500941912499753)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P159_TB'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83502873982499754)
,p_event_id=>wwv_flow_imp.id(83500941912499753)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P159_TB'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83503296184499754)
,p_name=>'tb'
,p_event_sequence=>90
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P159_TB'
,p_condition_element=>'P159_TB'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83503794071499756)
,p_event_id=>wwv_flow_imp.id(83503296184499754)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_tb is select * from tableau_bord',
'where numero_tb = :P159_TB;',
'',
'r_tb c_tb%rowtype;',
'',
'val number;',
'begin',
'   open c_tb;',
'   fetch c_tb into r_tb;',
'   if c_tb%found then',
'     :P159_POINT_VENTE := r_tb.num_point_vente;',
'     :P159_DATE_DEBUT := r_tb.date_debut;',
'     :P159_DATE_FIN := r_tb.date_fin;',
'   end if;',
'   close c_tb;',
'   ',
'     select  round(sum(montant_bon)/count(*)) into val ',
'    from bons b',
'    where  FN_DATE_NUM(b.date_creation) between nvl(FN_DATE_NUM(:P159_DATE_DEBUT),FN_DATE_NUM(b.date_creation)) and nvl(FN_DATE_NUM(:P159_DATE_FIN),FN_DATE_NUM(b.date_creation))',
'    and b.num_espace_vente in (select num_espace_vente from espace_vente where num_point_vente =:P159_POINT_VENTE);',
'    ',
'    :P159_VALEUR_MOYENNE_BON := to_char(val,''999G999G999G999G999G999G990'');',
'   ',
'    select FN_TEMPS_MOYEN(:P159_DATE_DEBUT, :P159_DATE_FIN, :P159_POINT_VENTE) INTO val from dual;',
'    ',
'    :P159_TEMPS_MOYEN_BON:= to_char(val,''999G999G999G999G999G999G990'');',
'',
'end;'))
,p_attribute_02=>'P159_TB,P159_POINT_VENTE,P159_DATE_DEBUT,P159_DATE_FIN,P159_VALEUR_MOYENNE_BON,P159_TEMPS_MOYEN_BON'
,p_attribute_03=>'P159_POINT_VENTE,P159_DATE_DEBUT,P159_DATE_FIN,P159_VALEUR_MOYENNE_BON,P159_TEMPS_MOYEN_BON'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83504359415499756)
,p_event_id=>wwv_flow_imp.id(83503296184499754)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(308363200386525889)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83504814953499756)
,p_event_id=>wwv_flow_imp.id(83503296184499754)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(308365813615525892)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83505344149499756)
,p_event_id=>wwv_flow_imp.id(83503296184499754)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(152583698984495748)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83505813029499758)
,p_event_id=>wwv_flow_imp.id(83503296184499754)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(152584446683495756)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83506305486499758)
,p_event_id=>wwv_flow_imp.id(83503296184499754)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(308367318953525893)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83506815540499758)
,p_event_id=>wwv_flow_imp.id(83503296184499754)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(113626673621056454)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83507264641499758)
,p_event_id=>wwv_flow_imp.id(83503296184499754)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(113627274664056460)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83507808505499759)
,p_event_id=>wwv_flow_imp.id(83503296184499754)
,p_event_result=>'TRUE'
,p_action_sequence=>90
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(114026939702022120)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
