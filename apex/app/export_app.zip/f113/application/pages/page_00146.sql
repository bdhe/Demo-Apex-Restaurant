prompt --application/pages/page_00146
begin
--   Manifest
--     PAGE: 00146
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>146
,p_name=>'AnnulationBon'
,p_alias=>'ANNULATIONBON'
,p_page_mode=>'MODAL'
,p_step_title=>'AnnulationBon'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(131652269480199581)
,p_plug_name=>'Annulation bon'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(57182675620948761)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(131652269480199581)
,p_button_name=>'Annuler'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Annuler'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(57183074047948766)
,p_name=>'P146_NUM_BON'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(131652269480199581)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(57183539599948768)
,p_name=>'P146_PWD'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(131652269480199581)
,p_prompt=>'Mot de passe administrateur'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'submit_when_enter_pressed', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(57183861878948768)
,p_name=>'P146_VERIF'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(131652269480199581)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(57184322930948769)
,p_name=>'P146_ANN'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(131652269480199581)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(57184832920948786)
,p_validation_name=>'ver'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if verifpwd(:P146_PWD) != 1 then',
'   return ''Mot de passe administrateur incorrect'';',
'else',
'  :P146_VERIF :=1;',
'end if;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_imp.id(57183539599948768)
,p_error_display_location=>'INLINE_WITH_FIELD'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(57185068747948788)
,p_name=>'annulation'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(57182675620948761)
,p_condition_element=>'P146_VERIF'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(57185543583948788)
,p_event_id=>wwv_flow_imp.id(57185068747948788)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_bon is select * from bons',
'where num_bon = :P146_NUM_BON;',
'r_bon c_bon%rowtype;',
'',
'nb number;',
'begin',
'open c_bon;',
'  fetch c_bon into r_bon;',
'  if c_bon%found then',
'     if r_bon.paye = ''O'' then',
'        :P146_ANN:=1;',
'     else',
'        :P146_ANN:= 2;',
'        if r_bon.code_etat_bon = 1 then',
'             update bons set code_etat_bon = 3',
'             where num_bon = :P146_NUM_BON; ',
'        end if;',
'     end if;',
'  end if;',
'   close c_bon;',
'end;',
'  '))
,p_attribute_02=>'P146_NUM_BON,P146_ANN'
,p_attribute_03=>'P146_ANN'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(57186079185948790)
,p_event_id=>wwv_flow_imp.id(57185068747948788)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Mot de passe administrateur incorrect !'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(57186478132948790)
,p_name=>'FINANNUL'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P146_ANN'
,p_condition_element=>'P146_ANN'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'2'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(57186945036948790)
,p_event_id=>wwv_flow_imp.id(57186478132948790)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Annulation effectu&#xE9;e avec succ&#xE8;s'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(57187485613948790)
,p_event_id=>wwv_flow_imp.id(57186478132948790)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Le bon est d&#xE9;j&#xE0; r&#xE9;gl&#xE9;. Impossible d&#x27;annuler !'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(57187862156948790)
,p_name=>'check'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P146_PWD'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(57188426071948791)
,p_event_id=>wwv_flow_imp.id(57187862156948790)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if verifpwd(:P146_PWD) = 1 then',
'  :P146_VERIF :=1;',
'else',
'  :P146_VERIF :=0;',
'end if;'))
,p_attribute_02=>'P146_PWD,P146_VERIF'
,p_attribute_03=>'P146_VERIF'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp.component_end;
end;
/
