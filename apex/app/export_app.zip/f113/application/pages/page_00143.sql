prompt --application/pages/page_00143
begin
--   Manifest
--     PAGE: 00143
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>143
,p_name=>'Personalisation'
,p_alias=>'PERSONALISATION'
,p_page_mode=>'MODAL'
,p_step_title=>'Personalisation'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(154839274068627420)
,p_name=>'Personaliser'
,p_template=>4501440665235496320
,p_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors:t-BadgeList--small:t-BadgeList--dash:t-BadgeList--cols:t-Report--hideNoPagination'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'TABLE'
,p_query_table=>'BON_INGREDIENT'
,p_query_where=>wwv_flow_string.join(wwv_flow_t_varchar2(
'NUM_detail_bon = :P143_NUM_DETAIL_BON',
''))
,p_include_rowid_column=>false
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P143_NUM_DETAIL_BON'
,p_lazy_loading=>false
,p_query_row_template=>2104643962563030528
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_no_data_found=>'Ce produit n''est pas personnalisable !'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83755079009290634)
,p_query_column_id=>1
,p_column_alias=>'NUM_BON'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83755539054290636)
,p_query_column_id=>2
,p_column_alias=>'NUM_DETAIL_BON'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83755888393290636)
,p_query_column_id=>3
,p_column_alias=>'NUM_PRODUIT'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83756354475290636)
,p_query_column_id=>4
,p_column_alias=>'PRO_NUM_PRODUIT'
,p_column_display_sequence=>4
,p_column_link=>'#'
,p_column_linktext=>'#SIGNE# #LIBELLE#'
,p_column_link_attr=>'id=''#PRO_NUM_PRODUIT#'' class="perso" title="#LIBELLE#"'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83756707924290637)
,p_query_column_id=>5
,p_column_alias=>'SIGNE'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83757154163290637)
,p_query_column_id=>6
,p_column_alias=>'LIBELLE'
,p_column_display_sequence=>6
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83757543441290645)
,p_name=>'P143_NUM_DETAIL_BON'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(154839274068627420)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83757932682290651)
,p_name=>'P143_NUM_PRODUIT_TEMP'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(154839274068627420)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83758292344290678)
,p_name=>'perso'
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'a.perso'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83758855674290681)
,p_event_id=>wwv_flow_imp.id(83758292344290678)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P143_NUM_PRODUIT_TEMP'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.id'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83759353113290683)
,p_event_id=>wwv_flow_imp.id(83758292344290678)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_ing is select * from bon_ingredient',
'where pro_num_produit = :P143_NUM_PRODUIT_TEMP',
'and num_detail_bon = :P143_NUM_DETAIL_BON;',
'',
'r_ing c_ing%rowtype;',
'',
'begin',
'      open c_ing;',
'      fetch c_ing into r_ing;',
'      if c_ing%found then',
'            if r_ing.signe = ''+'' then',
'               update bon_ingredient set signe = ''-'' where pro_num_produit = :P143_NUM_PRODUIT_TEMP',
'               and num_detail_bon = :P143_NUM_DETAIL_BON;',
'            else',
'               update bon_ingredient set signe = ''+'' where pro_num_produit = :P143_NUM_PRODUIT_TEMP',
'               and num_detail_bon = :P143_NUM_DETAIL_BON;',
'            end if;',
'      end if;',
'      close c_ing;',
'      commit;',
'end;'))
,p_attribute_02=>'P143_NUM_DETAIL_BON,P143_NUM_PRODUIT_TEMP'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83759794621290684)
,p_event_id=>wwv_flow_imp.id(83758292344290678)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(154839274068627420)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
