prompt --application/pages/page_00160
begin
--   Manifest
--     PAGE: 00160
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>160
,p_name=>'Journal_ventesr_1'
,p_alias=>'JOURNAL-VENTESR-1'
,p_page_mode=>'NON_MODAL'
,p_step_title=>'Journal_ventesr_1'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_resizable=>'Y'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(86149440357572448)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'imprimer'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'  ',
'  ',
'  CURSOR crParams IS',
'    SELECT trim(nom_parametre) 	as NAME,',
'           valeur_num    		as VALUE',
'      FROM parametres_etats',
'      where code_etat = 2;',
'	   ',
'  RepName  VARCHAR2(200);',
'  rParam  PK_JRXML2PDF_REPGEN.tParameter;',
'  lParams PK_JRXML2PDF_REPGEN.tParamList;',
'  bl BLOB;',
'  ',
'BEGIN',
'    ',
'    ',
'        FOR rec IN crParams LOOP',
'            rParam.vcName:=rec.NAME;',
'            rParam.vcValue:=rec.VALUE;',
'            lParams(lParams.COUNT+1):=rParam;',
'        END LOOP;',
'',
'        RepName := ''jventesr'';',
'        bl :=PK_JRXML2PDF_REPGEN.FK_RUN(i_vcName =>RepName,',
'                                        i_lParams=>lParams);',
'',
'        PK_JRXML2PDF_REPGEN.PR_SHOW_REPORT(bl);',
'        APEX_APPLICATION.STOP_APEX_ENGINE;',
'        ',
'       ',
'',
'END;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>86149440357572448
);
wwv_flow_imp.component_end;
end;
/
