prompt --application/pages/page_00178
begin
--   Manifest
--     PAGE: 00178
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>178
,p_name=>'Comptoir'
,p_alias=>'COMPTOIR1'
,p_step_title=>'Comptoir'
,p_allow_duplicate_submissions=>'N'
,p_reload_on_submit=>'A'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'ON'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var audio = new Audio("#APP_IMAGES#dindong.mpeg");',
'        function myFunction() {',
'        audio.play();',
'}'))
,p_javascript_code_onload=>'setInterval("jQuery(''#encours'').trigger(''apexrefresh'');", 40000);'
,p_css_file_urls=>'#APP_IMAGES#resto.css'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* Scroll Results Only in Side Column */',
'.t-Body-side {',
'    display: flex;',
'    flex-direction: column;',
'    overflow: hidden;',
'}',
'.search-results {',
'    flex: 1;',
'    overflow: auto;',
'}',
'/* Format Search Region */',
'.search-region {',
'    border-bottom: 1px solid rgba(0,0,0,.1);',
'    flex-shrink: 0;',
'}',
'.total {',
'    height: 100px',
'}',
'',
'.a-CardView-items--grid3col {',
'  height: 500px;',
'  overflow-y: scroll;',
'  scrollbar-width: none;',
'  }',
'',
'',
'',
'.a-CardView-items--grid2col',
'{',
'  height: 500px;',
'  overflow-y: scroll;',
'  scrollbar-width: none;',
'  }',
'',
'',
'.a-CardView-fullLink{',
'  height:200px;',
'  width: 400px;',
'}',
'',
'.typeprd{',
'    font-weight: bold;',
'    text-align: center;',
'    font-size: large;',
'    color: green;',
'}'))
,p_step_template=>4072355960268175073
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'23'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(79319477461875197)
,p_plug_name=>'Boutons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'REGION_POSITION_08'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(82208768633834976)
,p_name=>'Recapitulatif'
,p_template=>4501440665235496320
,p_display_sequence=>90
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_grid_column_span=>2
,p_display_point=>'REGION_POSITION_08'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''Commandes en cours'' libelle,count(*) nbre from bons',
'where fn_date_num(date_bon)=fn_date_num(:P178_DATE_VACATION)',
'and paye=''O''',
'and livre=''N''',
'union',
'select ''Commandes en cours internet'' libelle,count(*) nbre from bons',
'where fn_date_num(date_bon)=fn_date_num(:P178_DATE_VACATION)',
'and paye=''O''',
'and livre=''N''',
'and trim(code_utilisateur) =''CLTWEB''',
'union',
'select ''Toutes les Commandes'' libelle,count(*) nbre from bons',
'where fn_date_num(date_bon)=fn_date_num(:P178_DATE_VACATION)',
'and paye=''O''',
';',
''))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P178_DATE_VACATION'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(82208928704834977)
,p_query_column_id=>1
,p_column_alias=>'LIBELLE'
,p_column_display_sequence=>10
,p_column_heading=>'Libelle'
,p_report_column_width=>250
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(82208961403834978)
,p_query_column_id=>2
,p_column_alias=>'NBRE'
,p_column_display_sequence=>20
,p_column_heading=>'Nbre'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_report_column_width=>90
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(82209222336834980)
,p_plug_name=>'Libelle'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>80
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_08'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(82211651495835004)
,p_plug_name=>'Nouveau'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'REGION_POSITION_08'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(280552639239684875)
,p_plug_name=>'Infos Vacation'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_05'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(281873361492405598)
,p_name=>'Encours Bons'
,p_region_name=>'encours'
,p_template=>4501440665235496320
,p_display_sequence=>100
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_display_point=>'REGION_POSITION_08'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select rowid,num_bon id1,num_bon id,num_bon,num_table Ref,date_bon,montant_bon - nvl((select remise+arrondi from recu where num_bon = b.num_bon and rownum=1),0) montant_bon ,num_espace_vente,',
'livre,paye,code_utilisateur,code_etat_bon,date_creation,OBSERVATION',
'from bons b',
'where paye =''N''',
'and code_etat_bon in (1,2)',
'and num_espace_vente IN ( :P178_NUMESPACE,1000)',
'order by num_bon ;  '))
,p_header=>'<div style="height:200px;overflow:scroll;scrollbar-width: none;">  '
,p_footer=>'</div>'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P178_NUMESPACE'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>100
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81635060300508551)
,p_query_column_id=>1
,p_column_alias=>'ROWID'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81635451749508553)
,p_query_column_id=>2
,p_column_alias=>'ID1'
,p_column_display_sequence=>12
,p_column_heading=>'Annul.'
,p_column_link=>'f?p=&APP_ID.:146:&SESSION.::&DEBUG.:RP:P146_NUM_BON:#NUM_BON#'
,p_column_linktext=>'<span class="t-Icon fa fa-trash-o" aria-hidden="true"></span>'
,p_column_link_attr=>unistr('title="Annuler bon N\00B0 : #NUM_BON#"')
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81635798787508553)
,p_query_column_id=>3
,p_column_alias=>'ID'
,p_column_display_sequence=>13
,p_column_heading=>'Select.'
,p_column_link=>'#'
,p_column_linktext=>'<span class="t-Icon fa fa-toggle-up affbons-note" aria-hidden="true"></span>'
,p_column_link_attr=>'id=''#ID#'' class="affbons t-Button t-Button--danger t-Button--simple t-Button--small" title="Selectionner Bons: #NUM_BON#"'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81636200163508554)
,p_query_column_id=>4
,p_column_alias=>'NUM_BON'
,p_column_display_sequence=>3
,p_column_heading=>unistr('N\00B0 Bon')
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
,p_print_col_width=>'90'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81636561976508554)
,p_query_column_id=>5
,p_column_alias=>'REF'
,p_column_display_sequence=>2
,p_column_heading=>'Ref'
,p_report_column_width=>90
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81636989330508554)
,p_query_column_id=>6
,p_column_alias=>'DATE_BON'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81637449323508556)
,p_query_column_id=>7
,p_column_alias=>'MONTANT_BON'
,p_column_display_sequence=>5
,p_column_heading=>'Montant '
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_report_column_width=>90
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81637808850508556)
,p_query_column_id=>8
,p_column_alias=>'NUM_ESPACE_VENTE'
,p_column_display_sequence=>4
,p_column_heading=>'Espace Vente'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(81019840160213400)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81638182258508558)
,p_query_column_id=>9
,p_column_alias=>'LIVRE'
,p_column_display_sequence=>6
,p_column_heading=>unistr('Livr\00E9')
,p_column_alignment=>'CENTER'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>unistr('STATIC:Oui;O,Non;N,Pr\00EAt;P')
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81638562419508558)
,p_query_column_id=>10
,p_column_alias=>'PAYE'
,p_column_display_sequence=>7
,p_column_heading=>unistr('Pay\00E9')
,p_column_alignment=>'CENTER'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(80976620147194334)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81638979145508558)
,p_query_column_id=>11
,p_column_alias=>'CODE_UTILISATEUR'
,p_column_display_sequence=>8
,p_column_heading=>'Emetteur'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81639412795508559)
,p_query_column_id=>12
,p_column_alias=>'CODE_ETAT_BON'
,p_column_display_sequence=>9
,p_column_heading=>'Etat Bon'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(81311737542361267)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81639823360508559)
,p_query_column_id=>13
,p_column_alias=>'DATE_CREATION'
,p_column_display_sequence=>11
,p_column_heading=>unistr('Cr\00E9e \00E0 ')
,p_column_format=>'HH24:MI'
,p_report_column_width=>60
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81640217095508559)
,p_query_column_id=>14
,p_column_alias=>'OBSERVATION'
,p_column_display_sequence=>14
,p_column_heading=>'Observations'
,p_report_column_width=>760
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(309047892876127692)
,p_plug_name=>' produit type'
,p_region_name=>'TYPE_PRD_IR'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleC'
,p_plug_template=>2072724515482255512
,p_plug_display_sequence=>30
,p_plug_grid_column_span=>2
,p_plug_display_point=>'REGION_POSITION_08'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*select "CODE_TYPE_PRODUIT",',
'    null link_class,',
'    apex_page.get_url(p_items => ''P178_CODE_TYPE_PRODUIT'', p_values => "CODE_TYPE_PRODUIT") link,',
'    null icon_class,',
'    null link_attr,',
'    null icon_color_class,',
'    case when nvl(:P178_CODE_TYPE_PRODUIT,''0'') = "CODE_TYPE_PRODUIT"',
'      then ''is-active'' ',
'      else '' ''',
'    end list_class,',
'    substr("LIBELLE_TYPE_PRODUIT", 1, 50)||( case when length("LIBELLE_TYPE_PRODUIT") > 50 then ''...'' end ) list_title,',
'    substr("CODE_TYPE_PRODUIT", 1, 50)||( case when length("CODE_TYPE_PRODUIT") > 50 then ''...'' end ) list_text,',
'    null list_badge',
'from "TYPE_PRODUIT" x',
'where (:P178_SEARCH is null',
'        or upper(x."LIBELLE_TYPE_PRODUIT") like ''%''||upper(:P178_SEARCH)||''%''',
'        or upper(x."CODE_TYPE_PRODUIT") like ''%''||upper(:P178_SEARCH)||''%''',
'    )',
'and x."ACTIF" =''O''',
'and x."CODE_FAMILLE" = :P178_CODE_FAMILLE',
'order by "CODE_TYPE_PRODUIT"*/',
'',
'select code_type_produit ID,code_type_produit,',
'       LIBELLE_TYPE_PRODUIT,IMAGE,',
'        MIMETYPE,',
'        FILENAME,',
'        IMAGE_LAST_UPDATE',
'       from TYPE_PRODUIT',
'       where ACTIF =''O''',
'       --and CODE_FAMILLE = :P178_FAMILLE',
'order by code_type_produit'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(79320864776875211)
,p_region_id=>wwv_flow_imp.id(309047892876127692)
,p_layout_type=>'GRID'
,p_grid_column_count=>2
,p_title_adv_formatting=>false
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_second_body_column_name=>'LIBELLE_TYPE_PRODUIT'
,p_second_body_css_classes=>'typeprd'
,p_icon_source_type=>'BLOB'
,p_icon_blob_column_name=>'IMAGE'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'ID'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(79320969868875212)
,p_card_id=>wwv_flow_imp.id(79320864776875211)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'#'
,p_link_attributes=>'data-action=select data-value=&ID.'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(309063329264127704)
,p_plug_name=>'Produits'
,p_region_template_options=>'#DEFAULT#:t-CardsRegion--styleA'
,p_plug_template=>2072724515482255512
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_display_point=>'REGION_POSITION_08'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUM_PRODUIT ID,NUM_PRODUIT,',
'       DESIGNATION_PRODUIT,description,fn_promo(NUM_PRODUIT) promo,PRODUCT_IMAGE,',
'        MIMETYPE,',
'        FILENAME,',
'        IMAGE_LAST_UPDATE',
'       from PRODUITS',
'where actif = ''O''',
'and code_type_produit = :P178_TYPE_PRODUIT',
'and mimetype is not null',
'order by designation_produit',
''))
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P178_TYPE_PRODUIT'
,p_plug_query_num_rows_type=>'SCROLL'
,p_show_total_row_count=>false
,p_plug_footer=>' '
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(82208526105834973)
,p_region_id=>wwv_flow_imp.id(309063329264127704)
,p_layout_type=>'GRID'
,p_grid_column_count=>3
,p_title_adv_formatting=>false
,p_title_column_name=>'DESIGNATION_PRODUIT'
,p_sub_title_adv_formatting=>false
,p_sub_title_column_name=>'PROMO'
,p_body_adv_formatting=>false
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'BLOB'
,p_icon_blob_column_name=>'PRODUCT_IMAGE'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'NUM_PRODUIT'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(82208688074834975)
,p_card_id=>wwv_flow_imp.id(82208526105834973)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:106:&SESSION.::&DEBUG.::P106_NUM_PRODUIT:&NUM_PRODUIT.'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(309106544428035668)
,p_plug_name=>'Bon'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>5
,p_plug_display_point=>'REGION_POSITION_08'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(309107480778035677)
,p_name=>unistr('D\00E9tailsbon')
,p_template=>4501440665235496320
,p_display_sequence=>70
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_new_grid_column=>false
,p_display_point=>'REGION_POSITION_08'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select d.ROWID,d.num_detail_bon ID,FN_PERSONNALISATION(d.num_detail_bon) perso,d.num_detail_bon,d.num_bon,substr(designation_produit,1,30) ||( case when length(designation_produit) > 30 then ''...'' end ) designation_produit,',
'd.qte_bon,d.pu_bon,d.code_utilisateur,d.total',
'from details_bon_temp d,produits p',
'where d.num_produit = p.num_produit',
'and trim(d.util_modif) = trim(v(''app_user''))',
'order by d.num_detail_bon;'))
,p_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'   <div style="height:450px;overflow:scroll;scrollbar-width: none;"> ',
''))
,p_footer=>'</div>  '
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P178_NUM_VACATION'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>1000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81659586710508590)
,p_query_column_id=>1
,p_column_alias=>'ROWID'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81660050558508590)
,p_query_column_id=>2
,p_column_alias=>'ID'
,p_column_display_sequence=>28
,p_column_heading=>'Suppr.'
,p_column_link=>'#'
,p_column_linktext=>'<span class="t-Icon fa fa-trash-o" aria-hidden="true"></span>'
,p_column_link_attr=>'id=''#ID#'' class="delete t-Button t-Button--danger t-Button--simple t-Button--small" title="Supprimer : #DESIGNATION_PRODUIT#"'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81660389641508590)
,p_query_column_id=>3
,p_column_alias=>'PERSO'
,p_column_display_sequence=>6
,p_column_heading=>'Personnaliser'
,p_column_link=>'f?p=&APP_ID.:143:&SESSION.::&DEBUG.:RP:P143_NUM_DETAIL_BON:#NUM_DETAIL_BON#'
,p_column_linktext=>'#PERSO#'
,p_column_link_attr=>'title="Personaliser le produit"'
,p_column_alignment=>'CENTER'
,p_report_column_width=>100
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81660837677508592)
,p_query_column_id=>4
,p_column_alias=>'NUM_DETAIL_BON'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81661194512508592)
,p_query_column_id=>5
,p_column_alias=>'NUM_BON'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81661607459508594)
,p_query_column_id=>6
,p_column_alias=>'DESIGNATION_PRODUIT'
,p_column_display_sequence=>5
,p_column_heading=>'Designation '
,p_report_column_width=>250
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81662015337508594)
,p_query_column_id=>7
,p_column_alias=>'QTE_BON'
,p_column_display_sequence=>7
,p_column_heading=>'Qte '
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_report_column_width=>60
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81662398409508594)
,p_query_column_id=>8
,p_column_alias=>'PU_BON'
,p_column_display_sequence=>8
,p_column_heading=>'Pu '
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_report_column_width=>90
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(81662791563508595)
,p_query_column_id=>9
,p_column_alias=>'CODE_UTILISATEUR'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38144395887765146)
,p_query_column_id=>10
,p_column_alias=>'TOTAL'
,p_column_display_sequence=>18
,p_column_heading=>'Total'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_report_column_width=>100
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81650536734508578)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(79319477461875197)
,p_button_name=>'OperationsC'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary:t-Button--stretch:t-Button--gapTop:t-Button--gapBottom'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Caisse'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:104:&SESSION.::&DEBUG.::P104_NUM_VAC:&P178_NUM_VACATION.'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81651688699508578)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(79319477461875197)
,p_button_name=>'Don'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary:t-Button--stretch:t-Button--gapTop:t-Button--gapBottom'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Don'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:77:&SESSION.::&DEBUG.:RP:P77_NUM_BON,P77_QTE:&P178_NUM_BON.,0'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81650889111508578)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(79319477461875197)
,p_button_name=>'RefreshEncours'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary:t-Button--stretch:t-Button--gapTop:t-Button--gapBottom'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Rafra\00EEchir')
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>2
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81651280462508578)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(79319477461875197)
,p_button_name=>'Effacer'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary:t-Button--stretch:t-Button--gapTop:t-Button--gapBottom'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Effacer'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81652071674508579)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(79319477461875197)
,p_button_name=>'Enregistrer'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary:t-Button--stretch:t-Button--gapTop:t-Button--gapBottom'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Enregistrer'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>2
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81652490060508579)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(79319477461875197)
,p_button_name=>'Imprimer'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary:t-Button--stretch:t-Button--gapTop:t-Button--gapBottom'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Imprimer'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:141:&SESSION.::&DEBUG.:RP::'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>2
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(81652861669508579)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(79319477461875197)
,p_button_name=>'Regler'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary:t-Button--stretch:t-Button--gapTop:t-Button--gapBottom'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Regler'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:172:&SESSION.::&DEBUG.:RP,172:P172_MT_ARRONDI,P172_RELIQUAT,P172_ARRONDI,P172_MONTANT_REMISE:&P178_ZERO.,&P178_ZERO.,&P178_ZERO.,&P178_ZERO.'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81631891473508547)
,p_name=>'P178_DATE_VACATION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(280552639239684875)
,p_use_cache_before_default=>'NO'
,p_format_mask=>'DD/MM/YYYY'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.DATEHEURE_DEBUT_VAC ',
'from vacation v,affectation a,personnel p',
'where v.num_espace_vente = a.num_espace_vente',
'and a.matricule = p.matricule',
'and cloture = ''N''',
'and trim(p.profil_app) = trim(nvl(v(''app_user''), user));'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81632276787508547)
,p_name=>'P178_PV'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(280552639239684875)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pv.nom_point_vente',
'from affectation a,personnel p,espace_vente e,point_vente pv',
'where a.matricule = p.matricule',
'and a.num_espace_vente = e.num_espace_vente',
'and e.num_point_vente = pv.num_point_vente',
'and trim(profil_app) = nvl(v(''app_user''), user);'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81632728906508548)
,p_name=>'P178_ESPACE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(280552639239684875)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.nom_espace',
'from affectation a,personnel p,espace_vente e',
'where a.matricule = p.matricule',
'and a.num_espace_vente = e.num_espace_vente',
'and trim(profil_app) = nvl(v(''app_user''), user);'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81633088188508548)
,p_name=>'P178_USER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(280552639239684875)
,p_use_cache_before_default=>'NO'
,p_source=>'select v(''app_user'') from dual;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81633548884508550)
,p_name=>'P178_NUM_PV'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(280552639239684875)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.num_point_vente',
'from affectation a,personnel p,espace_vente e',
'where a.matricule = p.matricule',
'and a.num_espace_vente = e.num_espace_vente',
'and trim(profil_app) = nvl(v(''app_user''), user);'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81633902736508550)
,p_name=>'P178_NUMESPACE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(280552639239684875)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.num_espace_vente',
'from affectation a,personnel p,espace_vente e',
'where a.matricule = p.matricule',
'and a.num_espace_vente = e.num_espace_vente',
'and trim(profil_app) = nvl(v(''app_user''), user);'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81634333608508550)
,p_name=>'P178_NUM_VACATION'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(280552639239684875)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select num_vacation',
'from vacation',
'where  num_point_vente = :p178_num_pv',
'and num_espace_vente = :P178_NUMESPACE',
'and cloture = ''N'';'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81640635058508561)
,p_name=>'P178_NUM_BON_TEMP'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(281873361492405598)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81640977417508561)
,p_name=>'P178_NUM_ESPACE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(281873361492405598)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.num_espace_vente',
'from vacation v',
'where to_char(DATEHEURE_DEBUT_VAC,''ddmmyyyy'') = to_char(sysdate,''ddmmyyyy'')',
'and trim(v.code_utilisateur) = trim(nvl(v(''app_user''), user));'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81641393460508561)
,p_name=>'P178_ANN'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(281873361492405598)
,p_use_cache_before_default=>'NO'
,p_item_default=>'0'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81641834037508562)
,p_name=>'P178_COMMANDES'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(281873361492405598)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81642091305508564)
,p_name=>'P178_NBC'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(281873361492405598)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81648980638508575)
,p_name=>'P178_NUM_PRD'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(309063329264127704)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81649378108508575)
,p_name=>'P178_TYPE_PRODUIT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(309047892876127692)
,p_use_cache_before_default=>'NO'
,p_item_default=>'22'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81654089023508581)
,p_name=>'P178_NUM_BON'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(309106544428035668)
,p_prompt=>unistr('N\00B0Bon')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_colspan=>1
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81654499432508583)
,p_name=>'P178_TABLE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(309106544428035668)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Cmde'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_colspan=>1
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81654939649508583)
,p_name=>'P178_CLIENT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(309106544428035668)
,p_item_default=>'1'
,p_prompt=>'Client'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'CLIENT'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nom_clt as d,',
'       num_clt as r',
'  from client',
' order by 1'))
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81655360043508583)
,p_name=>'P178_SURPLACE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(309106544428035668)
,p_use_cache_before_default=>'NO'
,p_item_default=>'S'
,p_prompt=>'Type de conso'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'SURPLACE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select LIBELLE as d,',
'       CODE_TYPE_CONSO as r',
'  from type_conso',
' order by 1'))
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81655682202508584)
,p_name=>'P178_TICKET'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(309106544428035668)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('R\00E9f\00E9rence')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81656095110508584)
,p_name=>'P178_NBPERS'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(309106544428035668)
,p_use_cache_before_default=>'NO'
,p_item_default=>'1'
,p_prompt=>'Nb Pers.'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TABLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select num_table as d,',
'       num_table as r',
'  from tables',
' order by 1'))
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_colspan=>2
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81656499355508586)
,p_name=>'P178_ZERO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(309106544428035668)
,p_item_default=>'0'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81656905646508586)
,p_name=>'P178_MODIF'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(309106544428035668)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81657336991508586)
,p_name=>'P178_NOUVEAU'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(309106544428035668)
,p_use_cache_before_default=>'NO'
,p_item_default=>'3'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81657729974508587)
,p_name=>'P178_VERIF'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(309106544428035668)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81658092895508587)
,p_name=>'P178_VERIF_REF'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(309106544428035668)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81658488813508587)
,p_name=>'P178_PAYE'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(309106544428035668)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81658868532508589)
,p_name=>'P178_REFOK'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(309106544428035668)
,p_use_cache_before_default=>'NO'
,p_item_default=>'1'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81664023765508597)
,p_name=>'P178_DELETE_ID'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(309107480778035677)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81664383330508597)
,p_name=>'P178_TOTAL'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(309107480778035677)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(81664769041508598)
,p_name=>'P178_TOTAL_AFF'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(82211651495835004)
,p_prompt=>'Total '
,p_format_mask=>'FML999G999G999G999G990D00'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'Style="text-align: right; font-size: 30px;font-weight: bold"'
,p_colspan=>12
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(82209082626834979)
,p_name=>'P178_NEW'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(82209222336834980)
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81672186608508611)
,p_name=>'Refresh on Dialog Close'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(309063329264127704)
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81672697799508611)
,p_event_id=>wwv_flow_imp.id(81672186608508611)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(309063329264127704)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81673218455508611)
,p_event_id=>wwv_flow_imp.id(81672186608508611)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(309107480778035677)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81673694883508612)
,p_event_id=>wwv_flow_imp.id(81672186608508611)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if nvl(:P178_NUM_BON,0) =0 then',
'    select sum(nvl(qte_bon,0)*nvl(pu_bon,0)) into :P178_TOTAL from details_bon_temp',
'    where trim(util_modif) = nvl(v(''app_user''), user);',
'else ',
'    select sum(nvl(qte_bon,0)*nvl(pu_bon,0)) into :P178_TOTAL from details_bon_temp',
'     where num_bon = :P178_NUM_BON;',
'end if;',
'if :P178_NOUVEAU < 5 then',
'   :P178_NOUVEAU := 1;',
'end if;'))
,p_attribute_02=>'P178_TOTAL,P178_NUM_BON,P178_NOUVEAU'
,p_attribute_03=>'P178_TOTAL,P178_NOUVEAU'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81674139783508612)
,p_name=>'SUPPDETBON'
,p_event_sequence=>60
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'a.delete'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81675600381508615)
,p_event_id=>wwv_flow_imp.id(81674139783508612)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Etes vous s&#xFB;r de vouloir supprimer cette ligne? Attention la suppression ne se fera pas si le bon est d&#xE9;j&#xE0; r&#xE8;gl&#xE9; !'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81676119401508615)
,p_event_id=>wwv_flow_imp.id(81674139783508612)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_DELETE_ID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.id'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81674651035508614)
,p_event_id=>wwv_flow_imp.id(81674139783508612)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'nb number;',
'',
'cursor c_bon is select paye from bons b,details_bon d',
'where b.num_bon = d.num_bon',
'and  num_detail_bon = :P178_DELETE_ID;',
'',
'r_bon c_bon%rowtype;',
'p number;',
'',
'begin',
'      p :=0;',
'      open c_bon;',
'      fetch c_bon into r_bon;',
'      if c_bon%found then',
'         if r_bon.paye =''O'' then p:=1; end if;',
'      end if;',
'      close c_bon;',
'      if p=0 then',
'          select nvl(count(*),0) into nb from details_bon_temp',
'          where num_bon = :p178_num_bon',
'          and trim(util_modif) = trim(v(''app_user''));',
'          delete from details_bon_temp',
'          where num_detail_bon = :P178_DELETE_ID',
'          and trim(util_modif) = trim(v(''app_user''));',
'          if nvl(:p178_num_bon,0) > 0 then',
'',
'              delete from details_bon',
'              where num_detail_bon = :P178_DELETE_ID and num_bon = :p178_num_bon ;',
'              if nb = 1 then',
'                 update bons set code_etat_bon = 3',
'                 where num_bon = :p178_num_bon ;',
'              end if;',
'           end if;',
'       end if;',
' ',
'  commit;',
'  select sum(nvl(qte_bon,0)*nvl(pu_bon,0)) into :P178_TOTAL from details_bon_temp',
'  where trim(util_modif)=trim(v(''app_user''));',
'',
'end;',
'  '))
,p_attribute_02=>'P178_NUM_BON,P178_TOTAL,P178_DELETE_ID'
,p_attribute_03=>'P178_TOTAL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81675098384508614)
,p_event_id=>wwv_flow_imp.id(81674139783508612)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(309107480778035677)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81676557007508615)
,p_name=>'SUPPBON'
,p_event_sequence=>70
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'a.deleteB'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81677056851508617)
,p_event_id=>wwv_flow_imp.id(81676557007508615)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Etes vous s&#xFB;r de vouloir annuler ce bon?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81677519703508617)
,p_event_id=>wwv_flow_imp.id(81676557007508615)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_NUM_BON_TEMP'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.id'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81678050535508617)
,p_event_id=>wwv_flow_imp.id(81676557007508615)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_bon is select * from bons',
'where num_bon = :P178_NUM_BON_TEMP;',
'r_bon c_bon%rowtype;',
'',
'nb number;',
'begin',
'open c_bon;',
'  fetch c_bon into r_bon;',
'  if c_bon%found then',
'     if r_bon.paye = ''O'' then',
'        :P178_ANN :=1;',
'     else',
'        :P178_ANN := 2;',
'        if r_bon.code_etat_bon = 1 then',
'             update bons set code_etat_bon = 3',
'             where num_bon = :P178_NUM_BON_TEMP; ',
'        end if;',
'     end if;',
'  end if;',
'   close c_bon;',
'end;',
'  '))
,p_attribute_02=>'P178_NUM_BON_TEMP,P178_ANN'
,p_attribute_03=>'P178_ANN'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81678508879508619)
,p_event_id=>wwv_flow_imp.id(81676557007508615)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(281873361492405598)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81678909454508619)
,p_name=>'AffBons'
,p_event_sequence=>80
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'a.affbons'
,p_condition_element=>'P178_NUM_BON'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81679368647508619)
,p_event_id=>wwv_flow_imp.id(81678909454508619)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Veuillez effacer le bon courant avant!'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81679912023508620)
,p_event_id=>wwv_flow_imp.id(81678909454508619)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_NUM_BON_TEMP'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.id'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81680429228508620)
,p_event_id=>wwv_flow_imp.id(81678909454508619)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'cursor c_bon is select code_etat_bon,paye,livre from bons',
'where num_bon = :P178_NUM_BON_TEMP;',
'r_bon c_bon%rowtype;',
'',
'begin',
' if nvl(:p178_num_bon,0) != 0 then',
'    update bons set code_etat_bon = 1',
'    where num_bon = :p178_num_bon;',
'  end if;',
'',
'  open c_bon;',
'  fetch c_bon into r_bon;',
'  if c_bon%found then',
'    if r_bon.code_etat_bon = 1 then',
'          :P178_PAYE := r_bon.paye;',
'          if r_bon.paye = ''N'' then :p178_nouveau := 4; -- bon non paye',
'          elsif r_bon.paye = ''O'' and r_bon.livre = ''N'' then :p178_nouveau := 5; -- bon paye non pret',
'          elsif r_bon.livre = ''P'' then :p178_nouveau := 6; end if;-- bon paye  pret non livrer',
'          ',
'          delete details_bon_temp  where trim(util_modif) = v(''app_user'');',
'          insert into details_bon_temp',
'          select NUM_DETAIL_BON,NUM_PRODUIT ,NUM_BON,QTE_BON,PU_BON,QTE_RETOURNE,QTE_CONSIGNE,ETAT_DETAIL_BON,',
'            v(''app_user'') ,DATE_CREATION ,LIVRE,TYPE_DETAIL_BON,NUM_MENU,QTE_BON*PU_BON,v(''app_user'')',
'            from details_bon',
'          where num_bon = :P178_NUM_BON_TEMP;',
'',
'            update bons set code_etat_bon = 2,montant_bon = (select sum(qte_bon*pu_bon) from details_bon  where num_bon = :P178_NUM_BON_TEMP )',
'            where num_bon = :P178_NUM_BON_TEMP;',
'',
'          :p178_num_bon := :P178_NUM_BON_TEMP;',
'',
'           select num_clt,num_table,code_traitement,CONSIGATION,num_ticket into :p178_client,:p178_table,:p178_surplace,:p178_nbpers,:p178_ticket',
'          from bons',
'          where num_bon = :P178_NUM_BON_TEMP;',
'          :P178_modif := 0;',
'    else',
'          :p178_modif :=1;',
'    end if;',
'  end if;',
'  close c_bon;',
'      ',
'      --:p178_nouveau := 0;',
'      ',
'             commit;',
'',
'end;',
'  '))
,p_attribute_02=>'P178_NUM_BON_TEMP,P178_NOUVEAU,P178_CLIENT,P178_TABLE,P178_SURPLACE,P178_NBPERS,P178_NUM_BON,P178_TICKET,P178_MODIF,P178_PAYE'
,p_attribute_03=>'P178_NUM_BON,P178_CLIENT,P178_SURPLACE,P178_NBPERS,P178_TABLE,P178_NOUVEAU,P178_TICKET,P178_MODIF,P178_PAYE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81680873817508620)
,p_event_id=>wwv_flow_imp.id(81678909454508619)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nvl(sum(pu_bon*qte_bon),0) into :P178_TOTAL from details_bon_temp',
'where trim(util_modif) = trim(v(''app_user''));'))
,p_attribute_02=>'P178_TOTAL'
,p_attribute_03=>'P178_TOTAL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81681382624508622)
,p_event_id=>wwv_flow_imp.id(81678909454508619)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(309107480778035677)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81681864870508622)
,p_event_id=>wwv_flow_imp.id(81678909454508619)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(281873361492405598)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81682296885508622)
,p_name=>'CreerBon'
,p_event_sequence=>90
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'a.affiche'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81682760984508623)
,p_event_id=>wwv_flow_imp.id(81682296885508622)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_NUM_PRD'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.id'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81683270464508623)
,p_event_id=>wwv_flow_imp.id(81682296885508622)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_bon is select * from bons_temp',
'where trim(code_utilisateur) = trim(nvl(v(''app_user''), user));',
'',
'r_bon c_bon%rowtype;',
'',
'',
'begin',
'    open c_bon;',
'    fetch c_bon into r_bon;',
'    if c_bon%notfound then',
'       insert into bons_temp',
'       values(:p178_num_bon/*NUM_BON*/ ,:p178_table/*NUM_TABLE*/,:p178_client/*NUM_CLT*/,:p178_num_espace/*NUM_ESPACE_VENTE*/,',
'              :p178_num_vacation/*NUM_VACATION*/,:p178_total/*MONTANT_BON*/,:p178_surplace/*CODE_TRAITEMENT*/,v(''app_user''),:p178_nbpers);',
'    end if;',
'    close c_bon;',
'    :P178_NOUVEAU:=3;',
'end;',
'       '))
,p_attribute_02=>'P178_NOUVEAU,P178_NUM_BON,P178_CLIENT,P178_SURPLACE,P178_NBPERS'
,p_attribute_03=>'P178_TOTAL,P178_NOUVEAU'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81683816872508623)
,p_event_id=>wwv_flow_imp.id(81682296885508622)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(309107480778035677)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81684196902508625)
,p_name=>'Effacer'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(81651280462508578)
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81684663378508625)
,p_event_id=>wwv_flow_imp.id(81684196902508625)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  if nvl(:p178_num_bon,0) != 0 then',
'    update bons set code_etat_bon = 1',
'    where num_bon = :p178_num_bon;',
'  end if;',
'   ',
'   delete bons_temp',
'    where trim(code_utilisateur) = nvl(v(''app_user''), user);',
'    delete details_bon_temp',
'    where trim(util_modif) = nvl(v(''app_user''), user);',
'    commit;',
'',
'',
'    commit;',
'    select 0 into :P178_TOTAL  from dual;',
'    select null into :P178_NUM_BON  from dual;',
'',
'   ',
'    :P178_NOUVEAU :=3;',
'  '))
,p_attribute_02=>'P178_TOTAL,P178_NUM_BON,P178_NOUVEAU'
,p_attribute_03=>'P178_TOTAL,P178_NUM_BON,P178_NOUVEAU'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81685195113508625)
,p_event_id=>wwv_flow_imp.id(81684196902508625)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(309107480778035677)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81685663987508626)
,p_event_id=>wwv_flow_imp.id(81684196902508625)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(281873361492405598)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81686251623508628)
,p_event_id=>wwv_flow_imp.id(81684196902508625)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_CLIENT'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81686730855508628)
,p_event_id=>wwv_flow_imp.id(81684196902508625)
,p_event_result=>'TRUE'
,p_action_sequence=>90
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_NBPERS'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81687199035508628)
,p_event_id=>wwv_flow_imp.id(81684196902508625)
,p_event_result=>'TRUE'
,p_action_sequence=>110
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_SURPLACE'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'S'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81687705472508629)
,p_event_id=>wwv_flow_imp.id(81684196902508625)
,p_event_result=>'TRUE'
,p_action_sequence=>130
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_TICKET'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81688210456508629)
,p_event_id=>wwv_flow_imp.id(81684196902508625)
,p_event_result=>'TRUE'
,p_action_sequence=>150
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_PAYE'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81688701772508629)
,p_event_id=>wwv_flow_imp.id(81684196902508625)
,p_event_result=>'TRUE'
,p_action_sequence=>170
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_PAYE'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(59201606915155273)
,p_event_id=>wwv_flow_imp.id(81684196902508625)
,p_event_result=>'TRUE'
,p_action_sequence=>190
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_TABLE'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81689145234508631)
,p_name=>'majbontemp'
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(81652071674508579)
,p_condition_element=>'P178_REFOK'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81689617526508631)
,p_event_id=>wwv_flow_imp.id(81689145234508631)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete bons_temp;',
'insert into bons_temp values(:P178_NUM_BON,:p178_table,:p178_client,:P178_NUM_PV,:p178_nbpers,:p178_total,:p178_surplace,v(''app_user''),0);',
'commit;',
'',
'declare',
'cursor c_bon is select nvl(num_bon,0) num_bon from details_bon_temp',
'where trim(code_utilisateur) = nvl(v(''app_user''), user);',
'r_bon c_bon%rowtype;',
'numbon number;',
'mat number := fn_matricule(v(''app_user''));',
'numticket number;tot number;',
'',
'begin',
'      if nvl(:P178_TOTAL,0) > 0 then',
'               if nvl(:P178_NUM_BON,0) = 0 then',
'                   select BONS_NUM_BON_SEQ.nextval into numbon from dual;',
'                   numticket := fn_reference_bon;',
'                   :P178_TABLE := numticket;',
'                   :P178_NUM_BON := numbon;',
'                   insert into bons ',
'                   values(numbon/*NUM_BON*/ ,1/*CODE_ETAT_BON*/,:P178_TABLE/*NUM_TABLE*/,:P178_CLIENT/*NUM_CLT*/,:p178_ticket/*NUM_TICKET*/,',
'                          mat/*MATRICULE*/,null/*NUM_FACTURE*/,:P178_NUMESPACE/*NUM_ESPACE_VENTE*/,     ',
'                          NULL/*NUM_CMDE_CLT*/,:P178_NUM_VACATION/*NUM_VACATION*/,:p178_date_vacation/*DATE_BON*/,:P178_TOTAL/*MONTANT_BON*/,',
'                          null/*MONTANT_CONSIGNATION*/,''N''/*LIVRE*/,''N''/*PAYE*/,''N''/*FACTURE*/,',
'                          :P178_NBPERS/*CONSIGATION*/,null/*OBSERVATION*/,:P178_SURPLACE/*CODE_TRAITEMENT*/,nvl(v(''app_user''), user)/*CODE_UTILISATEUR*/,sysdate/*DATE_CREATION*/,1,null,null);',
'                   insert into details_bon select NUM_DETAIL_BON,NUM_PRODUIT,numbon,QTE_BON,PU_BON,QTE_RETOURNE,QTE_CONSIGNE,ETAT_DETAIL_BON,  ',
'                    CODE_UTILISATEUR,:p178_date_vacation/*DATE_CREATION*/,LIVRE,TYPE_DETAIL_BON,NUM_MENU',
'                    from details_bon_temp',
'                    where trim(util_modif) = trim(nvl(v(''app_user''), user)) order by NUM_DETAIL_BON;',
'                   update details_bon_temp set num_bon = :P178_NUM_BON,date_creation = :p178_date_vacation',
'                   where trim(util_modif) = trim(nvl(v(''app_user''), user));',
'                   select sum(QTE_BON*PU_BON) into tot from details_bon_temp  where trim(util_modif) = trim(nvl(v(''app_user''), user));',
'                   insert into recu values(seq_recu.nextval,:P178_NUM_BON,0,0,0,tot,0,0,0,0,null,null,null,null,null,null,null);',
'                   update bon_ingredient set num_bon =numbon where num_detail_bon in (select num_detail_bon from details_bon_temp where trim(util_modif)= v(''app_user''));',
'                else',
'                     update bons',
'                     set num_table = :P178_TABLE,num_clt = :P178_CLIENT,num_espace_vente = :P178_NUMESPACE,code_utilisateur =v(''app_user''),',
'                     num_vacation = :P178_NUM_VACATION,montant_bon = :P178_TOTAL,code_traitement = :P178_SURPLACE,code_etat_bon = 1,num_ticket =:p178_ticket,consigation = :P178_NBPERS ',
'                     where num_bon = :P178_NUM_BON;',
'                     delete details_bon',
'                     where num_bon = :P178_NUM_BON;',
'                     insert into details_bon select NUM_DETAIL_BON,NUM_PRODUIT,:P178_NUM_BON,QTE_BON,PU_BON,QTE_RETOURNE,QTE_CONSIGNE,ETAT_DETAIL_BON,  ',
'                     v(''app_user''),:p178_date_vacation/*DATE_CREATION*/,LIVRE,TYPE_DETAIL_BON,NUM_MENU',
'                     from details_bon_temp',
'                     where trim(util_modif) = trim(nvl(v(''app_user''), user)) order by NUM_DETAIL_BON;',
'                     select sum(QTE_BON*PU_BON) into tot from details_bon_temp  where trim(util_modif) = trim(nvl(v(''app_user''), user));',
'                     update recu set net = tot where num_bon = :P178_NUM_BON;',
'                     update bon_ingredient set num_bon =  :P178_NUM_BON where num_detail_bon in (select num_detail_bon from details_bon_temp where trim(util_modif)= v(''app_user''));',
'                end if;',
'            end if;',
'       ',
'       commit;',
'       --:P178_TOTAL :=0;',
'       :P178_NOUVEAU :=4;',
'end;'))
,p_attribute_02=>'P178_NUM_BON_TEMP,P178_TABLE,P178_CLIENT,P178_NBPERS,P178_TOTAL,P178_SURPLACE,P178_NUM_BON,P178_NOUVEAU,P178_DATE_VACATION,P178_NUM_VACATION,P178_TICKET,P178_NUMESPACE'
,p_attribute_03=>'P178_NUM_BON,P178_NOUVEAU,P178_TABLE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81690152805508633)
,p_event_id=>wwv_flow_imp.id(81689145234508631)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Vous devez saisir la r&#xE9;f&#xE9;rence du bon avant '
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81690611610508633)
,p_event_id=>wwv_flow_imp.id(81689145234508631)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Bon enregistr&#xE9; avec succ&#xE8;s'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81691098773508634)
,p_event_id=>wwv_flow_imp.id(81689145234508631)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(309107480778035677)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81691615126508634)
,p_event_id=>wwv_flow_imp.id(81689145234508631)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(281873361492405598)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81691970193508634)
,p_name=>'GestbuttonNouveau1'
,p_event_sequence=>120
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P178_NOUVEAU'
,p_condition_element=>'P178_NOUVEAU'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81692532354508636)
,p_event_id=>wwv_flow_imp.id(81691970193508634)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(81652071674508579)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81692994724508636)
,p_event_id=>wwv_flow_imp.id(81691970193508634)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(81651688699508578)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81693494057508636)
,p_event_id=>wwv_flow_imp.id(81691970193508634)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(81652861669508579)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81694947100508637)
,p_name=>'GestbuttonNouveau3'
,p_event_sequence=>130
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P178_NOUVEAU'
,p_condition_element=>'P178_NOUVEAU'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'3'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81695368675508639)
,p_event_id=>wwv_flow_imp.id(81694947100508637)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(81652071674508579)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81695899940508639)
,p_event_id=>wwv_flow_imp.id(81694947100508637)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(81652861669508579)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81696832268508640)
,p_name=>'GestbuttonNouveau0'
,p_event_sequence=>140
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P178_NOUVEAU'
,p_condition_element=>'P178_NOUVEAU'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'0'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81697266118508640)
,p_event_id=>wwv_flow_imp.id(81696832268508640)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(81651688699508578)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81697792390508642)
,p_event_id=>wwv_flow_imp.id(81696832268508640)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(81652071674508579)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81698300331508642)
,p_event_id=>wwv_flow_imp.id(81696832268508640)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(81652861669508579)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81698699617508642)
,p_name=>'GestBoutonTotal'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P178_TOTAL'
,p_condition_element=>'P178_TOTAL'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'0'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81699170618508644)
,p_event_id=>wwv_flow_imp.id(81698699617508642)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'begin',
'    ',
'    if nvl(:P178_NUM_BON,0)=0 then',
'          :p178_nouveau := 1;',
'         ',
'    else',
'        if :p178_nouveau is null then',
'                 :p178_nouveau :=1;',
'        end if;',
'         ',
'    end if;',
' end;'))
,p_attribute_02=>'P178_NUM_BON,P178_NOUVEAU'
,p_attribute_03=>'P178_NOUVEAU'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81699693230508644)
,p_event_id=>wwv_flow_imp.id(81698699617508642)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(81652071674508579)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81700190123508645)
,p_event_id=>wwv_flow_imp.id(81698699617508642)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(81652490060508579)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81700741453508645)
,p_event_id=>wwv_flow_imp.id(81698699617508642)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--select to_char(:p178_total,''999G999G999G999G990'') || '' FCFA'' into :p178_total_aff from dual;',
'declare',
'',
'cursor c_r is select * from recu',
'where num_bon = :P178_NUM_BON;',
'',
'r_r c_r%rowtype;',
'',
'begin',
'  select to_char(:p178_total,''999G999G999G999G990'') || '' FCFA''  into :p178_total_aff from dual;',
'  open c_r;',
'  fetch c_r  into r_r;',
'  if c_r%found then',
'      if nvl(r_r.remise,0) != 0 or  nvl(r_r.arrondi,0) != 0 then',
'           select to_char(:p178_total,''999G999G999G999G990'') || '' FCFA'' || '' (Remise : -'' || to_char(nvl(r_r.remise,0),''999G999G999G999G990'') || '' Arrondi : -'' || to_char(nvl(r_r.arrondi,0),''999G999G999G999G990'')||'')''  into :p178_total_aff from dual;',
'      end if;',
'  end if;',
'  close c_r;',
' end;'))
,p_attribute_02=>'P178_TOTAL,P178_TOTAL_AFF,P178_NUM_BON'
,p_attribute_03=>'P178_TOTAL_AFF'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81701169692508647)
,p_event_id=>wwv_flow_imp.id(81698699617508642)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--select to_char(:p178_total,''999G999G999G999G990'') || '' FCFA'' into :p178_total_aff from dual;',
'',
'declare',
'',
'cursor c_r is select * from recu',
'where num_bon = :P178_NUM_BON;',
'',
'r_r c_r%rowtype;',
'',
'begin',
'  select to_char(:p178_total,''999G999G999G999G990'') || '' FCFA''  into :p178_total_aff from dual;',
'  open c_r;',
'  fetch c_r  into r_r;',
'  if c_r%found then',
'      if nvl(r_r.remise,0) != 0 or  nvl(r_r.arrondi,0) != 0 then',
'           select to_char(:p178_total,''999G999G999G999G990'') || '' FCFA'' || '' (Remise : -'' || to_char(nvl(r_r.remise,0),''999G999G999G999G990'') || '' Arrondi : -'' || to_char(nvl(r_r.arrondi,0),''999G999G999G999G990'')||'')''  into :p178_total_aff from dual;',
'      end if;',
'  end if;',
'  close c_r;',
' end;'))
,p_attribute_02=>'P178_TOTAL,P178_TOTAL_AFF'
,p_attribute_03=>'P178_TOTAL_AFF'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(50260700435651790)
,p_event_id=>wwv_flow_imp.id(81698699617508642)
,p_event_result=>'FALSE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(81652490060508579)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81701606491508647)
,p_name=>'RefreshREgler'
,p_event_sequence=>160
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(81652861669508579)
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81702109734508647)
,p_event_id=>wwv_flow_imp.id(81701606491508647)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_NOUVEAU'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'5'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81702488455508648)
,p_name=>'RefreshdetailsDon'
,p_event_sequence=>170
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(309107480778035677)
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81703052722508648)
,p_event_id=>wwv_flow_imp.id(81702488455508648)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(309107480778035677)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81703430719508648)
,p_name=>'Famille'
,p_event_sequence=>180
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'a.famille'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81703937626508650)
,p_event_id=>wwv_flow_imp.id(81703430719508648)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_CODE_FAMILLE'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.id'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81704347818508650)
,p_name=>'AffectationPcodefamille'
,p_event_sequence=>190
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P178_CODE_FAMILLE'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81704842619508650)
,p_event_id=>wwv_flow_imp.id(81704347818508650)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
':p178_famille := :p178_code_famille;',
'select code_type_produit into :P178_TYPE_PRODUIT from type_produit',
'where code_famille = :p178_code_famille',
'and rownum = 1',
'order by code_type_produit ;',
'end;'))
,p_attribute_02=>'P178_CODE_FAMILLE,P178_TYPE_PRODUIT'
,p_attribute_03=>'P178_TYPE_PRODUIT'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81705324891508651)
,p_event_id=>wwv_flow_imp.id(81704347818508650)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(309047892876127692)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81705728307508651)
,p_name=>'TYPEPRDPRD'
,p_event_sequence=>200
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'a.typeprd'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81706190250508651)
,p_event_id=>wwv_flow_imp.id(81705728307508651)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_TYPE_PRODUIT'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.id'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81706736681508653)
,p_event_id=>wwv_flow_imp.id(81705728307508651)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(309063329264127704)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81707090092508653)
,p_name=>'REfreshPrd'
,p_event_sequence=>210
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P178_TYPEPRD'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81707604349508654)
,p_event_id=>wwv_flow_imp.id(81707090092508653)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(309063329264127704)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81708041267508654)
,p_name=>'Init code famille'
,p_event_sequence=>240
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexbeforepagesubmit'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81708503089508654)
,p_event_id=>wwv_flow_imp.id(81708041267508654)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_CODE_FAMILLE'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'6'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81709057200508656)
,p_event_id=>wwv_flow_imp.id(81708041267508654)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(309063329264127704)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81709543480508656)
,p_event_id=>wwv_flow_imp.id(81708041267508654)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_TYPEPRD'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'17'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81710004562508658)
,p_event_id=>wwv_flow_imp.id(81708041267508654)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(309063329264127704)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81710421865508658)
,p_name=>'Inittypeprd'
,p_event_sequence=>250
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexbeforepagesubmit'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81710865584508658)
,p_event_id=>wwv_flow_imp.id(81710421865508658)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_TYPEPRD'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'17'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81711401299508659)
,p_event_id=>wwv_flow_imp.id(81710421865508658)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_TYPEPRD'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'17'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81711768625508659)
,p_name=>'RefreshProduits'
,p_event_sequence=>270
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P178_TYPE_PRODUIT'
,p_bind_type=>'live'
,p_bind_delegate_to_selector=>'a.typeprd'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81712319791508659)
,p_event_id=>wwv_flow_imp.id(81711768625508659)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(309063329264127704)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81712744161508659)
,p_name=>'initTotal'
,p_event_sequence=>280
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81713189073508661)
,p_event_id=>wwv_flow_imp.id(81712744161508659)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_TOTAL'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'0'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81713726789508661)
,p_event_id=>wwv_flow_imp.id(81712744161508659)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_NOUVEAU'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'3'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81714079885508662)
,p_name=>'RefreshEncoursDA'
,p_event_sequence=>290
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(81650889111508578)
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81714569558508662)
,p_event_id=>wwv_flow_imp.id(81714079885508662)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update bons set code_etat_bon = 1 ',
'where code_etat_bon = 2 and num_bon  not in (select num_bon from details_bon_temp);',
''))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81715023203508662)
,p_event_id=>wwv_flow_imp.id(81714079885508662)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(281873361492405598)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81715537101508664)
,p_event_id=>wwv_flow_imp.id(81714079885508662)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(309107480778035677)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81715927215508664)
,p_name=>'BonEnModif'
,p_event_sequence=>310
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P178_MODIF'
,p_condition_element=>'P178_MODIF'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81716427198508664)
,p_event_id=>wwv_flow_imp.id(81715927215508664)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Bon actuellement en modification !'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81719673216508669)
,p_name=>'GestionbuttonNouveau4'
,p_event_sequence=>350
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P178_NOUVEAU'
,p_condition_element=>'P178_NOUVEAU'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'4'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81720217535508669)
,p_event_id=>wwv_flow_imp.id(81719673216508669)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(81652861669508579)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81720732878508669)
,p_event_id=>wwv_flow_imp.id(81719673216508669)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(81652071674508579)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81722071344508670)
,p_name=>'GestionbuttonNouveau5'
,p_event_sequence=>360
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P178_NOUVEAU'
,p_condition_element=>'P178_NOUVEAU'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'5'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81722654912508672)
,p_event_id=>wwv_flow_imp.id(81722071344508670)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(81652861669508579)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81723130730508672)
,p_event_id=>wwv_flow_imp.id(81722071344508670)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(81652071674508579)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81724092181508673)
,p_event_id=>wwv_flow_imp.id(81722071344508670)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(81651688699508578)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81724981294508675)
,p_name=>'GestionbuttonNouveau6'
,p_event_sequence=>370
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P178_NOUVEAU'
,p_condition_element=>'P178_NOUVEAU'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'6'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81725464607508675)
,p_event_id=>wwv_flow_imp.id(81724981294508675)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(81652861669508579)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81726007975508676)
,p_event_id=>wwv_flow_imp.id(81724981294508675)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(81652071674508579)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81727034383508678)
,p_event_id=>wwv_flow_imp.id(81724981294508675)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(81651688699508578)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81727388248508678)
,p_name=>'conso'
,p_event_sequence=>380
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P178_SURPLACE'
,p_condition_element=>'P178_SURPLACE'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'S'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81728865379508679)
,p_event_id=>wwv_flow_imp.id(81727388248508678)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_TICKET'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81729383762508679)
,p_event_id=>wwv_flow_imp.id(81727388248508678)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_TICKET'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81727900883508678)
,p_event_id=>wwv_flow_imp.id(81727388248508678)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_TICKET'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81728430727508679)
,p_event_id=>wwv_flow_imp.id(81727388248508678)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/*:P178_VERIF_REF :=0;',
'if :P178_SURPLACE in (''E'',''L'',''A'') and nvl(:P178_TICKET,''0'') =''0''  then',
'    :P178_VERIF_REF :=1;',
'end if;*/',
'null;'))
,p_attribute_02=>'P178_VERIF,P178_SURPLACE,P178_TICKET'
,p_attribute_03=>'P178_VERIF_REF'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81729808884508679)
,p_name=>'annulbon'
,p_event_sequence=>390
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P178_ANN'
,p_condition_element=>'P178_ANN'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81730303100508681)
,p_event_id=>wwv_flow_imp.id(81729808884508679)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Le bon est d&#xE9;ja pay&#xE9; impossible de l&#x27;annuler !'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81730803664508681)
,p_event_id=>wwv_flow_imp.id(81729808884508679)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_ANN'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'0'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81731245348508683)
,p_name=>'annulbon_1'
,p_event_sequence=>400
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P178_ANN'
,p_condition_element=>'P178_ANN'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'2'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81731732582508683)
,p_event_id=>wwv_flow_imp.id(81731245348508683)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Bon annul&#xE9; avec succ&#xE8;s !'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81732180367508683)
,p_event_id=>wwv_flow_imp.id(81731245348508683)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_ANN'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'0'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81732590001508684)
,p_name=>'perso'
,p_event_sequence=>410
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(309107480778035677)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81733094950508684)
,p_event_id=>wwv_flow_imp.id(81732590001508684)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(309107480778035677)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81733553689508684)
,p_name=>'Encoursbon'
,p_event_sequence=>420
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(281873361492405598)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81733998695508686)
,p_event_id=>wwv_flow_imp.id(81733553689508684)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(281873361492405598)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81734391586508686)
,p_name=>'bonpaye'
,p_event_sequence=>430
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P178_PAYE'
,p_condition_element=>'P178_PAYE'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'O'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81734912362508689)
,p_event_id=>wwv_flow_imp.id(81734391586508686)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_CLIENT,P178_TICKET,P178_NBPERS,,P178_SURPLACE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81735442260508689)
,p_event_id=>wwv_flow_imp.id(81734391586508686)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_CLIENT,P178_TICKET,P178_NBPERS,,P178_SURPLACE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81735762833508689)
,p_name=>'refok'
,p_event_sequence=>440
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P178_SURPLACE,P178_TICKET'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81736322217508690)
,p_event_id=>wwv_flow_imp.id(81735762833508689)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P178_SURPLACE in (''E'',''LA'',''LC'')  then ',
'   if :P178_TICKET is null then',
'     :P178_REFOK:= 0;',
'    else',
'      :P178_REFOK:=1;',
'    end if;',
'else',
'    :P178_REFOK:=1;',
'end if;'))
,p_attribute_02=>'P178_SURPLACE,P178_TICKET,P178_REFOK'
,p_attribute_03=>'P178_REFOK'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81736721398508690)
,p_name=>'perso1'
,p_event_sequence=>450
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'a.perso'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81737222714508690)
,p_event_id=>wwv_flow_imp.id(81736721398508690)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_DELETE_ID'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81666028062508603)
,p_name=>'New'
,p_event_sequence=>460
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P178_COMMANDES'
,p_condition_element=>'P178_COMMANDES'
,p_triggering_condition_type=>'NOT_EQUALS'
,p_triggering_expression=>'0'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81666535252508604)
,p_event_id=>wwv_flow_imp.id(81666028062508603)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.APEXUTILS.EXECUTE_PLSQL_CODE'
,p_attribute_01=>'null;'
,p_attribute_04=>'Vous avez &P178_COMMANDES. nouvelle(s) commande(s) internet '
,p_attribute_05=>'#SQLERRM#'
,p_attribute_07=>'body'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(81666933807508604)
,p_name=>'refreshint'
,p_event_sequence=>470
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(281873361492405598)
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(81667405311508604)
,p_event_id=>wwv_flow_imp.id(81666933807508604)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'nombre number;',
'',
'cursor c_bon is select  nb from temp_j;',
'',
'r_bon c_bon%rowtype;',
'',
'',
'fin number;',
'begin',
'    :P178_COMMANDES :=0;',
'    open c_bon;',
'    fetch c_bon into r_bon;',
'    if c_bon%found then',
'            :P178_COMMANDES:= r_bon.nb;',
'    end if;',
'    close c_bon;   ',
'end;'))
,p_attribute_02=>'P178_COMMANDES,P178_NBC'
,p_attribute_03=>'P178_COMMANDES,P178_NBC'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(82209278768834981)
,p_name=>'type_produit'
,p_event_sequence=>490
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'a.typeproduit'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(82209419860834982)
,p_event_id=>wwv_flow_imp.id(82209278768834981)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_TYPE_PRODUIT'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.id'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(82209481808834983)
,p_event_id=>wwv_flow_imp.id(82209278768834981)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(309063329264127704)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(82209770272834986)
,p_name=>'SELECTED CARDS'
,p_event_sequence=>500
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'[data-action=''select'']'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(82209944547834987)
,p_event_id=>wwv_flow_imp.id(82209770272834986)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_TYPE_PRODUIT'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.dataset.value'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(82210033099834988)
,p_event_id=>wwv_flow_imp.id(82209770272834986)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(309063329264127704)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(34566411366556883)
,p_name=>'paye'
,p_event_sequence=>510
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(81652861669508579)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(34566778814556887)
,p_event_id=>wwv_flow_imp.id(34566411366556883)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  if nvl(:p178_num_bon,0) != 0 then',
'    update bons set code_etat_bon = 1',
'    where num_bon = :p178_num_bon;',
'  end if;',
'   ',
'   delete bons_temp',
'    where trim(code_utilisateur) = nvl(v(''app_user''), user);',
'    delete details_bon_temp',
'    where trim(util_modif) = nvl(v(''app_user''), user);',
'    commit;',
'',
'',
'    commit;',
'    select 0 into :P178_TOTAL  from dual;',
'    select null into :P178_NUM_BON  from dual;',
'',
'   ',
'    :P178_NOUVEAU :=3;',
'  '))
,p_attribute_02=>'P178_TOTAL,P178_NUM_BON,P178_NOUVEAU'
,p_attribute_03=>'P178_TOTAL,P178_NUM_BON,P178_NOUVEAU'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(34566894023556888)
,p_event_id=>wwv_flow_imp.id(34566411366556883)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(309107480778035677)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(34567035509556889)
,p_event_id=>wwv_flow_imp.id(34566411366556883)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(281873361492405598)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(34567103237556890)
,p_event_id=>wwv_flow_imp.id(34566411366556883)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_CLIENT'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(34567180126556891)
,p_event_id=>wwv_flow_imp.id(34566411366556883)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_NBPERS'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'1'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(34567247140556892)
,p_event_id=>wwv_flow_imp.id(34566411366556883)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_SURPLACE'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'S'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(34567348657556893)
,p_event_id=>wwv_flow_imp.id(34566411366556883)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_TICKET'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(34567455747556894)
,p_event_id=>wwv_flow_imp.id(34566411366556883)
,p_event_result=>'TRUE'
,p_action_sequence=>80
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_PAYE'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(34567622276556895)
,p_event_id=>wwv_flow_imp.id(34566411366556883)
,p_event_result=>'TRUE'
,p_action_sequence=>90
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_PAYE'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(34567724980556896)
,p_event_id=>wwv_flow_imp.id(34566411366556883)
,p_event_result=>'TRUE'
,p_action_sequence=>100
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P178_TABLE'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(81665207646508601)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SuppDetBtemp'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update bons set code_etat_bon = 1 where num_bon in (select num_bon from details_bon_temp',
'                                                   where trim(util_modif) = trim(nvl(v(''app_user''), user))) ; ',
'delete details_bon_temp where trim(util_modif) = trim(nvl(v(''app_user''), user));',
'commit;',
''))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>81665207646508601
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(81665576520508601)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'SupprimerDetail_temp'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nvl(NUM_BON,null) ,nvl(NUM_TABLE,1),nvl(NUM_CLT,1),nvl(CODE_TRAITEMENT,''S''),nvl(NB_PERS,1)      ',
'into :p178_num_bon,:p178_table,:p178_client,:p178_surplace,:p178_nbpers',
'from bons_temp',
'where trim(code_utilisateur) =v(''app_user'');'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>81665576520508601
);
wwv_flow_imp.component_end;
end;
/
