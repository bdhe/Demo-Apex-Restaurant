prompt --application/pages/page_00117
begin
--   Manifest
--     PAGE: 00117
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>117
,p_name=>'Inventaire'
,p_alias=>'INVENTAIRE'
,p_step_title=>'Inventaire'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(245102388290533949)
,p_plug_name=>unistr('Param\00E8tres')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>6
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(245102733101533952)
,p_name=>'Inventaire'
,p_template=>4072358936313175081
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_grid_column_span=>6
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUM_INVENT,',
'       LIBELLE_INVENT,',
'       DATE_INVENT,',
'       COMMENTAIRE,',
'       ETAT_INVENTAIRE,',
'       CODE_UTILISATEUR,',
'       DATE_CREATION,',
'       NUM_POINT_VENTE',
'  from INVENTAIRE',
'where num_invent = :P117_NUM_INVENT',
'and etat_inventaire = 1'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P117_NUM_INVENT'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85877275928297526)
,p_query_column_id=>1
,p_column_alias=>'NUM_INVENT'
,p_column_display_sequence=>1
,p_column_heading=>unistr('N\00B0 Inventaire')
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85877690167297528)
,p_query_column_id=>2
,p_column_alias=>'LIBELLE_INVENT'
,p_column_display_sequence=>3
,p_column_heading=>'Libelle Invent'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85878141448297528)
,p_query_column_id=>3
,p_column_alias=>'DATE_INVENT'
,p_column_display_sequence=>2
,p_column_heading=>'Date'
,p_column_format=>'DD/MM/YYYY'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85878540487297528)
,p_query_column_id=>4
,p_column_alias=>'COMMENTAIRE'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85878872829297529)
,p_query_column_id=>5
,p_column_alias=>'ETAT_INVENTAIRE'
,p_column_display_sequence=>5
,p_column_heading=>'Etat Inventaire'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>'select libelle_etat_invent,code_etat_invent from etat_invent'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85879320644297531)
,p_query_column_id=>6
,p_column_alias=>'CODE_UTILISATEUR'
,p_column_display_sequence=>6
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85879751798297531)
,p_query_column_id=>7
,p_column_alias=>'DATE_CREATION'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85880067899297533)
,p_query_column_id=>8
,p_column_alias=>'NUM_POINT_VENTE'
,p_column_display_sequence=>8
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(245103663948533962)
,p_plug_name=>unistr('D\00E9tails')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUM_DETAIL_INVENT,',
'       NUM_INVENT,',
'       NUM_PRODUIT,',
'       UNITE_MESURE,',
'       QTE_OUV,',
'       QTE_ENTREE,',
'       QTE_SORTIE,',
'       QTE_INVENT,',
'       QTE_SOLDE,',
'       ECART,observationss',
'  from DETAIL_INVENTAIRE',
'where num_invent = :P117_NUM_INVENT',
'and code_type_produit = nvl(:P117_TYPE_PRODUIT,code_type_produit)',
'and num_invent in (select num_invent from inventaire where etat_inventaire = 1)'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P117_NUM_INVENT,P117_TYPE_PRODUIT'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(114962869053704559)
,p_name=>'ECART'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ECART'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Ecart'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>130
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(115405010183964458)
,p_name=>'OBSERVATIONSS'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'OBSERVATIONSS'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXTAREA'
,p_heading=>'Observationss'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>140
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>100
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(245177731256607035)
,p_name=>'NUM_DETAIL_INVENT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NUM_DETAIL_INVENT'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(245177838370607036)
,p_name=>'NUM_INVENT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NUM_INVENT'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>40
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(245177928942607037)
,p_name=>'NUM_PRODUIT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NUM_PRODUIT'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Produit'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(81557789633430934)
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(245178033722607038)
,p_name=>'UNITE_MESURE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UNITE_MESURE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Unite Mesure'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>60
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>10
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(245178087939607039)
,p_name=>'QTE_OUV'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QTE_OUV'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Stock Ouverture'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>70
,p_value_alignment=>'RIGHT'
,p_stretch=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
,p_format_mask=>'999G999G999G999G990D000'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(245178162868607040)
,p_name=>'QTE_ENTREE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QTE_ENTREE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Entrees'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>80
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
,p_format_mask=>'999G999G999G999G990D000'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(245178288923607041)
,p_name=>'QTE_SORTIE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QTE_SORTIE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Sorties'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>110
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
,p_format_mask=>'999G999G999G999G990D000'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(245178362996607042)
,p_name=>'QTE_SOLDE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QTE_SOLDE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Stock fin'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>100
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
,p_format_mask=>'999G999G999G999G990D000'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(245178537855607043)
,p_name=>'QTE_INVENT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QTE_INVENT'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Qte Inventaire'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>120
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
,p_format_mask=>'999G999G999G999G990D000'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(245177614979607034)
,p_internal_uid=>190005054523934065
,p_is_editable=>true
,p_edit_operations=>'u'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_show_nulls_as=>'-'
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'SEARCH_COLUMN:SEARCH_FIELD:RESET:SAVE'
,p_enable_save_public_report=>true
,p_enable_subscriptions=>true
,p_enable_flashback=>false
,p_define_chart_view=>false
,p_enable_download=>true
,p_download_formats=>'CSV'
,p_enable_mail_download=>false
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(245204683936086072)
,p_interactive_grid_id=>wwv_flow_imp.id(245177614979607034)
,p_static_id=>'252224'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(245204814597086072)
,p_report_id=>wwv_flow_imp.id(245204683936086072)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(115237404330182572)
,p_view_id=>wwv_flow_imp.id(245204814597086072)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(114962869053704559)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(115442300166318182)
,p_view_id=>wwv_flow_imp.id(245204814597086072)
,p_display_seq=>13
,p_column_id=>wwv_flow_imp.id(115405010183964458)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(245205307102086073)
,p_view_id=>wwv_flow_imp.id(245204814597086072)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(245177731256607035)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(245205764482086075)
,p_view_id=>wwv_flow_imp.id(245204814597086072)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(245177838370607036)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(245206290487086076)
,p_view_id=>wwv_flow_imp.id(245204814597086072)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(245177928942607037)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(245206797719086078)
,p_view_id=>wwv_flow_imp.id(245204814597086072)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(245178033722607038)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(245207328298086079)
,p_view_id=>wwv_flow_imp.id(245204814597086072)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(245178087939607039)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(245207801065086081)
,p_view_id=>wwv_flow_imp.id(245204814597086072)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(245178162868607040)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(245208279974086084)
,p_view_id=>wwv_flow_imp.id(245204814597086072)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(245178288923607041)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(245208837399086084)
,p_view_id=>wwv_flow_imp.id(245204814597086072)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(245178362996607042)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(245209334310086086)
,p_view_id=>wwv_flow_imp.id(245204814597086072)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(245178537855607043)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85871401257297519)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(245102388290533949)
,p_button_name=>unistr('Cr\00E9er')
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Cr\00E9er inventaire')
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85871776764297520)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(245102388290533949)
,p_button_name=>'Supprimer'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Supprimer'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P117_NUM_PV'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85872242769297520)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(245102388290533949)
,p_button_name=>'Effacer'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Effacer'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85872565341297520)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(245102388290533949)
,p_button_name=>'Valider'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Cl\00F4turer inventaire')
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85873045892297520)
,p_name=>'P117_PROFIL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(245102388290533949)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select code_statut_personnel  from personnel',
'    where trim(profil_app) =v(''app_user'');'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85873371211297522)
,p_name=>'P117_NUM_PV'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(245102388290533949)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Point de vente'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'POINT_VENTE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nom_point_vente as d,',
'       num_point_vente as r',
'  from point_vente where actif=''O''',
'order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85873767314297522)
,p_name=>'P117_CHOIX'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(245102388290533949)
,p_item_default=>'1'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC2:Nouveau;1,Modification;2'
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85874225947297522)
,p_name=>'P117_DATE_INVENT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(245102388290533949)
,p_use_cache_before_default=>'NO'
,p_item_default=>'select sysdate from dual;'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>unistr('P\00E9riode d\00E9but')
,p_format_mask=>'DD/MM/YYYY'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_colspan=>3
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'appearance_and_behavior', 'MONTH-PICKER:YEAR-PICKER',
  'days_outside_month', 'VISIBLE',
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_on', 'FOCUS',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85874614968297523)
,p_name=>'P117_DATE_INVENT_1'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(245102388290533949)
,p_use_cache_before_default=>'NO'
,p_item_default=>'select sysdate from dual;'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>unistr('P\00E9riode d\00E9but')
,p_format_mask=>'DD/MM/YYYY'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'appearance_and_behavior', 'MONTH-PICKER:YEAR-PICKER',
  'days_outside_month', 'VISIBLE',
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_on', 'FOCUS',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85874966119297523)
,p_name=>'P117_NUM_INVENT'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(245102388290533949)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('N\00B0 Inventaire')
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(num_invent) ||''-''||trim(libelle_invent) || ''-''|| to_char(date_invent,''dd/mm/yyyy'') || ''-''|| to_char(date_fin,''dd/mm/yyyy'') as d,num_invent ',
'from inventaire where etat_inventaire = 1',
'and num_point_vente = :P117_NUM_PV'))
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>6
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'DIALOG',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85875438899297523)
,p_name=>'P117_MESSAGE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(245102388290533949)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85875778982297523)
,p_name=>'P117_BOUTONS'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(245102388290533949)
,p_use_cache_before_default=>'NO'
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nvl(count(*),0) from inventaire',
'where num_point_vente = :P117_NUM_PV',
'and date_invent = :P117_DATE_INVENT;'))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85876244466297525)
,p_name=>'P117_VALIDER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(245102388290533949)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85876620847297526)
,p_name=>'P117_AS'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(245102388290533949)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85885937102297544)
,p_name=>'P117_TYPE_PRODUIT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(245103663948533962)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Type produit'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TYPE_PRODUIT_STOCK'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select libelle_type_produit as d,',
'       code_type_produit as r',
'  from type_produit',
'  where code_type_produit in (select code_type_produit from produits where STOCKABLE =''O'')',
' order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Tous'
,p_cHeight=>1
,p_colspan=>6
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85886662131297545)
,p_name=>'invent'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(85871401257297519)
,p_condition_element=>'P117_AS'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'0'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85887253118297547)
,p_event_id=>wwv_flow_imp.id(85886662131297545)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Il existe des demandes d&#x27;approvisionnement et&#x2F;ou des sorties non valid&#xE9;es. Veuillez effectuer &#xE0; leur validation avant !'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85887675919297547)
,p_event_id=>wwv_flow_imp.id(85886662131297545)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Etes vous s&#xFB;r de vouloir cr&#xE9;er un inventaire?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85888245912297547)
,p_event_id=>wwv_flow_imp.id(85886662131297545)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'cursor c_inv is select * from produits',
'where stockable=''O'';',
'--num_produit in (select num_produit from mouvement      where num_point_vente = :P117_NUM_PV ) and ',
'r_inv c_inv%rowtype;',
'souv number;sentrees  number;ssorties number;solde number;',
'',
'wnum_invent number;',
'--|| to_char(:P117_DATE_INVENT,''dd/mm/yyyy'') ||'' - ''  || (select trim(nom_point_vente) from point_vente where num_point_vente = :P117_NUM_PV)',
'begin',
'      select INVENTAIRE_NUM_INVENT_SEQ.nextval into wnum_invent from dual;',
'      :P117_NUM_INVENT := wnum_invent;',
'      ',
'      insert into inventaire values (wnum_invent/*NUM_INVENT*/,',
'                                    ''INVENTAIRE ''  ||'' - ''  || (select trim(nom_point_vente) from point_vente where num_point_vente = :P117_NUM_PV)/*LIBELLE_INVENT*/,',
'                                    :P117_DATE_INVENT/*DATE_INVENT*/,null/*COMMENTAIRE */,1/*ETAT_INVENTAIRE*/,v(''app_user'')/*CODE_UTILISATEUR*/,sysdate/*DATE_CREATION*/,:P117_NUM_PV/*NUM_POINT_VENTE*/,',
'                                    :P117_DATE_INVENT_1/*DATE_fin*/); ',
'      open c_inv;',
'       loop',
'           fetch c_inv into r_inv;',
'           exit when c_inv%notfound;',
'           souv := fn_stockprdpv_init(r_inv.num_produit,:P117_NUM_PV,:P117_DATE_INVENT);',
'          sentrees := fn_stockprdpv_entree(r_inv.num_produit,:P117_NUM_PV,:P117_DATE_INVENT,:P117_DATE_INVENT_1);',
'          ssorties := fn_stockprdpv_sortie(r_inv.num_produit,:P117_NUM_PV,:P117_DATE_INVENT,:P117_DATE_INVENT_1);',
'          solde := nvl(souv,0)+nvl(sentrees,0)-nvl(ssorties,0);',
'           insert into detail_inventaire values(seq_det_invent.nextval, wnum_invent,r_inv.num_produit, r_inv.unite_mesure ,souv,',
'           sentrees,ssorties,solde,solde,0,r_inv.code_type_produit,null);',
'       end loop;',
'       close c_inv;',
'       --update detail_inventaire set qte_solde = qte_ouv+qte_entree-qte_sortie where num_invent = wnum_invent;',
'       --delete detail_inventaire where num_invent = wnum_invent and nvl(qte_ouv,0) =0 and nvl(qte_entree,0) =0 and nvl(qte_sortie,0) =0 ;',
'       commit;',
' end;',
' ',
' ',
''))
,p_attribute_02=>'P117_NUM_PV,P117_DATE_INVENT,P117_NUM_INVENT,P117_DATE_INVENT_1'
,p_attribute_03=>'P117_NUM_INVENT'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85888669882297548)
,p_event_id=>wwv_flow_imp.id(85886662131297545)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(245102733101533952)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85889199969297548)
,p_event_id=>wwv_flow_imp.id(85886662131297545)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(245103663948533962)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85889672980297548)
,p_event_id=>wwv_flow_imp.id(85886662131297545)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(85871776764297520)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85890159695297548)
,p_name=>'typprd'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P117_TYPE_PRODUIT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85890575345297550)
,p_event_id=>wwv_flow_imp.id(85890159695297548)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(245103663948533962)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85891018335297550)
,p_name=>'suppr'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(85871776764297520)
,p_condition_element=>'P117_NUM_INVENT'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85891541011297550)
,p_event_id=>wwv_flow_imp.id(85891018335297550)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'&#xCA;tes vous s&#xFB;rs de vouloir supprimer cet inventaire?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85892034464297550)
,p_event_id=>wwv_flow_imp.id(85891018335297550)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Veuillez s&#xE9;lectionner l&#x27;inventaire &#xE0; supprimer'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85892534580297551)
,p_event_id=>wwv_flow_imp.id(85891018335297550)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'cursor c_inv is select etat_inventaire from inventaire',
'where num_invent = :P117_NUM_INVENT',
'and etat_inventaire = 1;',
'',
'r_inv c_inv%rowtype;',
'',
'begin ',
'   open c_inv;',
'   fetch c_inv into r_inv;',
'   if c_inv%found then',
'      delete detail_inventaire ',
'      where num_invent = :P117_NUM_INVENT;',
'      delete inventaire',
'      where num_invent = :P117_NUM_INVENT;',
'      commit;',
'    else',
unistr('       :p117_message := ''Inventaire d\00E9ja valid\00E9'';'),
'    end if;',
'    close c_inv;',
'end;',
'   ',
''))
,p_attribute_02=>'P117_NUM_INVENT'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85893020575297551)
,p_event_id=>wwv_flow_imp.id(85891018335297550)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(245102733101533952)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85893541656297551)
,p_event_id=>wwv_flow_imp.id(85891018335297550)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(245103663948533962)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85894016735297551)
,p_event_id=>wwv_flow_imp.id(85891018335297550)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(85871401257297519)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85894415555297553)
,p_name=>'boutons'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P117_INIT'
,p_condition_element=>'P117_INIT'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'2'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85894941548297553)
,p_event_id=>wwv_flow_imp.id(85894415555297553)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'cursor c_inv is select num_invent,etat_inventaire from inventaire',
'where num_point_vente = :P117_NUM_PV',
'and date_invent = :P117_DATE_INVENT;',
'r_inv c_inv%rowtype;',
'',
'begin ',
'    --:P117_BOUTONS :=0;',
'   open c_inv;',
'   fetch c_inv into r_inv;',
'   if c_inv%found then',
'      :P117_BOUTONS := 1;',
'      :P117_NUM_INVENT := r_inv.num_invent;',
'      :P117_VALIDER := r_inv.etat_inventaire;',
'    end if;',
'    close c_inv;',
'end;',
'   ',
''))
,p_attribute_02=>'P117_DATE_INVENT,P117_NUM_PV,P117_BOUTONS,P117_NUM_INVENT,P117_VALIDER'
,p_attribute_03=>'P117_BOUTONS,P117_NUM_INVENT'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85895308171297553)
,p_name=>'effacer'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(85872242769297520)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85895785665297554)
,p_event_id=>wwv_flow_imp.id(85895308171297553)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P117_NUM_INVENT'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85896306348297554)
,p_event_id=>wwv_flow_imp.id(85895308171297553)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(245102733101533952)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85896801717297554)
,p_event_id=>wwv_flow_imp.id(85895308171297553)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(245103663948533962)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85897259337297554)
,p_name=>'validation'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(85872565341297520)
,p_condition_element=>'P117_NUM_INVENT'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85897692254297556)
,p_event_id=>wwv_flow_imp.id(85897259337297554)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Etes-vous s&#xFB;r de vouloir valider cet inventaire? Les &#xE9;carts seront comptabilis&#xE9;s'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85898246959297556)
,p_event_id=>wwv_flow_imp.id(85897259337297554)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Veuillez s&#xE9;lectionner l&#x27;inventaire &#xE0; cl&#xF4;turer'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85898736851297556)
,p_event_id=>wwv_flow_imp.id(85897259337297554)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'cursor c_inv is select * from detail_inventaire ',
'where num_invent = :P117_NUM_INVENT',
'and ecart !=0;',
'r_inv c_inv%rowtype;',
' type_mvt number;',
'begin',
'   delete detail_inventaire where qte_ouv=0 and qte_entree=0 and qte_sortie=0 and qte_solde=0 and num_invent = :P117_NUM_INVENT;  ',
'   update detail_inventaire set ecart =  qte_invent - qte_solde where num_invent = :P117_NUM_INVENT;',
'   ',
'   open c_inv;',
'   loop',
'       fetch c_inv into r_inv;',
'       exit when c_inv%notfound;',
'        if r_inv.ecart < 0 then type_mvt := 26; else type_mvt := 25; end if;',
'        insert into mouvement values',
'        (MOUVEMENT_NUM_MVT_SEQ.nextval/*NUM_MVT*/,r_inv.NUM_PRODUIT,type_mvt/*CODE_TYPE_MOUVEMENT*/,null/*NUM_BON*/,:P117_NUM_PV/*NUM_POINT_VENTE*/, null/*NUM_LIVR*/, null/*NUM_LIVR_CLT*/,null/*NUM_CMDE*/,null/*CODE_FOURN*/,abs(r_inv.ecart)/*QTE*/,sy'
||'sdate/*DATE_MVT*/,               ',
'        0/*PU_MVT*/,''1''/*ETAT*/,nvl(v(''app_user''), user)/*CODE_UTILISATEUR*/,sysdate/*DATE_CREATION*/ ,r_inv.num_invent/*NUM_CARNET*/, to_char(fn_matricule(nvl(v(''app_user''), user)))/*MATRICULE*/,null/*NUM_TICKET*/,2/*CODE_NATURE_MVT*/,null);',
'   end loop;',
'   close c_inv;',
'   update inventaire set etat_inventaire = 2',
'   where num_invent = :P117_NUM_INVENT;',
'   commit;',
'end;',
'    '))
,p_attribute_02=>'P117_NUM_INVENT,P117_NUM_PV'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85899161566297556)
,p_event_id=>wwv_flow_imp.id(85897259337297554)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Validation effectu&#xE9;e avec succ&#xE8;s'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85899758412297558)
,p_event_id=>wwv_flow_imp.id(85897259337297554)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(245102733101533952)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85900164567297558)
,p_event_id=>wwv_flow_imp.id(85897259337297554)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(245102733101533952)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85900718184297558)
,p_event_id=>wwv_flow_imp.id(85897259337297554)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85901094221297559)
,p_name=>'regenerer'
,p_event_sequence=>110
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P117_DATE_INVENT,P117_NUM_PV,P117_DATE_INVENT_1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85901656287297559)
,p_event_id=>wwv_flow_imp.id(85901094221297559)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(245102733101533952)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85902145793297559)
,p_event_id=>wwv_flow_imp.id(85901094221297559)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(245103663948533962)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85902600988297559)
,p_event_id=>wwv_flow_imp.id(85901094221297559)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'numinvent number;',
'cursor c_inv is select num_invent from inventaire',
'    where num_point_vente = :P117_NUM_PV',
'    and date_invent = :P117_DATE_INVENT',
'    and date_fin = :P117_DATE_INVENT_1;',
'r_inv c_inv%rowtype;',
'',
'cursor c_appro is select * from appro where code_etat != 2 and NUM_POINT_VENTEA =  :P117_NUM_PV;',
'r_appro c_appro%rowtype;',
'',
'cursor c_s is select * from sortie_stock where code_etat_sortie != 1 and num_point_vente = :P117_NUM_PV;',
'r_s c_s%rowtype;',
'',
'appro number :=0;',
'sortie number :=0;',
'begin',
'    :P117_BOUTONS:=0;',
'    open c_inv;',
'    fetch c_inv into r_inv;',
'    if c_inv%found then',
'       numinvent := r_inv.num_invent;',
'       :P117_BOUTONS :=1;',
'       :P117_NUM_INVENT := numinvent;',
'    end if;',
'    close c_inv;',
'    ',
'    open c_appro;',
'    fetch c_appro into r_appro;',
'    if c_appro%found then',
'       appro :=1;',
'    end if;',
'    close c_appro;',
'    ',
'    open c_s;',
'    fetch c_s into r_s;',
'    if c_s%found then',
'       sortie := 1;',
'    end if;',
'    close c_s;',
'     :P117_AS :=0;',
'    if appro = 1 or sortie = 1 then',
'        :P117_AS :=1;',
'    end if;',
'end;'))
,p_attribute_02=>'P117_DATE_INVENT,P117_NUM_PV,P117_BOUTONS,P117_NUM_INVENT,P117_DATE_INVENT_1,P117_AS'
,p_attribute_03=>'P117_BOUTONS,P117_NUM_INVENT,P117_AS'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85903027527297561)
,p_name=>'rafraichir'
,p_event_sequence=>120
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P117_NUM_INVENT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85903546554297561)
,p_event_id=>wwv_flow_imp.id(85903027527297561)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(245102733101533952)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85904001322297561)
,p_event_id=>wwv_flow_imp.id(85903027527297561)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(245103663948533962)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85904436256297562)
,p_name=>'creer'
,p_event_sequence=>130
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P117_BOUTONS'
,p_condition_element=>'P117_BOUTONS'
,p_triggering_condition_type=>'GREATER_THAN_OR_EQUAL'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85904953861297562)
,p_event_id=>wwv_flow_imp.id(85904436256297562)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(85871401257297519)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85905379871297562)
,p_event_id=>wwv_flow_imp.id(85904436256297562)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(85871401257297519)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85905762413297562)
,p_name=>'ecart'
,p_event_sequence=>140
,p_triggering_element_type=>'COLUMN'
,p_triggering_region_id=>wwv_flow_imp.id(245103663948533962)
,p_triggering_element=>'QTE_INVENT'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85906356976297564)
,p_event_id=>wwv_flow_imp.id(85905762413297562)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>'select  :QTE_INVENT - :QTE_SOLDE into :ECART from dual;'
,p_attribute_02=>'QTE_SOLDE,QTE_INVENT,ECART'
,p_attribute_03=>'ECART'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85906740115297564)
,p_name=>'APP'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P117_PROFIL'
,p_condition_element=>'P117_PROFIL'
,p_triggering_condition_type=>'NOT_EQUALS'
,p_triggering_expression=>'3'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85907184018297564)
,p_event_id=>wwv_flow_imp.id(85906740115297564)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_pv is select num_point_vente from personnel p,affectation f',
'where p.matricule = f.matricule',
'and trim(profil_app)= v(''app_user'');',
'',
'r_pv c_pv%rowtype;',
'',
'begin',
' ',
'     open c_pv;',
'     fetch c_pv into r_pv;',
'     if c_pv%found then',
'         :P117_NUM_PV := r_pv.num_point_vente;',
'         ',
'     end if;',
'     close c_pv;',
'',
'  end;'))
,p_attribute_02=>'P117_NUM_PV'
,p_attribute_03=>'P117_NUM_PV'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85907701471297565)
,p_event_id=>wwv_flow_imp.id(85906740115297564)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P117_NUM_PV'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85908160310297565)
,p_name=>'chge'
,p_event_sequence=>160
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P117_CHOIX'
,p_condition_element=>'P117_CHOIX'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85908619513297565)
,p_event_id=>wwv_flow_imp.id(85908160310297565)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P117_NUM_INVENT'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85909091852297565)
,p_event_id=>wwv_flow_imp.id(85908160310297565)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P117_NUM_INVENT'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85909601990297567)
,p_event_id=>wwv_flow_imp.id(85908160310297565)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(85871401257297519)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85910095801297567)
,p_event_id=>wwv_flow_imp.id(85908160310297565)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(85871401257297519)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(85886262015297545)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(245103663948533962)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>unistr('D\00E9tails - Enregistrer les donn\00E9es de grille interactive')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>85886262015297545
);
wwv_flow_imp.component_end;
end;
/
