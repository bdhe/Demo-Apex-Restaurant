prompt --application/pages/page_00158
begin
--   Manifest
--     PAGE: 00158
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>158
,p_name=>'Cloture point de vente'
,p_alias=>'CLOTURE-POINT-DE-VENTE'
,p_step_title=>'Cloture point de vente'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(113252628942509421)
,p_name=>unistr('Bons annul\00E9s')
,p_template=>4072358936313175081
,p_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_grid_column_span=>7
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'TABLE'
,p_query_table=>'BONS'
,p_query_where=>wwv_flow_string.join(wwv_flow_t_varchar2(
'num_vacation = :P158_NUM_VACATION',
'and code_etat_bon = 3'))
,p_include_rowid_column=>false
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P158_NUM_VACATION'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'ROWS_X_TO_Y'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83408664391477201)
,p_query_column_id=>1
,p_column_alias=>'NUM_BON'
,p_column_display_sequence=>1
,p_column_heading=>'Num Bon'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83409066865477201)
,p_query_column_id=>2
,p_column_alias=>'CODE_ETAT_BON'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83409556928477201)
,p_query_column_id=>3
,p_column_alias=>'NUM_TABLE'
,p_column_display_sequence=>3
,p_column_heading=>unistr('N\00B0 Commande')
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83409917972477201)
,p_query_column_id=>4
,p_column_alias=>'NUM_CLT'
,p_column_display_sequence=>4
,p_column_heading=>'Num Clt'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(81019207167213398)
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83410318269477203)
,p_query_column_id=>5
,p_column_alias=>'NUM_TICKET'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83410751309477203)
,p_query_column_id=>6
,p_column_alias=>'MATRICULE'
,p_column_display_sequence=>6
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83411152806477203)
,p_query_column_id=>7
,p_column_alias=>'NUM_FACTURE'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83411555957477203)
,p_query_column_id=>8
,p_column_alias=>'NUM_ESPACE_VENTE'
,p_column_display_sequence=>8
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83411883965477203)
,p_query_column_id=>9
,p_column_alias=>'NUM_CMDE_CLT'
,p_column_display_sequence=>9
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83412334261477203)
,p_query_column_id=>10
,p_column_alias=>'NUM_VACATION'
,p_column_display_sequence=>10
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83412758287477204)
,p_query_column_id=>11
,p_column_alias=>'DATE_BON'
,p_column_display_sequence=>11
,p_column_heading=>'Date Bon'
,p_column_format=>'DD/MM/YYYY'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83413092358477204)
,p_query_column_id=>12
,p_column_alias=>'MONTANT_BON'
,p_column_display_sequence=>12
,p_column_heading=>'Montant '
,p_column_format=>'999G999G999G999G999G999G990'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83413504764477204)
,p_query_column_id=>13
,p_column_alias=>'MONTANT_CONSIGNATION'
,p_column_display_sequence=>13
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83413917657477204)
,p_query_column_id=>14
,p_column_alias=>'LIVRE'
,p_column_display_sequence=>14
,p_column_heading=>'Livre'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(82135818362696515)
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83414336742477204)
,p_query_column_id=>15
,p_column_alias=>'PAYE'
,p_column_display_sequence=>15
,p_column_heading=>'Paye'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(82135818362696515)
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83414687406477206)
,p_query_column_id=>16
,p_column_alias=>'FACTURE'
,p_column_display_sequence=>16
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83415149884477206)
,p_query_column_id=>17
,p_column_alias=>'CONSIGATION'
,p_column_display_sequence=>17
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83415527100477206)
,p_query_column_id=>18
,p_column_alias=>'OBSERVATION'
,p_column_display_sequence=>18
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83415884344477206)
,p_query_column_id=>19
,p_column_alias=>'CODE_TRAITEMENT'
,p_column_display_sequence=>19
,p_column_heading=>'Code Traitement'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(81314718136361273)
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83416354490477206)
,p_query_column_id=>20
,p_column_alias=>'CODE_UTILISATEUR'
,p_column_display_sequence=>20
,p_column_heading=>'Emetteur'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83416748548477208)
,p_query_column_id=>21
,p_column_alias=>'DATE_CREATION'
,p_column_display_sequence=>21
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83417129810477208)
,p_query_column_id=>22
,p_column_alias=>'CODE_SOCIETE'
,p_column_display_sequence=>22
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83417504785477208)
,p_query_column_id=>23
,p_column_alias=>'DATE_LIV'
,p_column_display_sequence=>23
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(327482820706084768)
,p_name=>'Vacation'
,p_template=>4072358936313175081
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_grid_column_span=>7
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.num_vacation,trim(nom) || '' '' || trim(prenoms) nom,pv.num_point_vente,pv.nom_point_vente,v.num_caisse,v.matricule,',
'DATEHEURE_DEBUT_VAC,SOLDE_INITIAL_CAISSE',
'from vacation v,personnel p,point_vente pv',
'where v.num_vacation = :P158_NUM_VACATION--to_char(DATEHEURE_DEBUT_VAC,''ddmmyyyy'') = to_char(sysdate,''ddmmyyyy'')',
'--and v.matricule = fn_matricule(v(''app_user''))',
'and v.matricule = p.matricule',
'and v.num_point_vente = pv.num_point_vente',
'and pv.num_point_vente = :P158_POINT_VENTE',
'and cloture = ''N'';'))
,p_translate_title=>'N'
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P158_POINT_VENTE'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'ROWS_X_TO_Y'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83418188699477209)
,p_query_column_id=>1
,p_column_alias=>'NUM_VACATION'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83418621400477209)
,p_query_column_id=>2
,p_column_alias=>'NOM'
,p_column_display_sequence=>2
,p_column_heading=>unistr('Vacation cr\00E9ee par')
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83418963496477209)
,p_query_column_id=>3
,p_column_alias=>'NUM_POINT_VENTE'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83419427857477211)
,p_query_column_id=>4
,p_column_alias=>'NOM_POINT_VENTE'
,p_column_display_sequence=>8
,p_column_heading=>'Point Vente'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83419762145477211)
,p_query_column_id=>5
,p_column_alias=>'NUM_CAISSE'
,p_column_display_sequence=>3
,p_column_heading=>'Caisse'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83420186382477211)
,p_query_column_id=>6
,p_column_alias=>'MATRICULE'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83420627003477212)
,p_query_column_id=>7
,p_column_alias=>'DATEHEURE_DEBUT_VAC'
,p_column_display_sequence=>5
,p_column_heading=>unistr('Date d\00E9but')
,p_column_format=>'DD/MM/YYYY HH:MIPM'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83421004412477212)
,p_query_column_id=>8
,p_column_alias=>'SOLDE_INITIAL_CAISSE'
,p_column_display_sequence=>6
,p_column_heading=>'Solde Initial '
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(327591686983615225)
,p_name=>unistr('R\00E9capitulatif')
,p_template=>4072358936313175081
,p_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUM_VACATION,',
'       CODE_LIGNE,',
'       LIBELLE_LIGNE,',
'       DEBIT,',
'       CREDIT,',
'       DATE_CLOTURE',
'  from CLOTURE',
'  where num_vacation = :P158_NUM_VACATION',
'order by code_ligne;'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P158_NUM_VACATION'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83424500497477220)
,p_query_column_id=>1
,p_column_alias=>'NUM_VACATION'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83424950084477222)
,p_query_column_id=>2
,p_column_alias=>'CODE_LIGNE'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83425321780477222)
,p_query_column_id=>3
,p_column_alias=>'LIBELLE_LIGNE'
,p_column_display_sequence=>3
,p_column_heading=>'Libelle '
,p_column_html_expression=>'<span style="display:block; width:300px">#LIBELLE_LIGNE#</span>'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83425713957477222)
,p_query_column_id=>4
,p_column_alias=>'DEBIT'
,p_column_display_sequence=>4
,p_column_heading=>'Debit'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_html_expression=>'<span style="display:block; width:100px">#DEBIT#</span>'
,p_column_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83426106854477223)
,p_query_column_id=>5
,p_column_alias=>'CREDIT'
,p_column_display_sequence=>5
,p_column_heading=>'Credit'
,p_column_format=>'999G999G999G999G999G999G990'
,p_column_html_expression=>'<span style="display:block; width:100px">#CREDIT#</span>'
,p_column_alignment=>'RIGHT'
,p_sum_column=>'Y'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83426501163477223)
,p_query_column_id=>6
,p_column_alias=>'DATE_CLOTURE'
,p_column_display_sequence=>6
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(327592368576615232)
,p_plug_name=>unistr('Encaisse fin de journ\00E9e')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(83429572176477228)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(327592368576615232)
,p_button_name=>'Verif'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('V\00E9rifier')
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(83429972863477228)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(327592368576615232)
,p_button_name=>'cloture'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>unistr('Cl\00F4turer')
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(83430363115477229)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(327592368576615232)
,p_button_name=>'Quitter'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Quitter'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83421422820477212)
,p_name=>'P158_PROFIL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(327482820706084768)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select code_statut_personnel  from personnel',
'    where trim(profil_app) =v(''app_user'');'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83421822168477215)
,p_name=>'P158_POINT_VENTE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(327482820706084768)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Point de vente'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'POINT_VENTE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nom_point_vente as d,',
'       num_point_vente as r',
'  from point_vente where actif=''O''',
'order by 1'))
,p_lov_display_null=>'YES'
,p_lov_null_text=>'Selectionnez le point de vente'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83422164132477217)
,p_name=>'P158_TOTAL_BON_NPAYE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(327482820706084768)
,p_use_cache_before_default=>'NO'
,p_item_default=>'0'
,p_prompt=>unistr('Total des bons non encaiss\00E9s')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83422569260477217)
,p_name=>'P158_NUM_ESPACE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(327482820706084768)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.num_espace_vente',
'from affectation a,personnel p,espace_vente e',
'where a.matricule = p.matricule',
'and a.num_espace_vente = e.num_espace_vente',
'and trim(profil_app) = nvl(v(''app_user''), user);'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83422985979477219)
,p_name=>'P158_NUM_PV'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(327482820706084768)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.num_point_vente',
'from affectation a,personnel p,espace_vente e',
'where a.matricule = p.matricule',
'and a.num_espace_vente = e.num_espace_vente',
'and trim(profil_app) = nvl(v(''app_user''), user);'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83423367786477219)
,p_name=>'P158_NUM_VACATION'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(327482820706084768)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('N\00B0 vacation non clotur\00E9e')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83423767820477219)
,p_name=>'P158_VERIF'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(327482820706084768)
,p_use_cache_before_default=>'NO'
,p_item_default=>'0'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83426895977477225)
,p_name=>'P158_LIB_2'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(327591686983615225)
,p_item_default=>'Solde initial'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83427336278477225)
,p_name=>'P158_TOTAL_OPD_1'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(327591686983615225)
,p_use_cache_before_default=>'NO'
,p_item_default=>'0'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select SOLDE_INITIAL_CAISSE from vacation',
'where num_vacation = :P158_NUM_VACATION;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83427741792477225)
,p_name=>'P158_LIB'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(327591686983615225)
,p_item_default=>unistr('Op\00E9rations de caisse D\00E9bit')
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83428150642477226)
,p_name=>'P158_TOTAL_OPD'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(327591686983615225)
,p_item_default=>'0'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83428512397477226)
,p_name=>'P158_LIB_1'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(327591686983615225)
,p_item_default=>unistr('Op\00E9rations de caisse D\00E9bit')
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83428905779477226)
,p_name=>'P158_TOTAL_OPC'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(327591686983615225)
,p_item_default=>'0'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83430779558477229)
,p_name=>'P158_ENCAISSE_FIN'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(327592368576615232)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Encaisse fin de journ\00E9e')
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>3031561932232085882
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83431192728477229)
,p_name=>'P158_ENCAISSE_SYSTEM'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(327592368576615232)
,p_use_cache_before_default=>'NO'
,p_item_default=>'0'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83431602568477231)
,p_name=>'P158_ENCAISSE_SYSTEM_1'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(327592368576615232)
,p_item_default=>'0'
,p_prompt=>'Encaisse System'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83432023323477231)
,p_name=>'P158_ECART'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(327592368576615232)
,p_use_cache_before_default=>'NO'
,p_item_default=>'0'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83432379276477231)
,p_name=>'P158_ECART_1'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(327592368576615232)
,p_use_cache_before_default=>'NO'
,p_item_default=>'0'
,p_prompt=>'Ecart'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83433124489477234)
,p_name=>'clot'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(83429572176477228)
,p_condition_element=>'P158_ENCAISSE_FIN'
,p_triggering_condition_type=>'GREATER_THAN'
,p_triggering_expression=>'0'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83433596595477234)
,p_event_id=>wwv_flow_imp.id(83433124489477234)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'mt_encaisse number;',
'totbp number;',
'',
'begin',
'    delete cloture where num_vacation = :P158_NUM_VACATION;',
'    select solde_initial_caisse into mt_encaisse from vacation where num_vacation = :P158_NUM_VACATION',
'    and  cloture = ''N'';',
'    ',
'    SELECT  nvl(sum(RECU.NET),0) into totbp',
'    FROM BONS, recu',
'    WHERE BONS.NUM_BON = RECU.NUM_BON ',
'    and num_vacation  = :P158_NUM_VACATION',
'    and paye =''O'';',
'    ',
'    --select nvl(sum(decode(sens,''D'',montant_op,0)),0) into  :P158_TOTAL_OPD from operation_caisse',
'    --where num_vacation = (select num_vacation from vacation where num_vacation = :P158_NUM_VACATION',
'    --and cloture = ''N'');',
'    select nvl(sum(decode(sens,''C'',montant_op,0)),0) into  :P158_TOTAL_OPC from operation_caisse',
'    where num_vacation = (select num_vacation from vacation where num_vacation = :P158_NUM_VACATION',
'    and cloture = ''N'') and CODE_TYPE_OP_CAISSE !=4;',
'    :P158_ENCAISSE_SYSTEM :=nvl(mt_encaisse,0)+ nvl(totbp,0) + nvl(:p158_total_opc,0) -nvl(:p158_total_opd,0);',
'    :p158_ecart := nvl(:P158_ENCAISSE_FIN,0) - nvl(:p158_encaisse_system,0);',
'    :P158_VERIF:=1;',
'    ',
'    insert into cloture values(:P158_NUM_VACATION,1,''Solde initial'',0,mt_encaisse,sysdate);',
unistr('    insert into cloture values(:P158_NUM_VACATION,2,''Ventes de la journ\00E9e'',0,totbp,sysdate);'),
unistr('    insert into cloture values(:P158_NUM_VACATION,3,''Autres recettes de la journ\00E9e'',0,:P158_TOTAL_OPC,sysdate);'),
unistr('    --insert into cloture values(:P158_NUM_VACATION,4,''D\00E9penses de la journ\00E9e'',:P158_TOTAL_OPD,0,sysdate);'),
'    insert into cloture  select :P158_NUM_VACATION,4,REFERENCE,montant_op,0,sysdate from operation_caisse',
'    where num_vacation = (select num_vacation from vacation where num_vacation = :P158_NUM_VACATION',
'    and cloture = ''N'')',
'    and sens =''D'';',
unistr('    insert into cloture values(:P158_NUM_VACATION,5,''Encaisse de fin de journ\00E9e'',:P158_ENCAISSE_FIN,0,sysdate);'),
'    ',
'    if :p158_ecart < 0 then',
'           insert into cloture values(:P158_NUM_VACATION,6,''Ecart'',:p158_ecart*-1,0,sysdate);',
'    elsif :p158_ecart > 0 then',
'            insert into cloture values(:P158_NUM_VACATION,6,''Ecart'',0,:p158_ecart,sysdate);',
'    end if;',
'    commit;',
'end;',
'   '))
,p_attribute_02=>'P158_TOTAL_BON_NPAYE,P158_TOTAL_OPD,P158_TOTAL_OPC,P158_ENCAISSE_SYSTEM,P158_ECART,P158_NUM_VACATION,P158_VERIF,P158_ENCAISSE_FIN'
,p_attribute_03=>'P158_TOTAL_BON_NPAYE,P158_TOTAL_OPD,P158_TOTAL_OPC,P158_ENCAISSE_SYSTEM,P158_ECART,P158_VERIF'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83434122717477236)
,p_event_id=>wwv_flow_imp.id(83433124489477234)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Veuillez saisir l&#x27;encaisse de fin de journ&#xE9;e avant !'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83434632856477236)
,p_event_id=>wwv_flow_imp.id(83433124489477234)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'V&#xE9;rification termin&#xE9;e'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83435129729477237)
,p_event_id=>wwv_flow_imp.id(83433124489477234)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(327591686983615225)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83435504725477237)
,p_name=>'Cloture'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(83429972863477228)
,p_condition_element=>'P158_VERIF'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83436043276477237)
,p_event_id=>wwv_flow_imp.id(83435504725477237)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Etes-vous s&#xFB;rs de vouloir cl&#xF4;turer? L&#x27;&#xE9;cart &#xE9;ventuel sera comptabilis&#xE9;'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83436521463477237)
,p_event_id=>wwv_flow_imp.id(83435504725477237)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Veuillez proc&#xE9;der &#xE0; la v&#xE9;rification avant ;'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83436961929477239)
,p_event_id=>wwv_flow_imp.id(83435504725477237)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DECLARE',
'',
'total number;',
'numvac number;',
'datevac date;',
'sens char(1);',
'mt_ecart number;',
'numcaisse number;',
'',
'begin',
'    select num_vacation,DATEHEURE_DEBUT_VAC,num_caisse INTO numvac,datevac,numcaisse',
'    from vacation',
'    where num_vacation = :P158_NUM_VACATION',
'    --and matricule = fn_matricule(v(''app_user''))',
'    and cloture = ''N'';',
'',
'    select nvl(sum(montant_bon),0) into total from bons',
'    where num_vacation = (select num_vacation from vacation where num_vacation = :P158_NUM_VACATION',
'    and matricule = fn_matricule(v(''app_user''))  and cloture = ''N'') and paye =''O'';		 	   ',
'   -- insert into operation_caisse',
'   -- values (OPERATION_CAISSE_NUM_OP_CAISSE.nextval/*NUM_OP_CAISSE*/,4/*CODE_TYPE_OP_CAISSE*/,    ',
'        --numcaisse/*NUM_CAISSE*/,to_char(fn_matricule(v(''app_user'')))/*MATRICULE*/,null/*NUM_REGL_CLT*/,           ',
'        --numvac/*NUM_VACATION*/,null/*NUM_REGL_FRN*/,datevac/*DATEHEURE_OP*/,total/*MONTANT_OP*/,             ',
'       -- ''VENTES DU '' || to_char(datevac,''dd/mm/yyyy'') /*REFERENCE*/,''C''/*SENS*/,''O''/*ACTIF*/,                  ',
'       -- v(''app_user'')/*CODE_UTILISATEUR*/,sysdate/*DATE_CREATION*/ );',
'     if nvl(:p158_ecart,0) != 0 then',
'        if nvl(:p158_ecart,0) > 0 then sens:=''C'';mt_ecart :=  nvl(:p158_ecart,0);',
'        else sens:=''D'';mt_ecart :=  nvl(:p158_ecart,0)*-1; end if;',
'        insert into operation_caisse',
'        values (OPERATION_CAISSE_NUM_OP_CAISSE.nextval/*NUM_OP_CAISSE*/,23/*CODE_TYPE_OP_CAISSE*/,    ',
'            numcaisse/*NUM_CAISSE*/,to_char(fn_matricule(v(''app_user'')))/*MATRICULE*/,null/*NUM_REGL_CLT*/,           ',
'            numvac/*NUM_VACATION*/,null/*NUM_REGL_FRN*/,datevac/*DATEHEURE_OP*/,mt_ecart/*MONTANT_OP*/,             ',
'            ''ECART DE CAISSE DU '' || to_char(datevac,''dd/mm/yyyy'') /*REFERENCE*/,sens/*SENS*/,''O''/*ACTIF*/,                  ',
'            v(''app_user'')/*CODE_UTILISATEUR*/,sysdate/*DATE_CREATION*/ );',
'      end if;',
'      update vacation set DATEHEURE_FIN_VAC = sysdate,MONTANT_TOTAL_BONS = total,MONTANT_ENCAISSE = :p158_encaisse_fin,',
'      ECART_VACATION = :P158_ECART,CLOTURE =''O'' where num_vacation =numvac;',
'				',
'		',
'end ;',
''))
,p_attribute_02=>'P158_ECART,P158_NUM_VACATION'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83437470468477239)
,p_event_id=>wwv_flow_imp.id(83435504725477237)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Cl&#xF4;ture effectu&#xE9;e avec succ&#xE8;s'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83438043392477240)
,p_event_id=>wwv_flow_imp.id(83435504725477237)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P158_NUM_VACATION'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83438517532477240)
,p_event_id=>wwv_flow_imp.id(83435504725477237)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(327592368576615232)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83438887092477240)
,p_name=>'encaisse'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P158_ENCAISSE_SYSTEM'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83439422728477242)
,p_event_id=>wwv_flow_imp.id(83438887092477240)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P158_ENCAISSE_SYSTEM_1'
,p_attribute_01=>'PLSQL_EXPRESSION'
,p_attribute_04=>'to_char(:P158_ENCAISSE_SYSTEM,''999G999G999G999G999G999G990'')'
,p_attribute_07=>'P158_ENCAISSE_SYSTEM'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83439838580477242)
,p_name=>'ecart'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P158_ECART'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83440273122477242)
,p_event_id=>wwv_flow_imp.id(83439838580477242)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P158_ECART_1'
,p_attribute_01=>'PLSQL_EXPRESSION'
,p_attribute_04=>'to_char(:P158_ECART,''999G999G999G999G999G999G990'')'
,p_attribute_07=>'P158_ECART'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83440728414477244)
,p_name=>'vac'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P158_POINT_VENTE'
,p_condition_element=>'P158_POINT_VENTE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83441194596477244)
,p_event_id=>wwv_flow_imp.id(83440728414477244)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P158_ENCAISSE_FIN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83441738746477244)
,p_event_id=>wwv_flow_imp.id(83440728414477244)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P158_ENCAISSE_FIN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83442230315477245)
,p_event_id=>wwv_flow_imp.id(83440728414477244)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(83429972863477228)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83442666187477247)
,p_event_id=>wwv_flow_imp.id(83440728414477244)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P158_ENCAISSE_SYSTEM,P158_ECART,P158_ENCAISSE_FIN'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'0'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83443241587477247)
,p_event_id=>wwv_flow_imp.id(83440728414477244)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(83429572176477228)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83443723688477247)
,p_event_id=>wwv_flow_imp.id(83440728414477244)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(83429972863477228)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83444163716477248)
,p_event_id=>wwv_flow_imp.id(83440728414477244)
,p_event_result=>'FALSE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(83429572176477228)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83444748860477248)
,p_event_id=>wwv_flow_imp.id(83440728414477244)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P158_ENCAISSE_SYSTEM,P158_ECART,P158_ENCAISSE_FIN'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'0'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83445224057477248)
,p_event_id=>wwv_flow_imp.id(83440728414477244)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_vac is select num_vacation ',
'from vacation',
'where  num_point_vente = :P158_POINT_VENTE',
'and cloture = ''N'';',
'',
'r_vac c_vac%rowtype;',
'',
'begin',
':P158_NUM_VACATION := null;',
'  open c_vac;',
'  fetch c_vac into r_vac;',
'  if c_vac%found then',
'    :P158_NUM_VACATION := r_vac.num_vacation;',
'  end if;',
'   select nvl(sum(montant_bon),0) into :p158_total_bon_Npaye from bons',
'    where num_vacation = (select num_vacation from vacation where num_vacation = :P158_NUM_VACATION and cloture = ''N'') ',
'    and paye =''N''',
'    and code_etat_bon =3;',
'end;',
'  '))
,p_attribute_02=>'P158_POINT_VENTE,P158_NUM_VACATION,P158_TOTAL_BON_NPAYE'
,p_attribute_03=>'P158_NUM_VACATION,P158_TOTAL_BON_NPAYE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83445683442477250)
,p_event_id=>wwv_flow_imp.id(83440728414477244)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(327482820706084768)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83446234139477250)
,p_event_id=>wwv_flow_imp.id(83440728414477244)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(113252628942509421)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83446594436477250)
,p_name=>'bnp'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P158_TOTAL_BON_NPAYE'
,p_condition_element=>'P158_TOTAL_BON_NPAYE'
,p_triggering_condition_type=>'LESS_THAN'
,p_triggering_expression=>'0'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83447139815477251)
,p_event_id=>wwv_flow_imp.id(83446594436477250)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P158_ENCAISSE_FIN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83447644892477251)
,p_event_id=>wwv_flow_imp.id(83446594436477250)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(83429972863477228)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83448094063477251)
,p_event_id=>wwv_flow_imp.id(83446594436477250)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(83429572176477228)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83448575013477253)
,p_event_id=>wwv_flow_imp.id(83446594436477250)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Il y&#x27;a encore des bons non encore encaiss&#xE9;s. Veuillez effectuer leur r&#xE8;glement avant !'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83449012052477253)
,p_name=>'app'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P158_PROFIL'
,p_condition_element=>'P158_PROFIL'
,p_triggering_condition_type=>'NOT_EQUALS'
,p_triggering_expression=>'3'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83449525513477253)
,p_event_id=>wwv_flow_imp.id(83449012052477253)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_pv is select num_point_vente from personnel p,affectation f',
'where p.matricule = f.matricule',
'and trim(profil_app)= v(''app_user'');',
'',
'r_pv c_pv%rowtype;',
'',
'begin',
' ',
'     open c_pv;',
'     fetch c_pv into r_pv;',
'     if c_pv%found then',
'         :P158_POINT_VENTE:= r_pv.num_point_vente;',
'         ',
'     end if;',
'     close c_pv;',
'',
'  end;'))
,p_attribute_02=>'P158_POINT_VENTE'
,p_attribute_03=>'P158_POINT_VENTE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83450032295477253)
,p_event_id=>wwv_flow_imp.id(83449012052477253)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P158_POINT_VENTE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83450372723477254)
,p_name=>'vac1'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P158_NUM_VACATION'
,p_condition_element=>'P158_NUM_VACATION'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83450902850477254)
,p_event_id=>wwv_flow_imp.id(83450372723477254)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(83429972863477228)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83451387188477254)
,p_event_id=>wwv_flow_imp.id(83450372723477254)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(83429972863477228)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83451901467477256)
,p_event_id=>wwv_flow_imp.id(83450372723477254)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(83429572176477228)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83452451112477256)
,p_event_id=>wwv_flow_imp.id(83450372723477254)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(83429572176477228)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(83432772922477233)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'supp'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete cloture where num_vacation = :P158_NUM_VACATION;',
'commit;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>83432772922477233
);
wwv_flow_imp.component_end;
end;
/
