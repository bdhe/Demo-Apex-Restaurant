prompt --application/pages/page_00127
begin
--   Manifest
--     PAGE: 00127
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>127
,p_name=>unistr('Entr\00E9e stock produits finis')
,p_alias=>unistr('ENTR\00C9E-STOCK-PRODUITS-FINIS')
,p_step_title=>unistr('Entr\00E9e stock produits finis')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(207162005718107744)
,p_name=>'Produits'
,p_template=>4072358936313175081
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_grid_column_span=>4
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUM_PRODUIT ID,NUM_produit,unite_mesure,:P127_NUMERO_APPRO num_appro,',
'       DESIGNATION_PRODUIT',
'  from PRODUITS',
'  where stockable = ''O''',
'  and nvl(:P127_NUMERO_APPRO,0) > 0',
'  and CODE_TYPE_PRODUIT = nvl(:P127_TYPE_PRODUIT_1,CODE_TYPE_PRODUIT)'))
,p_header=>' '
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P127_NUMERO_APPRO,P127_TYPE_PRODUIT_1'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85328865666778881)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>3
,p_column_heading=>'Id'
,p_column_link=>'f?p=&APP_ID.:116:&SESSION.::&DEBUG.:RP:P116_NUM_PRODUIT,P116_NUMERO_APPRO:#ID#,#NUM_APPRO#'
,p_column_linktext=>'<span class="t-Icon fa fa-toggle-right affbons-note" aria-hidden="true"></span>'
,p_column_link_attr=>'id=''#ID#'' class="affbons t-Button t-Button--danger t-Button--simple t-Button--small" title="Selectionner produit : #NUM_PRODUIT#"'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85329344416778883)
,p_query_column_id=>2
,p_column_alias=>'NUM_PRODUIT'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85329686157778883)
,p_query_column_id=>3
,p_column_alias=>'UNITE_MESURE'
,p_column_display_sequence=>2
,p_column_heading=>'Unite Mesure'
,p_column_html_expression=>'<span style="display:block; width:90px"><h5>#UNITE_MESURE#</h5></span>'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85330099128778886)
,p_query_column_id=>4
,p_column_alias=>'NUM_APPRO'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85330552806778886)
,p_query_column_id=>5
,p_column_alias=>'DESIGNATION_PRODUIT'
,p_column_display_sequence=>1
,p_column_heading=>'Designation Produit'
,p_column_html_expression=>'<span style="display:block; width:350px"><h5>#DESIGNATION_PRODUIT#</h5></span>'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(284282911457600267)
,p_plug_name=>'Point de vente'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>4
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(284283161341600270)
,p_name=>'Approvisionnement'
,p_parent_plug_id=>wwv_flow_imp.id(284282911457600267)
,p_template=>4072358936313175081
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUM_APPRO,',
'       LIBELLE,',
'       CODE_TYPE_APPRO,',
'       NUM_POINT_VENTED,',
'       NUM_POINT_VENTEA,',
'       DATE_APPRO,',
'       CODE_UTILISATEUR,',
'       DATE_CREATION,',
'       CODE_ETAT',
'  from APPRO',
'  where num_appro = :P127_NUMERO_APPRO',
'and code_etat = 0'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P127_NUMERO_APPRO'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85335530776778900)
,p_query_column_id=>1
,p_column_alias=>'NUM_APPRO'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85335869770778900)
,p_query_column_id=>2
,p_column_alias=>'LIBELLE'
,p_column_display_sequence=>2
,p_column_heading=>'Libelle'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85336311151778901)
,p_query_column_id=>3
,p_column_alias=>'CODE_TYPE_APPRO'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85336734358778901)
,p_query_column_id=>4
,p_column_alias=>'NUM_POINT_VENTED'
,p_column_display_sequence=>4
,p_column_heading=>'Point de vente principal'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(81104181522273040)
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85337073620778901)
,p_query_column_id=>5
,p_column_alias=>'NUM_POINT_VENTEA'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85337478930778903)
,p_query_column_id=>6
,p_column_alias=>'DATE_APPRO'
,p_column_display_sequence=>6
,p_column_heading=>'Date '
,p_column_format=>'DD/MM/YYYY'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85337888706778903)
,p_query_column_id=>7
,p_column_alias=>'CODE_UTILISATEUR'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85338304387778904)
,p_query_column_id=>8
,p_column_alias=>'DATE_CREATION'
,p_column_display_sequence=>8
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85338704912778904)
,p_query_column_id=>9
,p_column_alias=>'CODE_ETAT'
,p_column_display_sequence=>9
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(284285850478600296)
,p_plug_name=>unistr('D\00E9tails')
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUM_DETAIL_APPRO ,',
'        NUM_APPRO,',
'        unite_mesure,',
'        NUM_PRODUIT ,',
'        QTE  ',
'from details_appro',
'where num_appro = :P127_NUMERO_APPRO',
'and type_produit = nvl(:P127_TYPE_PRODUIT,type_produit)'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P127_NUMERO_APPRO,P127_TYPE_PRODUIT'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(206753083698185970)
,p_name=>'UNITE_MESURE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UNITE_MESURE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Unite Mesure'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>10
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(207164934385107773)
,p_name=>'menu'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>80
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(207165016762107774)
,p_name=>'selector'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>90
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'enable_multi_select', 'Y',
  'hide_control', 'N',
  'show_select_all', 'Y')).to_clob
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(285444578756509348)
,p_name=>'NUM_DETAIL_APPRO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NUM_DETAIL_APPRO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(285444680989509349)
,p_name=>'NUM_APPRO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NUM_APPRO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>40
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(285444825020509350)
,p_name=>'NUM_PRODUIT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NUM_PRODUIT'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Produit'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(81557789633430934)
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(285444898475509351)
,p_name=>'QTE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QTE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('Qt\00E9')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>60
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
,p_format_mask=>'999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(285444460562509347)
,p_internal_uid=>230271900106836378
,p_is_editable=>true
,p_edit_operations=>'u:d'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_show_nulls_as=>'-'
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>false
,p_show_toolbar=>true
,p_toolbar_buttons=>'SAVE'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>false
,p_define_chart_view=>false
,p_enable_download=>false
,p_download_formats=>null
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
' function(config) {',
'        let $             = apex.jQuery,',
'            toolbarData   = $.apex.interactiveGrid.copyDefaultToolbar(),',
'            addrowAction  = toolbarData.toolbarFind("selection-add-row"),',
'            saveAction    = toolbarData.toolbarFind("save"),',
'            editAction    = toolbarData.toolbarFind("edit");',
'         ',
'        addrowAction.icon = "icon-ig-add-row";',
'        addrowAction.iconBeforeLabel = true;',
'        addrowAction.hot = true;',
'        saveAction.label = "Enregistrer";',
'        saveAction.iconBeforeLabel = true;',
'        saveAction.icon ="icon-ig-save-as";',
'        saveAction.hot = true;',
'        editAction.label = "Modifier";',
'        config.toolbarData = toolbarData;',
'        return config;',
'    }'))
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(285450071373521842)
,p_interactive_grid_id=>wwv_flow_imp.id(285444460562509347)
,p_static_id=>'252240'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(285450197150521844)
,p_report_id=>wwv_flow_imp.id(285450071373521842)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(207038174111939085)
,p_view_id=>wwv_flow_imp.id(285450197150521844)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(206753083698185970)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(207197747186894964)
,p_view_id=>wwv_flow_imp.id(285450197150521844)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(207164934385107773)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(285450662016521847)
,p_view_id=>wwv_flow_imp.id(285450197150521844)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(285444578756509348)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(285451194577521849)
,p_view_id=>wwv_flow_imp.id(285450197150521844)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(285444680989509349)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(285451739471521850)
,p_view_id=>wwv_flow_imp.id(285450197150521844)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(285444825020509350)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(285452255234521853)
,p_view_id=>wwv_flow_imp.id(285450197150521844)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(285444898475509351)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85331658852778889)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(284282911457600267)
,p_button_name=>'Nouveau'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Nouvelle production'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85332027694778889)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(284282911457600267)
,p_button_name=>'Effacer'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Effacer'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85332410478778890)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(284282911457600267)
,p_button_name=>'Valider'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Validation production'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85332850516778892)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(284282911457600267)
,p_button_name=>'Quitter'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Quitter'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85330870353778886)
,p_name=>'P127_TYPE_PRODUIT_1'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(207162005718107744)
,p_prompt=>'Type produit'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TYPE_PRODUIT'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select libelle_type_produit as d,',
'       code_type_produit as r',
'  from type_produit',
' order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85333208020778894)
,p_name=>'P127_NUM_PV'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(284282911457600267)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pv.num_point_vente',
'from point_vente pv',
'where  pv.num_point_vente =101;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85333620046778895)
,p_name=>'P127_NOM_PV'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(284282911457600267)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Point de vente'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pv.nom_point_vente',
'from point_vente pv',
'where  pv.num_point_vente =101;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85334056760778897)
,p_name=>'P127_FOURNISSEUR'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(284282911457600267)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85334432687778897)
,p_name=>'P127_NUMERO_APPRO'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(284282911457600267)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('N\00B0Appro')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85334790208778898)
,p_name=>'P127_NUM_APPRO_MODIF'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(284282911457600267)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('S\00E9lectionner une production pour modification')
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(num_appro) ||''-''|| trim(libelle) as lib,num_appro ',
'from appro',
'where code_etat = 0',
'and code_type_appro =5 ',
'order by num_appro desc',
'--and num_point_ventea = :P107_NUM_PV;'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'DIALOG',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85342931144778915)
,p_name=>'P127_TYPE_PRODUIT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(284285850478600296)
,p_prompt=>'Type produit'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TYPE_PRODUIT_STOCK'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select libelle_type_produit as d,',
'       code_type_produit as r',
'  from type_produit',
'  where code_type_produit in (select code_type_produit from produits where STOCKABLE =''O'')',
' order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85343759134778917)
,p_name=>'demande'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(85331658852778889)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85344175808778919)
,p_event_id=>wwv_flow_imp.id(85343759134778917)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'num_pv number;',
'num_appro number;',
'',
'begin',
'  --select e.num_point_vente into num_pv from affectation a,personnel p,espace_vente e where a.matricule = p.matricule and a.num_espace_vente = e.num_espace_vente and trim(profil_app) = nvl(v(''app_user''), user);',
'  num_pv :=0;',
'  select seq_appro.nextval into num_appro from dual;',
'  insert into appro values(num_appro/*NUM_APPRO*/,''APPRO PDTS FINIS ''|| to_char(num_appro)/*LIBELLE*/,5/*CODE_TYPE_APPRO*/,:P127_NUM_PV/*NUM_POINT_VENTED*/,:P127_NUM_PV/*NUM_POINT_VENTEA*/,',
'                           sysdate/*DATE_APPRO*/,user/*CODE_UTILISATEUR */,sysdate/*DATE_CREATION*/,0/*CODE_ETAT*/,null );',
'  /* insert into details_appro select seq_num_detail_appro.nextval,num_appro,num_produit,0,code_type_produit,unite_mesure,0',
'   from produits',
'   where  stockable = ''O''; */',
'   :P127_NUMERO_APPRO := num_appro;',
'   commit;',
'end;',
'',
''))
,p_attribute_02=>'P127_NUMERO_APPRO,P127_NUM_PV'
,p_attribute_03=>'P127_NUMERO_APPRO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85344686249778920)
,p_event_id=>wwv_flow_imp.id(85343759134778917)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(284283161341600270)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85345237938778922)
,p_event_id=>wwv_flow_imp.id(85343759134778917)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(207162005718107744)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85345707383778926)
,p_event_id=>wwv_flow_imp.id(85343759134778917)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(284285850478600296)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85346112154778928)
,p_name=>'Nouveau'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_NUMERO_APPRO'
,p_condition_element=>'P127_NUMERO_APPRO'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85346599094778931)
,p_event_id=>wwv_flow_imp.id(85346112154778928)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(85331658852778889)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85347126541778931)
,p_event_id=>wwv_flow_imp.id(85346112154778928)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(85331658852778889)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85347492314778931)
,p_name=>'type'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_TYPE_PRODUIT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85347964338778936)
,p_event_id=>wwv_flow_imp.id(85347492314778931)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(284285850478600296)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85348415831778936)
,p_name=>'qte'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(207162005718107744)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85348911846778937)
,p_event_id=>wwv_flow_imp.id(85348415831778936)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(284285850478600296)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85349290995778937)
,p_name=>'refreshrd'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_TYPE_PRODUIT_1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85349812224778940)
,p_event_id=>wwv_flow_imp.id(85349290995778937)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(207162005718107744)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85350217131778940)
,p_name=>'modif'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P127_NUM_APPRO_MODIF'
,p_condition_element=>'P127_NUMERO_APPRO'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85350744311778940)
,p_event_id=>wwv_flow_imp.id(85350217131778940)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>' :P127_NUMERO_APPRO := :P127_NUM_APPRO_MODIF;'
,p_attribute_02=>'P127_NUMERO_APPRO,P127_NUM_APPRO_MODIF'
,p_attribute_03=>'P127_NUMERO_APPRO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85351255831778942)
,p_event_id=>wwv_flow_imp.id(85350217131778940)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Veuillez la livraison courant avant !'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85351696712778942)
,p_event_id=>wwv_flow_imp.id(85350217131778940)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(284283161341600270)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85352214957778944)
,p_event_id=>wwv_flow_imp.id(85350217131778940)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(284285850478600296)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85352724109778944)
,p_event_id=>wwv_flow_imp.id(85350217131778940)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(207162005718107744)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85353147246778944)
,p_name=>'effacer'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(85332027694778889)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85353620735778945)
,p_event_id=>wwv_flow_imp.id(85353147246778944)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P127_NUMERO_APPRO'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85354093535778945)
,p_event_id=>wwv_flow_imp.id(85353147246778944)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(284283161341600270)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85354592923778947)
,p_event_id=>wwv_flow_imp.id(85353147246778944)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(284285850478600296)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85355134659778947)
,p_event_id=>wwv_flow_imp.id(85353147246778944)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(207162005718107744)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85355557996778947)
,p_name=>'vprod'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(85332410478778890)
,p_condition_element=>'P127_NUM_APPRO_MODIF'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85355969351778948)
,p_event_id=>wwv_flow_imp.id(85355557996778947)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Etes-vous s&#xFB;r de vouloir valiser la pr&#xE9;sente production?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85356490567778948)
,p_event_id=>wwv_flow_imp.id(85355557996778947)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Veuillez s&#xE9;lectionner ou cr&#xE9;e un approvisionnement avant !'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85356990882778951)
,p_event_id=>wwv_flow_imp.id(85355557996778947)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'cursor c_appro is select * from appro where num_appro = :P127_NUMERO_APPRO; r_appro c_appro%rowtype;',
'cursor c_det is select * from details_appro where num_appro = :P127_NUMERO_APPRO and nvl(qte_acc,0) > 0; r_det c_det%rowtype;',
'cursor c_fiche is select * from fiche_tech  where num_produit = r_det.NUM_PRODUIT     and qte_fich > 0;     r_fiche c_fiche%rowtype;',
' cursor c_cmde is select num_cmde from  appro_commande where num_appro = r_appro.num_appro;   r_cmde c_cmde%rowtype;',
'begin',
'       open c_appro;',
'       fetch c_appro into r_appro;',
'       if c_appro%found then',
'            open c_det;',
'            loop',
'                fetch c_det into r_det;',
'                exit when c_det%notfound;',
'                   if r_appro.code_type_appro in (3,4) then',
'                        insert into mouvement values (MOUVEMENT_NUM_MVT_SEQ.nextval/*NUM_MVT*/,r_det.NUM_PRODUIT,5/*CODE_TYPE_MOUVEMENT*/,null/*NUM_BON*/,r_appro.num_point_vented/*NUM_POINT_VENTE*/,null/*NUM_LIVR*/, null/*NUM_LIVR_CLT*/,null/*NUM_CMD'
||'E*/,null/*CODE_FOURN*/,r_det.qte_acc/*QTE*/,sysdate/*DATE_MVT*/,0/*PU_MVT*/,''1''/*ETAT*/,nvl(v(''app_user''), user)/*CODE_UTILISATEUR*/,sysdate/*DATE_CREATION*/ ,null/*NUM_CARNET*/,null/*MATRICULE*/,null/*NUM_TICKET*/,2/*CODE_NATURE_MVT*/,r_det.num_appr'
||'o);',
'                        insert into mouvement values (MOUVEMENT_NUM_MVT_SEQ.nextval/*NUM_MVT*/,r_det.NUM_PRODUIT,6/*CODE_TYPE_MOUVEMENT*/,null/*NUM_BON*/,r_appro.num_point_ventea/*NUM_POINT_VENTE*/, null/*NUM_LIVR*/, null/*NUM_LIVR_CLT*/,null/*NUM_CM'
||'DE*/,null/*CODE_FOURN*/,r_det.qte_acc/*QTE*/,sysdate/*DATE_MVT*/,0/*PU_MVT*/,''1''/*ETAT*/,nvl(v(''app_user''), user)/*CODE_UTILISATEUR*/,sysdate/*DATE_CREATION*/ ,null/*NUM_CARNET*/,null/*MATRICULE*/, null/*NUM_TICKET*/,2/*CODE_NATURE_MVT*/,r_det.num_ap'
||'pro);',
'                   elsif r_appro.code_type_appro in (0,6) then',
'                         insert into mouvement values  (MOUVEMENT_NUM_MVT_SEQ.nextval/*NUM_MVT*/,r_det.NUM_PRODUIT,4/*CODE_TYPE_MOUVEMENT*/,null/*NUM_BON*/,r_appro.num_point_vented/*NUM_POINT_VENTE*/, null/*NUM_LIVR*/, null/*NUM_LIVR_CLT*/,null/*NUM_'
||'CMDE*/,r_appro.code_fourn/*CODE_FOURN*/,r_det.qte/*QTE*/,sysdate/*DATE_MVT*/,0/*PU_MVT*/,''1''/*ETAT*/,nvl(v(''app_user''), user)/*CODE_UTILISATEUR*/,sysdate/*DATE_CREATION*/ ,null/*NUM_CARNET*/,null/*MATRICULE*/,null/*NUM_TICKET*/,2/*CODE_NATURE_MVT*/,r'
||'_det.num_appro);',
'                         open c_cmde; fetch c_cmde into r_cmde; if c_cmde%found then update commande_frns set code_etat = 2 where num_cmde =r_cmde.num_cmde; end if; close c_cmde;',
'                    elsif r_appro.code_type_appro = 5 then',
'                         insert into mouvement values (MOUVEMENT_NUM_MVT_SEQ.nextval/*NUM_MVT*/,r_det.NUM_PRODUIT,6/*CODE_TYPE_MOUVEMENT*/,null/*NUM_BON*/,r_appro.num_point_ventea/*NUM_POINT_VENTE*/, null/*NUM_LIVR*/, null/*NUM_LIVR_CLT*/,null/*NUM_C'
||'MDE*/,null/*CODE_FOURN*/,r_det.qte_acc/*QTE*/,sysdate/*DATE_MVT*/,0/*PU_MVT*/,''1''/*ETAT*/,nvl(v(''app_user''), user)/*CODE_UTILISATEUR*/,sysdate/*DATE_CREATION*/ ,null/*NUM_CARNET*/,null/*MATRICULE*/, null/*NUM_TICKET*/,2/*CODE_NATURE_MVT*/,r_det.num_a'
||'ppro);',
'                        open c_fiche; loop fetch c_fiche into r_fiche; exit when c_fiche%notfound; insert into mouvement values (MOUVEMENT_NUM_MVT_SEQ.nextval/*NUM_MVT*/,r_fiche.pro_num_produit,18/*CODE_TYPE_MOUVEMENT*/,null/*NUM_BON*/,r_appro.num_po'
||'int_ventea/*NUM_POINT_VENTE*/, null/*NUM_LIVR*/, null/*NUM_LIVR_CLT*/, null/*NUM_CMDE*/,null/*CODE_FOURN*/,r_fiche.qte_fich*r_det.qte/*QTE*/,sysdate/*DATE_MVT*/,0/*PU_MVT*/,''1''/*ETAT*/,nvl(v(''app_user''), user)/*CODE_UTILISATEUR*/,sysdate/*DATE_CREATI'
||'ON*/ ,null/*NUM_CARNET*/,to_char(fn_matricule(nvl(v(''app_user''), user)))/*MATRICULE*/,null/*NUM_TICKET*/,2/*CODE_NATURE_MVT*/,null);  end loop;     close c_fiche;',
'                   end if;',
'            end loop;',
'            close c_det;',
'        end if;',
'        close c_appro;',
'     update appro set code_etat = 1   where num_appro = :P127_NUMERO_APPRO;',
'    commit;',
' end;'))
,p_attribute_02=>'P127_NUMERO_APPRO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85357476951778951)
,p_event_id=>wwv_flow_imp.id(85355557996778947)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Validation effectu&#xE9;e avec succ&#xE8;s'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85358005745778951)
,p_event_id=>wwv_flow_imp.id(85355557996778947)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P127_NUMERO_APPRO,P127_NUM_APPRO_MODIF'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85358511752778953)
,p_event_id=>wwv_flow_imp.id(85355557996778947)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(284285850478600296)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85359058170778953)
,p_event_id=>wwv_flow_imp.id(85355557996778947)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(284283161341600270)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85359509442778953)
,p_event_id=>wwv_flow_imp.id(85355557996778947)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(207162005718107744)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(85343282325778915)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(284285850478600296)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>unistr('D\00E9tails - Enregistrer les donn\00E9es de grille interactive')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>85343282325778915
);
wwv_flow_imp.component_end;
end;
/
