prompt --application/pages/page_00119
begin
--   Manifest
--     PAGE: 00119
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>119
,p_name=>'Liste des appro pv'
,p_alias=>'LISTE-DES-APPRO-PV'
,p_step_title=>'Liste des appro pv'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(240518948823638954)
,p_plug_name=>'Liste des appro '
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "NUM_APPRO", ',
'"LIBELLE",',
'"CODE_TYPE_APPRO",',
'"NUM_POINT_VENTED",',
'"NUM_POINT_VENTEA",',
'"DATE_APPRO",',
'"CODE_UTILISATEUR",',
'"DATE_CREATION",',
'"CODE_ETAT"',
'from "APPRO" ',
'where  num_point_ventea = (select num_point_vente from affectation a,personnel p',
'where a.matricule = p.matricule and trim(profil_app) = trim(v(''app_user'')))',
'and code_etat = 1',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(240519418452638956)
,p_name=>unistr('Liste des appro valid\00E9s')
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_enable_mail_download=>'N'
,p_detail_link=>'f?p=&APP_ID.:120:&SESSION.::&DEBUG.::P120_NUM_APPRO:#NUM_APPRO#'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'BDHE'
,p_internal_uid=>185346857996965987
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85082402288548262)
,p_db_column_name=>'NUM_APPRO'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>unistr('N\00B0 Appro')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85082764046548264)
,p_db_column_name=>'LIBELLE'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Libelle'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85083072596548265)
,p_db_column_name=>'CODE_TYPE_APPRO'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Type Appro'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(81193600919304700)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85083467687548265)
,p_db_column_name=>'NUM_POINT_VENTED'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Point de vente sortie'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(81104181522273040)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85083862702548267)
,p_db_column_name=>'NUM_POINT_VENTEA'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>unistr('Point de vente entr\00E9e')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(81104181522273040)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85084309904548267)
,p_db_column_name=>'DATE_APPRO'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Date '
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85084723599548269)
,p_db_column_name=>'CODE_UTILISATEUR'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Code Utilisateur'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85085157128548269)
,p_db_column_name=>'DATE_CREATION'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Date Creation'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85085559925548270)
,p_db_column_name=>'CODE_ETAT'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Etat'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(240533198281653729)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'24353'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NUM_APPRO:LIBELLE:CODE_TYPE_APPRO:NUM_POINT_VENTED:NUM_POINT_VENTEA:DATE_APPRO:CODE_UTILISATEUR:DATE_CREATION:CODE_ETAT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85086206836548276)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(240518948823638954)
,p_button_name=>'Quitter'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Quitter'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_imp.component_end;
end;
/
