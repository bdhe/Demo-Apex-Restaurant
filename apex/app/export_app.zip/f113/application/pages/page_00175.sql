prompt --application/pages/page_00175
begin
--   Manifest
--     PAGE: 00175
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>175
,p_name=>'Appro direct pv'
,p_alias=>'APPRO-DIRECT-PV'
,p_step_title=>'Appro direct pv'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(216905946065031262)
,p_name=>'Produits'
,p_template=>4072358936313175081
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUM_PRODUIT ID,NUM_produit,unite_mesure,:P175_NUMERO_APPRO num_appro,',
'       DESIGNATION_PRODUIT',
'  from PRODUITS',
'  where stockable = ''O''',
'  and nvl(:P175_NUMERO_APPRO,0) > 0',
'  and CODE_TYPE_PRODUIT = nvl(:P175_TYPE_PRODUIT_1,CODE_TYPE_PRODUIT)'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P175_NUMERO_APPRO,P175_TYPE_PRODUIT_1'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85097996058573153)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>3
,p_column_link=>'f?p=&APP_ID.:116:&SESSION.::&DEBUG.:RP:P116_NUM_PRODUIT,P116_NUMERO_APPRO:#ID#,#NUM_APPRO#'
,p_column_linktext=>'<span class="t-Icon fa fa-toggle-right affbons-note" aria-hidden="true"></span>'
,p_column_link_attr=>'id=''#ID#'' class="affbons t-Button t-Button--danger t-Button--simple t-Button--small" title="Selectionner produit : #NUM_PRODUIT#"'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85098408494573154)
,p_query_column_id=>2
,p_column_alias=>'NUM_PRODUIT'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85098835260573154)
,p_query_column_id=>3
,p_column_alias=>'UNITE_MESURE'
,p_column_display_sequence=>2
,p_column_heading=>'Unite Mesure'
,p_column_html_expression=>'<span style="display:block; width:90px"><h5>#UNITE_MESURE#</h5></span>'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85099240767573156)
,p_query_column_id=>4
,p_column_alias=>'NUM_APPRO'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85099579867573156)
,p_query_column_id=>5
,p_column_alias=>'DESIGNATION_PRODUIT'
,p_column_display_sequence=>1
,p_column_heading=>'Designation Produit'
,p_column_html_expression=>'<span style="display:block; width:350px"><h5>#DESIGNATION_PRODUIT#</h5></span>'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(294026851804523785)
,p_plug_name=>'Point de vente'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>3
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(294027101688523788)
,p_name=>'Approvisionnement'
,p_parent_plug_id=>wwv_flow_imp.id(294026851804523785)
,p_template=>4072358936313175081
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_display_point=>'SUB_REGIONS'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUM_APPRO,',
'       LIBELLE,',
'       CODE_TYPE_APPRO,',
'       NUM_POINT_VENTED,',
'       NUM_POINT_VENTEA,',
'       DATE_APPRO,',
'       CODE_UTILISATEUR,',
'       DATE_CREATION,',
'       CODE_ETAT',
'  from APPRO',
'  where num_appro = :P175_NUMERO_APPRO',
'and code_etat = 0'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P175_NUMERO_APPRO'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85104944821573167)
,p_query_column_id=>1
,p_column_alias=>'NUM_APPRO'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85105322949573167)
,p_query_column_id=>2
,p_column_alias=>'LIBELLE'
,p_column_display_sequence=>2
,p_column_heading=>'Libelle'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85105684103573169)
,p_query_column_id=>3
,p_column_alias=>'CODE_TYPE_APPRO'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85106103882573169)
,p_query_column_id=>4
,p_column_alias=>'NUM_POINT_VENTED'
,p_column_display_sequence=>4
,p_column_heading=>'Point de vente principal'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(81104181522273040)
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85106495098573169)
,p_query_column_id=>5
,p_column_alias=>'NUM_POINT_VENTEA'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85106881633573170)
,p_query_column_id=>6
,p_column_alias=>'DATE_APPRO'
,p_column_display_sequence=>6
,p_column_heading=>'Date '
,p_column_format=>'DD/MM/YYYY'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85107341610573170)
,p_query_column_id=>7
,p_column_alias=>'CODE_UTILISATEUR'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85107670367573170)
,p_query_column_id=>8
,p_column_alias=>'DATE_CREATION'
,p_column_display_sequence=>8
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85108104439573172)
,p_query_column_id=>9
,p_column_alias=>'CODE_ETAT'
,p_column_display_sequence=>9
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(294029790825523814)
,p_plug_name=>unistr('D\00E9tails')
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>4
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUM_DETAIL_APPRO ,',
'        NUM_APPRO,',
'        unite_mesure,',
'        NUM_PRODUIT ,',
'        QTE  ',
'from details_appro',
'where num_appro = :P175_NUMERO_APPRO',
'and type_produit = nvl(:P175_TYPE_PRODUIT,type_produit)'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P175_NUMERO_APPRO,P175_TYPE_PRODUIT'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(216497024045109488)
,p_name=>'UNITE_MESURE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UNITE_MESURE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Unite Mesure'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>10
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(216908874732031291)
,p_name=>'menu'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>80
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(216908957109031292)
,p_name=>'selector'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>90
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'enable_multi_select', 'Y',
  'hide_control', 'N',
  'show_select_all', 'Y')).to_clob
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(295188519103432866)
,p_name=>'NUM_DETAIL_APPRO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NUM_DETAIL_APPRO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(295188621336432867)
,p_name=>'NUM_APPRO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NUM_APPRO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>40
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(295188765367432868)
,p_name=>'NUM_PRODUIT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NUM_PRODUIT'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Produit'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(81557789633430934)
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(295188838822432869)
,p_name=>'QTE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QTE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('Qt\00E9')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>60
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
,p_format_mask=>'999G999G999G999G990D00'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(295188400909432865)
,p_internal_uid=>240015840453759896
,p_is_editable=>true
,p_edit_operations=>'u:d'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_show_nulls_as=>'-'
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>false
,p_show_toolbar=>true
,p_toolbar_buttons=>'SAVE'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>false
,p_define_chart_view=>false
,p_enable_download=>false
,p_download_formats=>null
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
' function(config) {',
'        let $             = apex.jQuery,',
'            toolbarData   = $.apex.interactiveGrid.copyDefaultToolbar(),',
'            addrowAction  = toolbarData.toolbarFind("selection-add-row"),',
'            saveAction    = toolbarData.toolbarFind("save"),',
'            editAction    = toolbarData.toolbarFind("edit");',
'         ',
'        addrowAction.icon = "icon-ig-add-row";',
'        addrowAction.iconBeforeLabel = true;',
'        addrowAction.hot = true;',
'        saveAction.label = "Enregistrer";',
'        saveAction.iconBeforeLabel = true;',
'        saveAction.icon ="icon-ig-save-as";',
'        saveAction.hot = true;',
'        editAction.label = "Modifier";',
'        config.toolbarData = toolbarData;',
'        return config;',
'    }'))
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(295194011720445360)
,p_interactive_grid_id=>wwv_flow_imp.id(295188400909432865)
,p_static_id=>'252299'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(295194137497445362)
,p_report_id=>wwv_flow_imp.id(295194011720445360)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(216782114458862603)
,p_view_id=>wwv_flow_imp.id(295194137497445362)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(216497024045109488)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(216941687533818482)
,p_view_id=>wwv_flow_imp.id(295194137497445362)
,p_display_seq=>0
,p_column_id=>wwv_flow_imp.id(216908874732031291)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(295194602363445365)
,p_view_id=>wwv_flow_imp.id(295194137497445362)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(295188519103432866)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(295195134924445367)
,p_view_id=>wwv_flow_imp.id(295194137497445362)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(295188621336432867)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(295195679818445368)
,p_view_id=>wwv_flow_imp.id(295194137497445362)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(295188765367432868)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(295196195581445371)
,p_view_id=>wwv_flow_imp.id(295194137497445362)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(295188838822432869)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85100749991573159)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(294026851804523785)
,p_button_name=>'Nouveau'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Cr\00E9er')
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85101082218573159)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(294026851804523785)
,p_button_name=>'Effacer'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Effacer'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85101560319573159)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(294026851804523785)
,p_button_name=>'Supprimer'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Supprimer'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85101860770573161)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(294026851804523785)
,p_button_name=>'Quitter'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Quitter'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85099964352573158)
,p_name=>'P175_TYPE_PRODUIT_1'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(216905946065031262)
,p_prompt=>'Type produit'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TYPE_PRODUIT_STOCK'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select libelle_type_produit as d,',
'       code_type_produit as r',
'  from type_produit',
'  where code_type_produit in (select code_type_produit from produits where STOCKABLE =''O'')',
' order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85102345068573161)
,p_name=>'P175_ACTION'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(294026851804523785)
,p_item_default=>'1'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC2:Nouveau;1,Modification;2'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85102743213573162)
,p_name=>'P175_FOURNISSEURN'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(294026851804523785)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fournisseur'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'FOURNISSEUR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nom_fourn as d,',
'       code_fourn as r',
'  from fournisseur',
' order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85103077364573162)
,p_name=>'P175_NUM_POINT_VENTEA'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(294026851804523785)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select num_point_vente from personnel p,affectation f',
'where p.matricule = f.matricule',
'and trim(profil_app)= v(''app_user'');',
''))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>unistr('Point de vente arriv\00E9e')
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'POINT_VENTE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nom_point_vente as d,',
'       num_point_vente as r',
'  from point_vente where actif=''O''',
'order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85103477931573164)
,p_name=>'P175_NUMERO_APPRO'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(294026851804523785)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85103842461573165)
,p_name=>'P175_NUM_APPRO_MODIF'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(294026851804523785)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('S\00E9lectionner une livraison pour modification')
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(num_appro) ||''-''|| trim(libelle) as lib,num_appro ',
'from appro',
'where code_etat = 0',
'and code_type_appro = 4',
'order by num_appro desc',
'--and num_point_ventea = :P107_NUM_PV;'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'DIALOG',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85104168105573165)
,p_name=>'P175_PVNULL'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(294026851804523785)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85112323039573181)
,p_name=>'P175_TYPE_PRODUIT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(294029790825523814)
,p_prompt=>'Type produit'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TYPE_PRODUIT_STOCK'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select libelle_type_produit as d,',
'       code_type_produit as r',
'  from type_produit',
'  where code_type_produit in (select code_type_produit from produits where STOCKABLE =''O'')',
' order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85113081277573183)
,p_name=>'demande'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(85100749991573159)
,p_condition_element=>'P175_FOURNISSEURN'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85113613401573183)
,p_event_id=>wwv_flow_imp.id(85113081277573183)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'num_pv number;',
'num_appro number;',
'pvd number;',
'nom_pvd varchar2(20);',
'nom_pva varchar2(20);',
'code_typea number ;',
'begin',
'  --select e.num_point_vente into num_pv from affectation a,personnel p,espace_vente e where a.matricule = p.matricule and a.num_espace_vente = e.num_espace_vente and trim(profil_app) = nvl(v(''app_user''), user);',
' -- num_pv :=0;',
'  ',
'      nom_pvd := ''Cmde fournisseur'';',
'      code_typea  :=4;',
' ',
'  select seq_appro.nextval into num_appro from dual;',
unistr('  insert into appro values(num_appro/*NUM_APPRO*/,''Appro direct N\00B0 ''|| to_char(num_appro)||''-''||trim(nom_pvd)||''/''||trim(nom_pva)/*LIBELLE*/,code_typea/*CODE_TYPE_APPRO*/,pvd/*NUM_POINT_VENTED*/,:P175_NUM_POINT_VENTEA/*NUM_POINT_VENTEA*/,'),
'                           sysdate/*DATE_APPRO*/,v(''app_user'')/*CODE_UTILISATEUR */,sysdate/*DATE_CREATION*/,0/*CODE_ETAT*/,:P175_FOURNISSEURN );',
'  /* insert into details_appro select seq_num_detail_appro.nextval,num_appro,num_produit,0,code_type_produit,unite_mesure,0',
'   from produits',
'   where  stockable = ''O''; */',
'   :P175_NUMERO_APPRO := num_appro;',
'   commit;',
'end;',
'',
''))
,p_attribute_02=>'P175_NUMERO_APPRO,P175_NUM_POINT_VENTEA,P175_FOURNISSEURN'
,p_attribute_03=>'P175_NUMERO_APPRO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85114117119573184)
,p_event_id=>wwv_flow_imp.id(85113081277573183)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Vous devez renseigner fournisseur !'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85114578803573184)
,p_event_id=>wwv_flow_imp.id(85113081277573183)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(294027101688523788)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85115145738573186)
,p_event_id=>wwv_flow_imp.id(85113081277573183)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(216905946065031262)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85115646749573186)
,p_event_id=>wwv_flow_imp.id(85113081277573183)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(294029790825523814)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85116009988573186)
,p_name=>'Nouveau'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P175_NUMERO_APPRO'
,p_condition_element=>'P175_NUMERO_APPRO'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85116513961573187)
,p_event_id=>wwv_flow_imp.id(85116009988573186)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(85100749991573159)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85116987860573187)
,p_event_id=>wwv_flow_imp.id(85116009988573186)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(85100749991573159)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85117411429573187)
,p_name=>'type'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P175_TYPE_PRODUIT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85117907060573189)
,p_event_id=>wwv_flow_imp.id(85117411429573187)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(294029790825523814)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85118349565573189)
,p_name=>'qte'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(216905946065031262)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85118806082573189)
,p_event_id=>wwv_flow_imp.id(85118349565573189)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(294029790825523814)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85119202147573190)
,p_name=>'refreshrd'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P175_TYPE_PRODUIT_1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85119688542573190)
,p_event_id=>wwv_flow_imp.id(85119202147573190)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(216905946065031262)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85120151468573190)
,p_name=>'modif'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P175_NUM_APPRO_MODIF'
,p_condition_element=>'P175_NUMERO_APPRO'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85120632957573192)
,p_event_id=>wwv_flow_imp.id(85120151468573190)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>' :P175_NUMERO_APPRO := :P175_NUM_APPRO_MODIF;'
,p_attribute_02=>'P175_NUMERO_APPRO,P175_NUM_APPRO_MODIF'
,p_attribute_03=>'P175_NUMERO_APPRO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85121094340573192)
,p_event_id=>wwv_flow_imp.id(85120151468573190)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Veuillez la livraison courant avant !'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85121569036573192)
,p_event_id=>wwv_flow_imp.id(85120151468573190)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(294027101688523788)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85122090379573194)
,p_event_id=>wwv_flow_imp.id(85120151468573190)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(294029790825523814)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85122658129573194)
,p_event_id=>wwv_flow_imp.id(85120151468573190)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(216905946065031262)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85122985435573194)
,p_name=>'effacer'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(85101082218573159)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85123540377573195)
,p_event_id=>wwv_flow_imp.id(85122985435573194)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P175_NUMERO_APPRO'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85124038023573195)
,p_event_id=>wwv_flow_imp.id(85122985435573194)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(294027101688523788)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85124514712573197)
,p_event_id=>wwv_flow_imp.id(85122985435573194)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(294029790825523814)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85125042573573197)
,p_event_id=>wwv_flow_imp.id(85122985435573194)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(216905946065031262)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85125547505573197)
,p_event_id=>wwv_flow_imp.id(85122985435573194)
,p_event_result=>'TRUE'
,p_action_sequence=>90
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P175_NUM_APPRO_MODIF'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85125919036573198)
,p_name=>'New'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P175_FOURNISSEUR'
,p_condition_element=>'P175_FOURNISSEUR'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85126399341573198)
,p_event_id=>wwv_flow_imp.id(85125919036573198)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P175_NUM_POINT_VENTED'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85126920680573200)
,p_event_id=>wwv_flow_imp.id(85125919036573198)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P175_NUM_POINT_VENTED'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85127413572573200)
,p_event_id=>wwv_flow_imp.id(85125919036573198)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P175_FOURNISSEURN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85127898572573200)
,p_event_id=>wwv_flow_imp.id(85125919036573198)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P175_FOURNISSEURN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85128393410573201)
,p_event_id=>wwv_flow_imp.id(85125919036573198)
,p_event_result=>'FALSE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P175_NUM_POINT_VENTEA'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85128851365573201)
,p_name=>'supp'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(85101560319573159)
,p_condition_element=>'P175_NUMERO_APPRO'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85129290906573203)
,p_event_id=>wwv_flow_imp.id(85128851365573201)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Etes-vous s&#xFB;rs de vouloir supprimer cet approvisoinnement?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85129805428573203)
,p_event_id=>wwv_flow_imp.id(85128851365573201)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete details_appro where num_appro = :P175_NUMERO_APPRO;',
'delete appro where num_appro = :P175_NUMERO_APPRO;',
'commit;'))
,p_attribute_02=>'P175_NUMERO_APPRO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85130302382573203)
,p_event_id=>wwv_flow_imp.id(85128851365573201)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P175_NUMERO_APPRO'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85130788092573204)
,p_event_id=>wwv_flow_imp.id(85128851365573201)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(294027101688523788)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85131323352573204)
,p_event_id=>wwv_flow_imp.id(85128851365573201)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(294029790825523814)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85131766777573204)
,p_event_id=>wwv_flow_imp.id(85128851365573201)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(216905946065031262)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85132321993573206)
,p_event_id=>wwv_flow_imp.id(85128851365573201)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P175_NUM_APPRO_MODIF'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85132715165573206)
,p_name=>'APP'
,p_event_sequence=>100
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P175_PROFIL'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85133250143573208)
,p_event_id=>wwv_flow_imp.id(85132715165573206)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_pv is select num_point_vente from personnel p,affectation f',
'where p.matricule = f.matricule',
'and trim(profil_app)= v(''app_user'');',
'',
'r_pv c_pv%rowtype;',
'',
'begin',
' ',
'     open c_pv;',
'     fetch c_pv into r_pv;',
'     if c_pv%found then',
'         :P148_NUM_POINT_VENTEA:= r_pv.num_point_vente;',
'         :P148_FOURNISSEUR := null;',
'         ',
'     end if;',
'     close c_pv;',
'',
'  end;'))
,p_attribute_02=>'P175_NUM_POINT_VENTEA'
,p_attribute_03=>'P175_NUM_POINT_VENTEA'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85133730160573208)
,p_event_id=>wwv_flow_imp.id(85132715165573206)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P175_NUM_POINT_VENTEA'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85134113897573208)
,p_name=>'action'
,p_event_sequence=>110
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P175_ACTION'
,p_condition_element=>'P175_ACTION'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85134583620573209)
,p_event_id=>wwv_flow_imp.id(85134113897573208)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(85100749991573159)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85135159417573209)
,p_event_id=>wwv_flow_imp.id(85134113897573208)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(85100749991573159)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85135583213573209)
,p_event_id=>wwv_flow_imp.id(85134113897573208)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P175_NUM_APPRO_MODIF'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85136147882573211)
,p_event_id=>wwv_flow_imp.id(85134113897573208)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P175_NUM_APPRO_MODIF'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85136534904573211)
,p_name=>'New'
,p_event_sequence=>120
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P175_NUM_POINT_VENTEA'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85136962259573211)
,p_event_id=>wwv_flow_imp.id(85136534904573211)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P175_NUM_POINT_VENTEA'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(85112757027573181)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(294029790825523814)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>unistr('D\00E9tails - Enregistrer les donn\00E9es de grille interactive')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>85112757027573181
);
wwv_flow_imp.component_end;
end;
/
