prompt --application/pages/page_00179
begin
--   Manifest
--     PAGE: 00179
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>179
,p_name=>'Livraison'
,p_alias=>'LIVRAISON'
,p_page_mode=>'MODAL'
,p_step_title=>'Livraison'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(210965843055339442)
,p_name=>'Recu'
,p_template=>4072358936313175081
,p_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUM_RECU,',
'       NUM_BON,',
'       REMISE,',
'       ARRONDI,',
'       FRAIS_LIVRAISON,',
'       NET,',
'       NUM_LIVREUR,',
'       MONTANT_RECU,',
'       RELIQUAT,',
'       CODE_MODE_REG,',
'       REFERENCE_PAYEMENT,',
'       NOM,',
'       TXREFERENCE,',
'       STATUS,',
'       DATEPAYEMENT,',
'       PAYEMENTMETHODE,',
'       ETAT',
'  from RECU',
' where NUM_BON = :P179_NUM_BON'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83867355520712794)
,p_query_column_id=>1
,p_column_alias=>'NUM_RECU'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83867675259712795)
,p_query_column_id=>2
,p_column_alias=>'NUM_BON'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83868062799712795)
,p_query_column_id=>3
,p_column_alias=>'REMISE'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83868460651712797)
,p_query_column_id=>4
,p_column_alias=>'ARRONDI'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83868891277712797)
,p_query_column_id=>5
,p_column_alias=>'FRAIS_LIVRAISON'
,p_column_display_sequence=>5
,p_column_heading=>'Frais Livraison'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83869298416712798)
,p_query_column_id=>6
,p_column_alias=>'NET'
,p_column_display_sequence=>6
,p_column_heading=>'Net'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83869712591712798)
,p_query_column_id=>7
,p_column_alias=>'NUM_LIVREUR'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83870065650712800)
,p_query_column_id=>8
,p_column_alias=>'MONTANT_RECU'
,p_column_display_sequence=>8
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83870465131712800)
,p_query_column_id=>9
,p_column_alias=>'RELIQUAT'
,p_column_display_sequence=>9
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83870900098712801)
,p_query_column_id=>10
,p_column_alias=>'CODE_MODE_REG'
,p_column_display_sequence=>10
,p_column_heading=>'Mode Regl.'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_inline_lov=>'select LIBELLE_MODE,ID_MODERGLT from MODE_RGLT'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83871313747712801)
,p_query_column_id=>11
,p_column_alias=>'REFERENCE_PAYEMENT'
,p_column_display_sequence=>11
,p_column_heading=>'Reference Payement'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83871704795712801)
,p_query_column_id=>12
,p_column_alias=>'NOM'
,p_column_display_sequence=>12
,p_column_heading=>'Ref Paygate'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83872123960712803)
,p_query_column_id=>13
,p_column_alias=>'TXREFERENCE'
,p_column_display_sequence=>13
,p_column_heading=>'Txreference'
,p_derived_column=>'N'
,p_include_in_export=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83872505036712803)
,p_query_column_id=>14
,p_column_alias=>'STATUS'
,p_column_display_sequence=>14
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83872891408712804)
,p_query_column_id=>15
,p_column_alias=>'DATEPAYEMENT'
,p_column_display_sequence=>15
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83873309572712804)
,p_query_column_id=>16
,p_column_alias=>'PAYEMENTMETHODE'
,p_column_display_sequence=>16
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(83873662695712804)
,p_query_column_id=>17
,p_column_alias=>'ETAT'
,p_column_display_sequence=>17
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(83874136442712806)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(210965843055339442)
,p_button_name=>'Valider'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Valider'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83874502696712808)
,p_name=>'P179_NUM_BON'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(210965843055339442)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('N\00B0bon')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct num_bon',
'from details_bon_temp ',
'where  trim(util_modif) = trim(v(''app_user''))'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83874882681712808)
,p_name=>'P179_NUM_LIVREUR'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(210965843055339442)
,p_prompt=>'Livreur'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'LIVREUR'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select trim(nom) || '' '' || trim(prenoms) as d,',
'       num_livreur as r',
'  from livreur',
' order by 1'))
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>3031561932232085882
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83875309397712809)
,p_name=>'P179_PV'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(210965843055339442)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.num_point_vente from bons b,espace_vente e',
'where b.num_espace_vente = e.num_espace_vente',
'and b.num_bon = :P179_NUM_BON'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83875711346712811)
,p_name=>'ok'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(83874136442712806)
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83876259106712811)
,p_event_id=>wwv_flow_imp.id(83875711346712811)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_bon is select num_espace_vente from bons',
'where num_bon = :P179_NUM_BON;',
'',
'r_bon c_bon%rowtype;',
'fin number;',
'begin',
'',
'        open c_bon;',
'        fetch c_bon into r_bon;',
'        if c_bon%found then',
'           if r_bon.num_espace_vente = 1000 then',
'               fin :=fn_pret (:P179_NUM_BON, :P179_NUM_LIVREUR);',
'           else',
'              update bons set livre =''O'' where num_bon = :P179_NUM_BON;',
'           end if;',
'        end if;',
'   ',
'        if nvl(:p179_num_bon,0) != 0 then',
'            update bons set code_etat_bon = 1',
'            where num_bon = :P179_NUM_BON;',
'        end if;',
'',
'       delete bons_temp',
'       where trim(code_utilisateur) = nvl(v(''app_user''), user);',
'       delete details_bon_temp',
'       where trim(util_modif) = nvl(v(''app_user''), user);',
'',
'       /*select 0 into :P138_TOTAL  from dual;',
'       select null into :P138_NUM_BON  from dual;',
'',
'',
'       :P138_NOUVEAU :=3;*/',
'    commit;',
'end;',
''))
,p_attribute_02=>'P179_NUM_BON,P179_NUM_LIVREUR,P179_PV'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83876680452712812)
,p_event_id=>wwv_flow_imp.id(83875711346712811)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Mise &#xE0; jour effectu&#xE9;e avec succ&#xE8;s'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83877219408712812)
,p_event_id=>wwv_flow_imp.id(83875711346712811)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83877584476712814)
,p_name=>'INT'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P179_PV'
,p_condition_element=>'P179_PV'
,p_triggering_condition_type=>'NOT_EQUALS'
,p_triggering_expression=>'1000'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83878159978712814)
,p_event_id=>wwv_flow_imp.id(83877584476712814)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P179_NUM_LIVREUR'
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
