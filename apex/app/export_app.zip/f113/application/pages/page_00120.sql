prompt --application/pages/page_00120
begin
--   Manifest
--     PAGE: 00120
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>120
,p_name=>unistr('D\00E9tails appro pv')
,p_alias=>unistr('D\00C9TAILS-APPRO-PV')
,p_step_title=>unistr('D\00E9tails appro pv')
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'var htmldb_delete_message=''"DELETE_CONFIRM_MSG"'';',
'var htmldb_ch_message=''"OK_TO_GET_NEXT_PREV_PK_VALUE"'';'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(203170790914574662)
,p_name=>'Mouvements'
,p_template=>4072358936313175081
,p_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select MOUVEMENT.NUM_PRODUIT as NUM_PRODUIT,',
'    MOUVEMENT.CODE_TYPE_MOUVEMENT as CODE_TYPE_MOUVEMENT,',
'    MOUVEMENT.NUM_POINT_VENTE as NUM_POINT_VENTE,',
'    MOUVEMENT.QTE as QTE,',
'    MOUVEMENT.DATE_MVT as DATE_MVT,',
'    MOUVEMENT.NUM_APPRO as NUM_APPRO ',
' from MOUVEMENT MOUVEMENT',
' where num_appro = :p120_num_appro'))
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P120_NUM_APPRO'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38065055689464016)
,p_query_column_id=>1
,p_column_alias=>'NUM_PRODUIT'
,p_column_display_sequence=>1
,p_column_heading=>'Num Produit'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38065356620464035)
,p_query_column_id=>2
,p_column_alias=>'CODE_TYPE_MOUVEMENT'
,p_column_display_sequence=>2
,p_column_heading=>'Type Mouvement'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38065707975464035)
,p_query_column_id=>3
,p_column_alias=>'NUM_POINT_VENTE'
,p_column_display_sequence=>3
,p_column_heading=>'Point Vente'
,p_disable_sort_column=>'N'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38066149648464038)
,p_query_column_id=>4
,p_column_alias=>'QTE'
,p_column_display_sequence=>4
,p_column_heading=>'Qte'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38066529088464038)
,p_query_column_id=>5
,p_column_alias=>'DATE_MVT'
,p_column_display_sequence=>5
,p_column_heading=>'Date '
,p_column_format=>'DD/MM/YYYY'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(38066907228464038)
,p_query_column_id=>6
,p_column_alias=>'NUM_APPRO'
,p_column_display_sequence=>6
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(203199886178871478)
,p_plug_name=>'Approvisinnement'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>7
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(203215900364871493)
,p_plug_name=>unistr('D\00E9tails')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>30
,p_plug_grid_column_span=>7
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUM_DETAIL_APPRO,',
'       NUM_APPRO,',
'       NUM_PRODUIT,',
'       QTE,qte_acc',
'  from DETAILS_APPRO',
' where NUM_APPRO =:P120_NUM_APPRO'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P120_NUM_APPRO'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P120_NUM_APPRO'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(166576870499096751)
,p_name=>'QTE_ACC'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QTE_ACC'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('Qt\00E9 accord\00E9e')
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>70
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(203226618520918032)
,p_name=>'NUM_DETAIL_APPRO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NUM_DETAIL_APPRO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(203226796517918033)
,p_name=>'NUM_APPRO'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NUM_APPRO'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>40
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(203226799030918034)
,p_name=>'NUM_PRODUIT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NUM_PRODUIT'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Produit'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(203226989207918035)
,p_name=>'QTE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QTE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_DISPLAY_ONLY'
,p_heading=>unistr('Qt\00E9 demand\00E9e')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>60
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN')).to_clob
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(203226523062918031)
,p_internal_uid=>167883736246997788
,p_is_editable=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_show_nulls_as=>'-'
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>false
,p_toolbar_buttons=>null
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>false
,p_define_chart_view=>false
,p_enable_download=>false
,p_download_formats=>null
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(203237880323956253)
,p_interactive_grid_id=>wwv_flow_imp.id(203226523062918031)
,p_static_id=>'323229'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(203237920493956253)
,p_report_id=>wwv_flow_imp.id(203237880323956253)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(166620863745595152)
,p_view_id=>wwv_flow_imp.id(203237920493956253)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(166576870499096751)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(203238403401956255)
,p_view_id=>wwv_flow_imp.id(203237920493956253)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(203226618520918032)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(203238940763956257)
,p_view_id=>wwv_flow_imp.id(203237920493956253)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(203226796517918033)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(203239435834956260)
,p_view_id=>wwv_flow_imp.id(203237920493956253)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(203226799030918034)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(203239967235956261)
,p_view_id=>wwv_flow_imp.id(203237920493956253)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(203226989207918035)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38070614996464091)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(203199886178871478)
,p_button_name=>'GET_PREVIOUS_NUM_APPRO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Previous'
,p_button_position=>'CHANGE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P120_NUM_APPRO_PREV'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-chevron-left'
,p_button_comment=>'This button is needed for Get Next or Previous Primary Key Value process.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38071008187464096)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(203199886178871478)
,p_button_name=>'GET_NEXT_NUM_APPRO'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>2349107722467437027
,p_button_image_alt=>'Next'
,p_button_position=>'CHANGE'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P120_NUM_APPRO_NEXT'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-chevron-right'
,p_button_comment=>'This button is needed for Get Next or Previous Primary Key Value process.'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38071418825464096)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(203199886178871478)
,p_button_name=>'CANCEL'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Annuler'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:119:&SESSION.::&DEBUG.:::'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(38078275505464143)
,p_branch_action=>'f?p=&APP_ID.:111:&SESSION.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>1
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(38078654968464146)
,p_branch_action=>'f?p=&APP_ID.:120:&SESSION.::&DEBUG.::P120_NUM_APPRO:&P120_NUM_APPRO_NEXT.'
,p_branch_point=>'BEFORE_COMPUTATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(38071008187464096)
,p_branch_sequence=>1
,p_branch_comment=>'This button is needed for Get Next or Previous Primary Key Value process.'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(38079020087464146)
,p_branch_action=>'f?p=&APP_ID.:120:&SESSION.::&DEBUG.::P120_NUM_APPRO:&P120_NUM_APPRO_PREV.'
,p_branch_point=>'BEFORE_COMPUTATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(38070614996464091)
,p_branch_sequence=>1
,p_branch_comment=>'This button is needed for Get Next or Previous Primary Key Value process.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38071796211464097)
,p_name=>'P120_NUM_APPRO'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(203199886178871478)
,p_use_cache_before_default=>'NO'
,p_source=>'NUM_APPRO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38072257828464110)
,p_name=>'P120_LIBELLE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(203199886178871478)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Libelle'
,p_source=>'LIBELLE'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38072538967464110)
,p_name=>'P120_CODE_TYPE_APPRO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(203199886178871478)
,p_use_cache_before_default=>'NO'
,p_source=>'CODE_TYPE_APPRO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38072924792464110)
,p_name=>'P120_NUM_POINT_VENTED'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(203199886178871478)
,p_use_cache_before_default=>'NO'
,p_source=>'NUM_POINT_VENTED'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38073353336464111)
,p_name=>'P120_NUM_POINT_VENTEA'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(203199886178871478)
,p_use_cache_before_default=>'NO'
,p_source=>'NUM_POINT_VENTEA'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38073706332464111)
,p_name=>'P120_DATE_APPRO'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(203199886178871478)
,p_use_cache_before_default=>'NO'
,p_source=>'DATE_APPRO'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38074173412464111)
,p_name=>'P120_CODE_UTILISATEUR'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(203199886178871478)
,p_use_cache_before_default=>'NO'
,p_source=>'CODE_UTILISATEUR'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38074492930464113)
,p_name=>'P120_DATE_CREATION'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(203199886178871478)
,p_use_cache_before_default=>'NO'
,p_source=>'DATE_CREATION'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38074955133464113)
,p_name=>'P120_CODE_ETAT'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(203199886178871478)
,p_use_cache_before_default=>'NO'
,p_source=>'CODE_ETAT'
,p_source_type=>'DB_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38075333168464114)
,p_name=>'P120_NUM_APPRO_NEXT'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(203199886178871478)
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_item_comment=>'This item is needed for Get Next or Previous Primary Key Value process.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38075700263464116)
,p_name=>'P120_NUM_APPRO_PREV'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(203199886178871478)
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
,p_item_comment=>'This item is needed for Get Next or Previous Primary Key Value process.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38076090090464116)
,p_name=>'P120_NUM_APPRO_COUNT'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(203199886178871478)
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_tag_attributes=>'class="fielddata"'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'N')).to_clob
,p_item_comment=>'This item is needed for Get Next or Previous Primary Key Value process.'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38076505288464130)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_FETCH'
,p_process_name=>'Fetch Row from APPRO'
,p_attribute_02=>'APPRO'
,p_attribute_03=>'P120_NUM_APPRO'
,p_attribute_04=>'NUM_APPRO'
,p_internal_uid=>38076505288464130
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38077726638464139)
,p_process_sequence=>20
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_FORM_PAGINATION'
,p_process_name=>'Get Next or Previous Primary Key Value'
,p_attribute_02=>'APPRO'
,p_attribute_03=>'P120_NUM_APPRO'
,p_attribute_04=>'NUM_APPRO'
,p_attribute_07=>'NUM_APPRO'
,p_attribute_09=>'P120_NUM_APPRO_NEXT'
,p_attribute_10=>'P120_NUM_APPRO_PREV'
,p_attribute_13=>'P120_NUM_APPRO_COUNT'
,p_internal_uid=>38077726638464139
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38076888468464132)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_FORM_PROCESS'
,p_process_name=>'Process Row of APPRO'
,p_attribute_02=>'APPRO'
,p_attribute_03=>'P120_NUM_APPRO'
,p_attribute_04=>'NUM_APPRO'
,p_attribute_11=>'I:U:D'
,p_attribute_12=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'Action Processed.'
,p_internal_uid=>38076888468464132
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(38077371904464138)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'reset page'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>38077371904464138
);
wwv_flow_imp.component_end;
end;
/
