prompt --application/pages/page_00047
begin
--   Manifest
--     PAGE: 00047
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>47
,p_name=>unistr('Op\00E9rations de caisse')
,p_alias=>unistr('OP\00C9RATIONS-DE-CAISSE')
,p_step_title=>unistr('Op\00E9rations de caisse')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(267583739487046578)
,p_plug_name=>unistr('P\00E9riode')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>3
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(267625785960427232)
,p_plug_name=>'Operations'
,p_region_name=>'emp'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUM_OP_CAISSE ID,NUM_OP_CAISSE,DATEHEURE_OP,CODE_TYPE_OP_CAISSE ,REFERENCE,SENS,MONTANT_OP,',
'decode(sens,''D'',montant_op,0) debit,decode(sens,''C'',montant_op,0) credit,',
'(select CODE_MODE_REG from recu where num_bon = o.NUM_REGL_CLT) mode_reg,code_utilisateur',
'from operation_caisse o',
'where FN_DATE_NUM(DATEHEURE_OP) between  FN_DATE_NUM(:p47_date_debut)',
' and  FN_DATE_NUM(:p47_date_fin)',
'and num_caisse = :p47_caisse',
'order by NUM_OP_CAISSE;'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P47_DATE_DEBUT,P47_DATE_FIN,P47_CAISSE,P47_POINT_VENTE'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(237135004751560287)
,p_max_row_count=>'1000000'
,p_allow_save_rpt_public=>'Y'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'BDHE'
,p_internal_uid=>181962444295887318
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(84951293626467656)
,p_db_column_name=>'ID'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Id'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(84951664835467656)
,p_db_column_name=>'NUM_OP_CAISSE'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Num Op Caisse'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(84952108789467656)
,p_db_column_name=>'DATEHEURE_OP'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Date'
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(84952537263467658)
,p_db_column_name=>'CODE_TYPE_OP_CAISSE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Type'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(83778690093549639)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(84952935484467658)
,p_db_column_name=>'REFERENCE'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Reference'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(84953350547467658)
,p_db_column_name=>'SENS'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Sens'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(84953703994467658)
,p_db_column_name=>'MONTANT_OP'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Montant Op'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(84954065546467659)
,p_db_column_name=>'DEBIT'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Debit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G999'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(84954499291467659)
,p_db_column_name=>'CREDIT'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Credit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G999'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(84950478170467648)
,p_db_column_name=>'MODE_REG'
,p_display_order=>100
,p_column_identifier=>'K'
,p_column_label=>unistr('Mode r\00E8glement')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(83601214007751033)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(84950922450467656)
,p_db_column_name=>'CODE_UTILISATEUR'
,p_display_order=>110
,p_column_identifier=>'J'
,p_column_label=>'Utilisateur'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(237214424685667236)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'344654'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:NUM_OP_CAISSE:DATEHEURE_OP:CODE_TYPE_OP_CAISSE:REFERENCE:SENS:MONTANT_OP:DEBIT:CREDIT:CODE_UTILISATEUR:MODE_REG'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(84947407457467625)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(267583739487046578)
,p_button_name=>'Afficher_soldes'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Afficher Soldes'
,p_button_position=>'BELOW_BOX'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(84955140652467669)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(267625785960427232)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Cr\00E9er')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:49:&SESSION.::&DEBUG.:49:P49_NUM_CAISSE:&P47_CAISSE.'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(84947795908467631)
,p_name=>'P47_ATTRIB'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(267583739487046578)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select code_statut_personnel  from personnel',
'    where trim(profil_app) =v(''app_user'');'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(84948198072467633)
,p_name=>'P47_DATEJ'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(267583739487046578)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.DATEHEURE_DEBUT_VAC ',
'from vacation v,affectation a,personnel p',
'where v.num_espace_vente = a.num_espace_vente',
'and a.matricule = p.matricule',
'and cloture = ''N''',
'and trim(p.profil_app) = trim(nvl(v(''app_user''), user));'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(84948650634467634)
,p_name=>'P47_POINT_VENTE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(267583739487046578)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Point Vente'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'POINT_VENTE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nom_point_vente as d,',
'       num_point_vente as r',
'  from point_vente where actif=''O''',
'order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(84949047902467636)
,p_name=>'P47_DATE_DEBUT'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(267583739487046578)
,p_item_default=>'select sysdate from dual;'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>unistr('Date D\00E9but')
,p_format_mask=>'DD/MM/YYYY'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(84949411787467636)
,p_name=>'P47_DATE_FIN'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(267583739487046578)
,p_item_default=>'select sysdate from dual;'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Date Fin'
,p_format_mask=>'DD/MM/YYYY'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(84949830383467636)
,p_name=>'P47_REFRESH'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(267583739487046578)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(84955525082467669)
,p_name=>'P47_CAISSE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(267625785960427232)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(84955903334467670)
,p_name=>'P47_SOLDE_ANT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(267625785960427232)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Solde ant\00E9rieur')
,p_format_mask=>'999G999G999G999G990D00'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(84956353484467670)
,p_name=>'P47_TOT_DEBIT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(267625785960427232)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Total d\00E9bit p\00E9riode')
,p_format_mask=>'999G999G999G999G999G999G990'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  sum(MONTANT_OP) as tot ',
'from operation_caisse',
'where DATEHEURE_OP between :p47_date_debut and :p47_date_fin',
'and num_caisse = :P47_CAISSE',
'and sens = ''D'';'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(84956731386467670)
,p_name=>'P47_TOT_CREDIT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(267625785960427232)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('Total cr\00E9dit p\00E9riode')
,p_format_mask=>'999G999G999G999G999G999G990'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  sum(MONTANT_OP) as tot ',
'from operation_caisse',
'where DATEHEURE_OP between :p47_date_debut and :p47_date_fin',
'and num_caisse = :P47_CAISSE',
'and sens = ''C'';'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(84957103601467672)
,p_name=>'P47_SOLDE_FIN'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(267625785960427232)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Solde Fin'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(84957531158467690)
,p_name=>'pv'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P47_POINT_VENTE'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(84958038238467692)
,p_event_id=>wwv_flow_imp.id(84957531158467690)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_caisse is select num_caisse from caisse ',
'where num_point_vente = :P47_POINT_VENTE;',
'r_caisse c_caisse%rowtype;',
'',
'begin',
'  :P47_CAISSE :=null;',
'   open c_caisse;',
'   fetch c_caisse into r_caisse;',
'    if c_caisse%found then',
'       :P47_CAISSE := r_caisse.num_caisse;',
'    end if;',
'    close c_caisse;',
'   /* :P47_CAISSE :=2;',
'    ',
'    select num_caisse into :P47_CAISSE from caisse ',
'where num_point_vente = :P47_POINT_VENTE*/',
'',
'end;'))
,p_attribute_02=>'P47_POINT_VENTE,P47_CAISSE'
,p_attribute_03=>'P47_CAISSE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(84958477347467694)
,p_event_id=>wwv_flow_imp.id(84957531158467690)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(267625785960427232)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(84958909484467694)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(267625785960427232)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(84959368222467694)
,p_event_id=>wwv_flow_imp.id(84958909484467694)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(267625785960427232)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(84959773803467694)
,p_name=>'AffOp'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P47_DATE_DEBUT,P47_DATE_FIN,P47_POINT_VENTE'
,p_condition_element=>'P47_POINT_VENTE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(84960335228467695)
,p_event_id=>wwv_flow_imp.id(84959773803467694)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(267625785960427232)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(84960718793467695)
,p_name=>'ref'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P47_REFRESH'
,p_condition_element=>'P47_REFRESH'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(84961231022467695)
,p_event_id=>wwv_flow_imp.id(84960718793467695)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(267625785960427232)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(84961651359467697)
,p_name=>'Affsoldes'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(84947407457467625)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(84962136091467697)
,p_event_id=>wwv_flow_imp.id(84961651359467697)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :p47_attrib not in (1,3) then',
'  :p47_date_debut := :p47_datej;',
'  :p47_date_fin := :p47_datej;',
'end if;',
'select  nvl(sum(MONTANT_OP),0) into :p47_tot_debit ',
'from operation_caisse',
'where FN_DATE_NUM(DATEHEURE_OP) between FN_DATE_NUM(:p47_date_debut) and FN_DATE_NUM(:p47_date_fin)',
'and num_caisse = :P47_CAISSE',
'and sens = ''D'';',
'',
'select  nvl(sum(MONTANT_OP),0) into :p47_tot_credit',
'from operation_caisse',
'where FN_DATE_NUM(DATEHEURE_OP) between FN_DATE_NUM(:p47_date_debut) and FN_DATE_NUM(:p47_date_fin)',
'and num_caisse = :P47_CAISSE',
'and sens = ''C'';',
'',
'if :P47_ATTRIB in (1,3) then',
'    select  nvl(sum(DECODE(SENS,''C'',MONTANT_OP,0))-sum(DECODE(SENS,''D'',MONTANT_OP,0)),0) into :p47_solde_ant',
'    from operation_caisse',
'    where FN_DATE_NUM(DATEHEURE_OP)< FN_DATE_NUM(:p47_date_debut)',
'    and num_caisse = :P47_CAISSE;',
'    :p47_solde_fin := :p47_solde_ant + (:p47_tot_credit-:p47_tot_debit );',
'else',
'    :p47_solde_ant :=0;',
'     :p47_solde_fin:=0;',
'    ',
'end if;',
''))
,p_attribute_02=>'P47_TOT_DEBIT,P47_TOT_CREDIT,P47_SOLDE_ANT,P47_SOLDE_FIN,P47_ATTRIB'
,p_attribute_03=>'P47_TOT_DEBIT,P47_TOT_CREDIT,P47_SOLDE_ANT,P47_SOLDE_FIN'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(84962540766467697)
,p_name=>'Attrib'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P47_ATTRIB'
,p_condition_element=>'P47_ATTRIB'
,p_triggering_condition_type=>'IN_LIST'
,p_triggering_expression=>'2,4,5,6,7,8'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(84963012473467698)
,p_event_id=>wwv_flow_imp.id(84962540766467697)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_pv is select num_point_vente from personnel p,affectation f',
'where p.matricule = f.matricule',
'and trim(profil_app)= v(''app_user'');',
'',
'r_pv c_pv%rowtype;',
'',
'begin',
' ',
'     open c_pv;',
'     fetch c_pv into r_pv;',
'     if c_pv%found then',
'         :P47_POINT_VENTE:= r_pv.num_point_vente;',
'     end if;',
'     close c_pv;',
'',
'  end;'))
,p_attribute_02=>'P47_ATTRIB,P47_POINT_VENTE'
,p_attribute_03=>'P47_POINT_VENTE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(84963464528467698)
,p_event_id=>wwv_flow_imp.id(84962540766467697)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P47_POINT_VENTE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(84964003461467698)
,p_event_id=>wwv_flow_imp.id(84962540766467697)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P47_POINT_VENTE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(84964493044467698)
,p_event_id=>wwv_flow_imp.id(84962540766467697)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P47_DATE_DEBUT,P47_DATE_FIN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(84965012860467700)
,p_event_id=>wwv_flow_imp.id(84962540766467697)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(84947407457467625)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(84965410923467700)
,p_name=>'Attrib_1'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P47_ATTRIB'
,p_condition_element=>'P47_ATTRIB'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(84965908882467701)
,p_event_id=>wwv_flow_imp.id(84965410923467700)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_pv is select num_point_vente from personnel p,affectation f',
'where p.matricule = f.matricule',
'and trim(profil_app)= v(''app_user'');',
'',
'r_pv c_pv%rowtype;',
'',
'begin',
' ',
'     open c_pv;',
'     fetch c_pv into r_pv;',
'     if c_pv%found then',
'         :P47_POINT_VENTE:= r_pv.num_point_vente;',
'     end if;',
'     close c_pv;',
'',
'  end;'))
,p_attribute_02=>'P47_ATTRIB,P47_POINT_VENTE'
,p_attribute_03=>'P47_POINT_VENTE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(84966377284467701)
,p_event_id=>wwv_flow_imp.id(84965410923467700)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P47_POINT_VENTE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(84966900563467701)
,p_event_id=>wwv_flow_imp.id(84965410923467700)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P47_POINT_VENTE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(84967448344467703)
,p_event_id=>wwv_flow_imp.id(84965410923467700)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(84947407457467625)
);
wwv_flow_imp.component_end;
end;
/
