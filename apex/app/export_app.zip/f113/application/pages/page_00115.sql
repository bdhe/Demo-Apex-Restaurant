prompt --application/pages/page_00115
begin
--   Manifest
--     PAGE: 00115
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>115
,p_name=>'Livraison fournisseur'
,p_alias=>'LIVRAISON-FOURNISSEUR'
,p_step_title=>'Livraison fournisseur'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(281321413184224943)
,p_plug_name=>unistr('Param\00E8tres')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>5
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(281324352205224972)
,p_plug_name=>unistr('D\00E9tails')
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>40
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>7
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'NUM_DETAIL_CMDE,   ',
'NUM_CMDE,        ',
'NUM_PRODUIT,     ',
'QTE_CMDE,        ',
'PU_CMD_FRN ,    ',
'TYPE_PRODUIT ,            ',
'UNITE_MESURE ,            ',
'QTE_ACC,                 ',
'TOTAL ',
'from detail_cmde',
'where num_cmde = :P115_NUMERO_COMMANDE',
'and type_produit = nvl(:P115_TYPE_PRODUIT,type_produit)'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P115_TYPE_PRODUIT,P115_NUMERO_COMMANDE'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(154222015955320968)
,p_name=>'NUM_DETAIL_CMDE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NUM_DETAIL_CMDE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>100
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(154222110490320969)
,p_name=>'NUM_CMDE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NUM_CMDE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>110
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(154222229203320970)
,p_name=>'QTE_CMDE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QTE_CMDE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('Qte command\00E9')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>120
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
,p_is_required=>true
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(154222377621320971)
,p_name=>'PU_CMD_FRN'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'PU_CMD_FRN'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Prix'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>130
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
,p_is_required=>true
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(154222464525320972)
,p_name=>'TYPE_PRODUIT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TYPE_PRODUIT'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>140
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(154222575888320973)
,p_name=>'QTE_ACC'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QTE_ACC'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>unistr('Qte livr\00E9e')
,p_heading_alignment=>'CENTER'
,p_display_sequence=>150
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(154222658636320974)
,p_name=>'TOTAL'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'TOTAL'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Total'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>160
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
,p_format_mask=>'999G999G999G999G999G999G990'
,p_is_required=>false
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(203791585424810646)
,p_name=>'UNITE_MESURE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UNITE_MESURE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Unite Mesure'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>70
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>10
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(282483326747134026)
,p_name=>'NUM_PRODUIT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NUM_PRODUIT'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading=>'Produit'
,p_heading_alignment=>'CENTER'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_is_required=>true
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(81557789633430934)
,p_lov_display_extra=>true
,p_lov_display_null=>true
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>false
,p_enable_hide=>false
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(282482962289134023)
,p_internal_uid=>227310401833461054
,p_is_editable=>true
,p_edit_operations=>'u:d'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_show_nulls_as=>'-'
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>false
,p_show_toolbar=>true
,p_toolbar_buttons=>'SAVE'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>false
,p_define_chart_view=>false
,p_enable_download=>false
,p_download_formats=>null
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
' function(config) {',
'        let $             = apex.jQuery,',
'            toolbarData   = $.apex.interactiveGrid.copyDefaultToolbar(),',
'            addrowAction  = toolbarData.toolbarFind("selection-add-row"),',
'            saveAction    = toolbarData.toolbarFind("save"),',
'            editAction    = toolbarData.toolbarFind("edit");',
'         ',
'        addrowAction.icon = "icon-ig-add-row";',
'        addrowAction.iconBeforeLabel = true;',
'        addrowAction.hot = true;',
'        saveAction.label = "Enregistrer";',
'        saveAction.iconBeforeLabel = true;',
'        saveAction.icon ="icon-ig-save-as";',
'        saveAction.hot = true;',
'        editAction.label = "Modifier";',
'        config.toolbarData = toolbarData;',
'        return config;',
'    }'))
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(282488573100146518)
,p_interactive_grid_id=>wwv_flow_imp.id(282482962289134023)
,p_static_id=>'252221'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(282488698877146520)
,p_report_id=>wwv_flow_imp.id(282488573100146518)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(154313487371367344)
,p_view_id=>wwv_flow_imp.id(282488698877146520)
,p_display_seq=>6
,p_column_id=>wwv_flow_imp.id(154222015955320968)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(154313975910367348)
,p_view_id=>wwv_flow_imp.id(282488698877146520)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(154222110490320969)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(154314430607367350)
,p_view_id=>wwv_flow_imp.id(282488698877146520)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(154222229203320970)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(154314927487367353)
,p_view_id=>wwv_flow_imp.id(282488698877146520)
,p_display_seq=>9
,p_column_id=>wwv_flow_imp.id(154222377621320971)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(154315449178367355)
,p_view_id=>wwv_flow_imp.id(282488698877146520)
,p_display_seq=>10
,p_column_id=>wwv_flow_imp.id(154222464525320972)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(154315963012367358)
,p_view_id=>wwv_flow_imp.id(282488698877146520)
,p_display_seq=>11
,p_column_id=>wwv_flow_imp.id(154222575888320973)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(154316430738367359)
,p_view_id=>wwv_flow_imp.id(282488698877146520)
,p_display_seq=>12
,p_column_id=>wwv_flow_imp.id(154222658636320974)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(204076675838563761)
,p_view_id=>wwv_flow_imp.id(282488698877146520)
,p_display_seq=>5
,p_column_id=>wwv_flow_imp.id(203791585424810646)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(282490241198146526)
,p_view_id=>wwv_flow_imp.id(282488698877146520)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(282483326747134026)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85283001685679211)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(281321413184224943)
,p_button_name=>'Effacer'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Effacer'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85283453391679212)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(281321413184224943)
,p_button_name=>'Valider'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Valider Livraison'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85283781874679212)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(281321413184224943)
,p_button_name=>'Quitter'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Quitter'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85284257125679212)
,p_name=>'P115_NOM_PV'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(281321413184224943)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Point de vente'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pv.NOM_POINT_VENTE',
'from affectation a,personnel p,espace_vente e,point_vente pv',
'where a.matricule = p.matricule',
'and a.num_espace_vente = e.num_espace_vente',
'and e.num_point_vente = pv.num_point_vente',
'and trim(profil_app) = nvl(v(''app_user''), user);'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85284562031679214)
,p_name=>'P115_NUMERO_COMMANDE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(281321413184224943)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('S\00E9lectionner le numero de commande \00E0 livrer')
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select libelle,num_cmde from commande_frns',
'where code_etat = 1'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'DIALOG',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85284991729679214)
,p_name=>'P115_NUM_PV'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(281321413184224943)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pv.num_point_vente',
'from affectation a,personnel p,espace_vente e,point_vente pv',
'where a.matricule = p.matricule',
'and a.num_espace_vente = e.num_espace_vente',
'and e.num_point_vente = pv.num_point_vente',
'and trim(profil_app) = nvl(v(''app_user''), user);'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85285426676679215)
,p_name=>'P115_FOURNISSEUR'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(281321413184224943)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85285789250679215)
,p_name=>'P115_NOM_FOURN'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(281321413184224943)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Fournisseur'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nom_fourn',
'from fournisseur',
'where  code_fourn = :p115_fournisseur;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85290850598679231)
,p_name=>'P115_TYPE_PRODUIT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(281324352205224972)
,p_prompt=>'Type produit'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TYPE_PRODUIT_STOCK'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select libelle_type_produit as d,',
'       code_type_produit as r',
'  from type_produit',
'  where code_type_produit in (select code_type_produit from produits where STOCKABLE =''O'')',
' order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85291579585679233)
,p_name=>'Nouveau'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P115_NUMERO_APPRO'
,p_condition_element=>'P115_NUMERO_APPRO'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85292032411679233)
,p_name=>'type'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P115_TYPE_PRODUIT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85292480444679234)
,p_event_id=>wwv_flow_imp.id(85292032411679233)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(281324352205224972)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85292937748679236)
,p_name=>'refreshrd'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P115_TYPE_PRODUIT_1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85293287926679236)
,p_name=>'modif'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P115_NUM_APPRO_MODIF'
,p_condition_element=>'P115_NUMERO_APPRO'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85293830313679237)
,p_event_id=>wwv_flow_imp.id(85293287926679236)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>' :P115_NUMERO_APPRO := :P115_NUM_APPRO_MODIF;'
,p_attribute_02=>'P115_NUMERO_APPRO,P115_NUM_APPRO_MODIF'
,p_attribute_03=>'P115_NUMERO_APPRO'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85294338240679237)
,p_event_id=>wwv_flow_imp.id(85293287926679236)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Veuillez la livraison courant avant !'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85294843756679239)
,p_event_id=>wwv_flow_imp.id(85293287926679236)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(281324352205224972)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85295231297679240)
,p_name=>'effacer'
,p_event_sequence=>70
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(85283001685679211)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85295687602679240)
,p_event_id=>wwv_flow_imp.id(85295231297679240)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P115_NUMERO_APPRO'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85296170184679242)
,p_event_id=>wwv_flow_imp.id(85295231297679240)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P115_FOURNISSEUR'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85296669910679242)
,p_event_id=>wwv_flow_imp.id(85295231297679240)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P115_NUMERO_COMMANDE'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85297162142679244)
,p_event_id=>wwv_flow_imp.id(85295231297679240)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(281324352205224972)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85297638140679244)
,p_name=>'typeL'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P115_TYPE_LIVRAISON'
,p_condition_element=>'P115_TYPE_LIVRAISON'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85298125633679245)
,p_event_id=>wwv_flow_imp.id(85297638140679244)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P115_NUMERO_COMMANDE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85298561330679247)
,p_event_id=>wwv_flow_imp.id(85297638140679244)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P115_FOURNISSEUR,P115_TYPE_PRODUIT'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85299140564679247)
,p_event_id=>wwv_flow_imp.id(85297638140679244)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P115_FOURNISSEUR,P115_TYPE_PRODUIT'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85299573710679248)
,p_event_id=>wwv_flow_imp.id(85297638140679244)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P115_NUMERO_COMMANDE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85300015504679248)
,p_name=>'vliv'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(85283453391679212)
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85300550125679250)
,p_event_id=>wwv_flow_imp.id(85300015504679248)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Etes-vous s&#xFB;r de vouloir valider cette livraison?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85300995161679251)
,p_event_id=>wwv_flow_imp.id(85300015504679248)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' cursor c_cmde is select * from  detail_cmde where num_cmde = :P115_NUMERO_COMMANDE;   ',
' r_cmde c_cmde%rowtype;',
'begin',
'       open c_cmde;',
'       loop',
'           fetch c_cmde into r_cmde;',
'           exit when c_cmde%notfound;',
'           insert into mouvement values  (MOUVEMENT_NUM_MVT_SEQ.nextval/*NUM_MVT*/,r_cmde.NUM_PRODUIT,4/*CODE_TYPE_MOUVEMENT*/,null/*NUM_BON*/,:P115_NUM_PV/*NUM_POINT_VENTE*/, null/*NUM_LIVR*/, null/*NUM_LIVR_CLT*/,:P115_NUMERO_COMMANDE/*NUM_CMDE*/,:'
||'P115_FOURNISSEUR/*CODE_FOURN*/,nvl(r_cmde.QTE_acc,r_cmde.QTE_CMDE)/*QTE*/,sysdate/*DATE_MVT*/,0/*PU_MVT*/,''1''/*ETAT*/,nvl(v(''app_user''), user)/*CODE_UTILISATEUR*/,sysdate/*DATE_CREATION*/ ,null/*NUM_CARNET*/,null/*MATRICULE*/,null/*NUM_TICKET*/,2/*CO'
||'DE_NATURE_MVT*/,null);',
'                  ',
'       end loop;',
'       close c_cmde;',
'       update commande_frns set code_etat = 2   where num_cmde = :P115_NUMERO_COMMANDE;',
'    commit;',
' end;'))
,p_attribute_02=>'P115_NUMERO_COMMANDE,P115_NUM_PV,P115_FOURNISSEUR'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85301470159679253)
,p_event_id=>wwv_flow_imp.id(85300015504679248)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Validation effectu&#xE9;e avec succ&#xE8;s'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85301977338679253)
,p_event_id=>wwv_flow_imp.id(85300015504679248)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P115_NUMERO_APPRO,P115_NUM_APPRO_MODIF'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85302461794679254)
,p_event_id=>wwv_flow_imp.id(85300015504679248)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P115_NUMERO_COMMANDE'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85302984356679254)
,p_event_id=>wwv_flow_imp.id(85300015504679248)
,p_event_result=>'TRUE'
,p_action_sequence=>70
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(281324352205224972)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85303407129679256)
,p_name=>'nomf'
,p_event_sequence=>110
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P115_FOURNISSEUR'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85303882631679256)
,p_event_id=>wwv_flow_imp.id(85303407129679256)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P115_FOURNISSEUR is not null then',
'        select nom_fourn into :P115_NOM_FOURN',
'        from fournisseur',
'        where  code_fourn = :P115_FOURNISSEUR;',
'else',
'        :P115_NOM_FOURN:=null;',
'end if;'))
,p_attribute_02=>'P115_FOURNISSEUR,P115_NOM_FOURN'
,p_attribute_03=>'P115_NOM_FOURN'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85304341292679258)
,p_name=>'frns'
,p_event_sequence=>120
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P115_NUMERO_COMMANDE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85304845266679258)
,p_event_id=>wwv_flow_imp.id(85304341292679258)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if  :P115_NUMERO_COMMANDE is not null then',
'    select code_fourn into :P115_FOURNISSEUR from commande_frns',
'    where num_cmde = :P115_NUMERO_COMMANDE;',
'end if;'))
,p_attribute_02=>'P115_NUMERO_COMMANDE,P115_FOURNISSEUR'
,p_attribute_03=>'P115_FOURNISSEUR'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85305301757679259)
,p_event_id=>wwv_flow_imp.id(85304341292679258)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(281324352205224972)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(85291169634679231)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(281324352205224972)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>unistr('D\00E9tails - Enregistrer les donn\00E9es de grille interactive')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>85291169634679231
);
wwv_flow_imp.component_end;
end;
/
