prompt --application/pages/page_00136
begin
--   Manifest
--     PAGE: 00136
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>136
,p_name=>'EditionUsine'
,p_alias=>'EDITIONUSINE'
,p_step_title=>'EditionUsine'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(295522562035496006)
,p_plug_name=>'Demande d''approvisionnement & production'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>6
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85674179676050509)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(295522562035496006)
,p_button_name=>'Editer_appro'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Editer'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:134:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85674554940050522)
,p_name=>'P136_LIB_APPRO'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(295522562035496006)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Lib Appro'
,p_source=>unistr('Edition demande d''approvisionnement ou Production (renseigner le num\00E9ro)')
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85674917252050526)
,p_name=>'P136_NUM_APPRO'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(295522562035496006)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('N\00B0 Facture')
,p_display_as=>'NATIVE_POPUP_LOV'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select libelle,num_appro',
'from appro',
'where code_type_appro = nvl(:P132_TYPE_APPRO,code_type_appro)',
'and num_point_ventea = (select num_point_vente from affectation a,personnel p',
'where a.matricule = p.matricule and trim(profil_app) = trim(v(''app_user'')))',
'order by num_appro desc'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'DIALOG',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85675693679050576)
,p_name=>'param'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P136_DATE_DEBUT,P136_DATE_FIN'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85676237642050578)
,p_event_id=>wwv_flow_imp.id(85675693679050576)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :p136_attrib != 3 then',
'   :p136_date_debut := sysdate;',
'   :p136_date_fin := sysdate;',
'end if;',
'update parametres_etats set valeur_date = :p136_date_debut',
'where trim(nom_parametre) = ''date_debut''',
'and code_etat = 2;',
'',
'update parametres_etats set valeur_date = :p136_date_fin',
'where trim(nom_parametre) = ''date_fin''',
'and code_etat = 2;',
'',
'commit;'))
,p_attribute_02=>'P136_DATE_DEBUT,P136_DATE_FIN,P136_ATTRIB'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85676635105050579)
,p_name=>'attrib'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P136_ATTRIB'
,p_condition_element=>'P136_ATTRIB'
,p_triggering_condition_type=>'NOT_EQUALS'
,p_triggering_expression=>'3'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85677149594050579)
,p_event_id=>wwv_flow_imp.id(85676635105050579)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P136_DATE_DEBUT,P136_DATE_FIN'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85677626361050581)
,p_event_id=>wwv_flow_imp.id(85676635105050579)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :p136_attrib != 3 then',
'   :p136_date_debut := sysdate;',
'   :p136_date_fin := sysdate;',
'end if;',
'update parametres_etats set valeur_date = :p136_date_debut',
'where trim(nom_parametre) = ''date_debut''',
'and code_etat = 2;',
'',
'update parametres_etats set valeur_date = :p136_date_fin',
'where trim(nom_parametre) = ''date_fin''',
'and code_etat = 2;',
'',
'commit;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85677965908050581)
,p_name=>'PARAMFACT'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P136_NUM_APPRO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85678496976050583)
,p_event_id=>wwv_flow_imp.id(85677965908050581)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update parametres_etats set valeur_num = :P136_NUM_APPRO',
'where trim(nom_parametre) = ''num_appro''',
'and code_etat = 6;',
'',
'commit;'))
,p_attribute_02=>'P136_NUM_APPRO'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85678913620050583)
,p_name=>'num_invt'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P136_NUM_INVENT'
,p_condition_element=>'P136_NUM_INVENT'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85679450898050583)
,p_event_id=>wwv_flow_imp.id(85678913620050583)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update parametres_etats set valeur_num = :P136_NUM_INVENT',
'where  code_etat = 4;',
'commit;'))
,p_attribute_02=>'P136_NUM_INVENT'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85679853616050584)
,p_name=>'paramcommande'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P136_NUM_CMDE'
,p_condition_element=>'P136_NUM_CMDE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85680307476050584)
,p_event_id=>wwv_flow_imp.id(85679853616050584)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update parametres_etats set valeur_num = :P136_NUM_CMDE',
'where trim(nom_parametre) = ''num_cmde''',
'and code_etat = 5;',
'',
'commit;'))
,p_attribute_02=>'P136_NUM_CMDE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(85675340202050573)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'attrib'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'code_stat number;',
'',
'begin',
'    select code_statut_personnel into code_stat  from personnel',
'    where trim(profil_app) =v(''app_user'');',
'    if code_stat != 3 then',
'         update parametres_etats set valeur_date = sysdate',
'        where trim(nom_parametre) = ''date_debut''',
'        and code_etat = 2;',
'',
'        update parametres_etats set valeur_date = sysdate',
'        where trim(nom_parametre) = ''date_fin''',
'        and code_etat = 2;',
'   end if;',
'',
'commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>85675340202050573
);
wwv_flow_imp.component_end;
end;
/
