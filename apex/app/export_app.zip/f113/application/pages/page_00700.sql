prompt --application/pages/page_00700
begin
--   Manifest
--     PAGE: 00700
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>700
,p_name=>'Liste de type produit'
,p_alias=>'LISTE-DE-TYPE-PRODUIT'
,p_step_title=>'Liste de type produit'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(82159988271782500)
,p_plug_name=>'Etat 1'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_plug_grid_column_span=>6
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "CODE_TYPE_PRODUIT","LIBELLE_TYPE_PRODUIT","ACTIF","CODE_FAMILLE","CODE_UTILISATEUR","DATE_CREATION","IMAGE","MIMETYPE","FILENAME","IMAGE_LAST_UPDATE"from "TYPE_PRODUIT"',
'where actif=''O'''))
,p_plug_source_type=>'NATIVE_JQM_LIST_VIEW'
,p_plug_query_num_rows=>15
,p_plug_header=>'<div style="height:800px;overflow:scroll;scrollbar-width: none;"> '
,p_plug_footer=>'</div>'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'counter_column', 'CODE_TYPE_PRODUIT',
  'image_blob_column', 'IMAGE',
  'image_primary_key_column_1', 'CODE_TYPE_PRODUIT',
  'image_type', 'IMAGE_BLOB',
  'link_target', 'f?p=&APP_ID.:701:&SESSION.::&DEBUG.:RP:P701_CODE_TYPE_PRODUIT:\&CODE_TYPE_PRODUIT.\',
  'list_divider_column', 'ACTIF',
  'list_view_features', 'IMAGE:DIVIDER',
  'supplemental_info_column', 'CODE_FAMILLE',
  'text_column', 'LIBELLE_TYPE_PRODUIT')).to_clob
);
wwv_flow_imp.component_end;
end;
/
