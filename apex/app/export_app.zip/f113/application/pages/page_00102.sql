prompt --application/pages/page_00102
begin
--   Manifest
--     PAGE: 00102
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>102
,p_name=>'Facture client'
,p_alias=>'FACTURE-CLIENT'
,p_step_title=>'Facture client'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(241810388230436602)
,p_plug_name=>'Facture'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>5
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(241810687003436605)
,p_name=>'Selection'
,p_template=>2100526641005906379
,p_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUM_BON ID, NUM_BON,',
'       NUM_TABLE,',
'       NUM_ESPACE_VENTE,',
'       DATE_BON,',
'       MONTANT_BON',
'       from BONS',
' where num_bon in (select num_bon from bons_facture where num_session = v(''app_session''))',
' order by NUM_BON'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>10000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85149885016587209)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>6
,p_column_heading=>'Supprimer'
,p_column_link=>'#'
,p_column_linktext=>' <span class="t-Icon fa fa-trash-o" aria-hidden="true"></span>'
,p_column_link_attr=>'id=''#ID#'' class="delete t-Button t-Button--danger t-Button--simple t-Button--small" title="Supprimer le bon"'
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85150285819587209)
,p_query_column_id=>2
,p_column_alias=>'NUM_BON'
,p_column_display_sequence=>1
,p_column_heading=>unistr('N\00B0Bon')
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85150736333587211)
,p_query_column_id=>3
,p_column_alias=>'NUM_TABLE'
,p_column_display_sequence=>2
,p_column_heading=>'Table'
,p_column_alignment=>'RIGHT'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85151087042587211)
,p_query_column_id=>4
,p_column_alias=>'NUM_ESPACE_VENTE'
,p_column_display_sequence=>3
,p_column_heading=>'Espace Vente'
,p_display_as=>'TEXT_FROM_LOV_ESC'
,p_named_lov=>wwv_flow_imp.id(81019840160213400)
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85151531197587212)
,p_query_column_id=>5
,p_column_alias=>'DATE_BON'
,p_column_display_sequence=>4
,p_column_heading=>'Date '
,p_column_format=>'DD/MM/YYYY'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(85151896623587214)
,p_query_column_id=>6
,p_column_alias=>'MONTANT_BON'
,p_column_display_sequence=>5
,p_column_heading=>'Montant '
,p_column_format=>'999G999G999G999G999G999G990'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(241812379164436622)
,p_plug_name=>'Bons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUM_CLT,NUM_BON ID, NUM_BON,',
'       NUM_TABLE,',
'       NUM_ESPACE_VENTE,',
'       DATE_BON,',
'       MONTANT_BON',
'       from BONS ',
' where num_bon not in (select num_bon_fact from detail_facture)',
' and code_etat_bon = nvl(:p102_etat_bon,code_etat_bon)',
' and num_clt = nvl(:p102_clt,num_clt)',
' AND num_espace_vente in (select num_espace_vente from espace_vente where num_point_vente = :P102_POINT_VENTE)',
' and num_facture is null',
' order by NUM_BON'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P102_ETAT_BON,P102_CLT,P102_POINT_VENTE'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>210
,p_prn_height=>297
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#9bafde'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'normal'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#efefef'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(241862165730374011)
,p_max_row_count=>'1000000'
,p_no_data_found_message=>unistr('Aucun bon \00E0 facturer !')
,p_allow_save_rpt_public=>'Y'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_rows_per_page=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'BDHE'
,p_internal_uid=>186689605274701042
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85155398328587220)
,p_db_column_name=>'NUM_CLT'
,p_display_order=>10
,p_column_identifier=>'G'
,p_column_label=>'Client'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(81019207167213398)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85153362092587217)
,p_db_column_name=>'NUM_BON'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>unistr('N\00B0Bon')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85153770033587217)
,p_db_column_name=>'NUM_TABLE'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Table'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85154184567587219)
,p_db_column_name=>'NUM_ESPACE_VENTE'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Espace Vente'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(81019840160213400)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85154560803587219)
,p_db_column_name=>'DATE_BON'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Date '
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85155014819587220)
,p_db_column_name=>'MONTANT_BON'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Montant '
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85153043567587217)
,p_db_column_name=>'ID'
,p_display_order=>70
,p_column_identifier=>'A'
,p_column_label=>'Selection'
,p_column_link=>'#'
,p_column_linktext=>'<span class="t-Icon fa fa-toggle-right affbons-note" aria-hidden="true"></span>'
,p_column_link_attr=>'id=''#ID#'' class="affbons t-Button t-Button--danger t-Button--simple t-Button--small" title="Selectionner Bons: #NUM_BON#"'
,p_column_type=>'NUMBER'
,p_column_alignment=>'CENTER'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(241903258278604020)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'20412'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ID:NUM_BON:NUM_TABLE:NUM_ESPACE_VENTE:DATE_BON:MONTANT_BON:NUM_CLT'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(241918768775850505)
,p_plug_name=>'Infos'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85145227536587203)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(241810388230436602)
,p_button_name=>'Clien'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Nouveau client'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85145600202587203)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(241810388230436602)
,p_button_name=>'Editer'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Editer'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:103:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85146044856587204)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(241810388230436602)
,p_button_name=>'Generer'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('G\00E9n\00E9rer facture')
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85146372981587204)
,p_name=>'P102_NUM_FACTURE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(241810388230436602)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('N\00B0Facture')
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85146860273587204)
,p_name=>'P102_CLIENT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(241810388230436602)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Client'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'CLIENT'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nom_clt as d,',
'       num_clt as r',
'  from client',
' order by 1'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'DIALOG',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85147255667587206)
,p_name=>'P102_TYPE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(241810388230436602)
,p_use_cache_before_default=>'NO'
,p_item_default=>'3'
,p_prompt=>'Type facture'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select LIBELLE_TYPE_FACTURE,NUM_TYPE_FACTURE',
'from TYPE_FACTURE;'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85147581975587206)
,p_name=>'P102_DATE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(241810388230436602)
,p_use_cache_before_default=>'NO'
,p_item_default=>'select sysdate from dual;'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Date'
,p_format_mask=>'DD/MM/YYYY'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'appearance_and_behavior', 'MONTH-PICKER:YEAR-PICKER',
  'days_outside_month', 'VISIBLE',
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_on', 'FOCUS',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85147995480587206)
,p_name=>'P102_REFERENCE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(241810388230436602)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('R\00E9f\00E9rence')
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85148424461587208)
,p_name=>'P102_NEW'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(241810388230436602)
,p_use_cache_before_default=>'NO'
,p_source=>'select v(''app_session'') from dual;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85148765938587208)
,p_name=>'P102_NB_BONS'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(241810388230436602)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nvl(count(*),0)  from bons',
'    where num_bon in( select num_bon from bons_facture where num_session = v(''app_session''));'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85149208395587208)
,p_name=>'P102_OK'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(241810388230436602)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85152292115587214)
,p_name=>'P102_NUM_BOND'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(241810687003436605)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85156084531587222)
,p_name=>'P102_NUM_BON'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(241812379164436622)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85156516892587223)
,p_name=>'P102_PROFIL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(241812379164436622)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select code_statut_personnel  from personnel',
'    where trim(profil_app) =v(''app_user'');'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85156866342587223)
,p_name=>'P102_POINT_VENTE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(241812379164436622)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Point vente'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'POINT_VENTE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nom_point_vente as d,',
'       num_point_vente as r',
'  from point_vente where actif=''O''',
'order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85157283522587225)
,p_name=>'P102_ETAT_BON'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(241812379164436622)
,p_prompt=>'Etat bon'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'ETAT_BON'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select libelle_etat_bon as d,',
'       code_etat_bon as r',
'  from etat_bon',
' order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85157735070587225)
,p_name=>'P102_CLT'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(241812379164436622)
,p_prompt=>'Client'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'CLIENT'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nom_clt as d,',
'       num_clt as r',
'  from client',
' order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85158384059587226)
,p_name=>'P102_NEW_1'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(241918768775850505)
,p_prompt=>'New'
,p_source=>unistr('1 - S\00E9lectionnez le client \00E0 facturer (cr\00E9ez le si il est nouveau);')
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85158804002587226)
,p_name=>'P102_NEW_2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(241918768775850505)
,p_source=>unistr('2 - S\00E9lectionnez les bons \00E0 facturer dans la liste des bons \00E0 gauche;')
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85159177633587228)
,p_name=>'P102_NEW_3'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(241918768775850505)
,p_source=>unistr('3 - Cliquez sur le bouton "G\00E9n\00E9rer facture" pour g\00E9n\00E9rer la facture puis sur le bouton "Editer" pour l''\00E9diter')
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85160057892587229)
,p_name=>'affbons '
,p_event_sequence=>10
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'a.affbons'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85160511183587229)
,p_event_id=>wwv_flow_imp.id(85160057892587229)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P102_NUM_BON'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.id'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85161010639587231)
,p_event_id=>wwv_flow_imp.id(85160057892587229)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_b is select num_bon from bons_facture',
'where num_bon = :P102_NUM_BON',
'and num_session = v(''app_session'');',
'',
'r_b c_b%rowtype;',
'begin',
'open c_b;',
'fetch c_b into r_b;',
'if c_b%notfound then',
'    insert into bons_facture values (:P102_NUM_BON,v(''app_session''));commit;',
'end if;',
'close c_b;',
'select nvl(count(*),0)  into :P102_NB_BONS from bons',
'    where num_bon in( select num_bon from bons_facture where num_session = v(''app_session''));',
'end;',
''))
,p_attribute_02=>'P102_NUM_BON,P102_NB_BONS'
,p_attribute_03=>'P102_NB_BONS'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85161533166587231)
,p_event_id=>wwv_flow_imp.id(85160057892587229)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(241810687003436605)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85161984803587231)
,p_event_id=>wwv_flow_imp.id(85160057892587229)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P102_NB_BONS'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85162410936587233)
,p_name=>'supp'
,p_event_sequence=>20
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'a.delete'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85162916536587234)
,p_event_id=>wwv_flow_imp.id(85162410936587233)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P102_NUM_BOND'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.id'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85163431017587234)
,p_event_id=>wwv_flow_imp.id(85162410936587233)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Etes-vous s&#xFB;r de vouloir supprimer ce bon?'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85163923818587234)
,p_event_id=>wwv_flow_imp.id(85162410936587233)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete bons_facture where num_bon = :P102_NUM_BOND',
'and num_session = v(''app_session'');',
'commit;'))
,p_attribute_02=>'P102_NUM_BOND'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85164447755587236)
,p_event_id=>wwv_flow_imp.id(85162410936587233)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(241810687003436605)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85164830717587236)
,p_name=>'facture'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(85146044856587204)
,p_condition_element=>'P102_OK'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'0'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85165315460587237)
,p_event_id=>wwv_flow_imp.id(85164830717587236)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'montant number;',
'nb number;',
'numf number;mt_ht number;mt_tva number;',
'taux number;',
'tva char(1);',
'',
'begin',
'   select nvl(count(*),0) into nb from bons',
'    where num_bon in( select num_bon from bons_facture where num_session = v(''app_session''));',
'   if nvl(nb,0) > 0 then',
'       select code_tva into tva from client where num_clt = :P102_CLIENT;',
'       ',
'       select FACTURE_NUM_FACTURE_SEQ.nextval into numf from dual;:P102_NUM_FACTURE := numf;',
'       if tva = ''O'' then',
'           select taux_tva into taux from societe where code_societe = 1;taux:=1+(taux/100);',
'           select sum(pu_bon*qte_bon) into montant from details_bon',
'           where num_bon in( select num_bon from bons_facture where num_session = v(''app_session''));',
'           mt_ht := montant/taux;',
'           mt_tva := montant-mt_ht;',
'           insert into facture values (numf,:P102_CLIENT,:P102_TYPE,null,:P102_date,:P102_REFERENCE,mt_ht,0,''O'',v(''app_user''),sysdate,mt_tva,montant,:P102_POINT_VENTE);',
'           insert into DETAIL_FACTURE select SEQ_NUM_DETAIL_FACTURE.nextval,numf,num_produit,qte_bon,pu_bon/taux,num_bon,v(''app_user''),sysdate from details_bon',
'           where num_bon in( select num_bon from bons_facture where num_session = v(''app_session''));',
'           update bons set num_facture = numf,facture=''O''',
'           where num_bon in( select num_bon from bons_facture where num_session = v(''app_session''));',
'       else',
'           ',
'           select sum(pu_bon*qte_bon) into montant from details_bon',
'            where num_bon in( select num_bon from bons_facture where num_session = v(''app_session''));',
'           insert into facture values (numf,:P102_CLIENT,:P102_TYPE,null,:P102_date,:P102_REFERENCE,montant,0,''O'',v(''app_user''),sysdate,0,montant,:P102_POINT_VENTE);',
'           insert into DETAIL_FACTURE select SEQ_NUM_DETAIL_FACTURE.nextval,numf,num_produit,qte_bon,pu_bon,num_bon,v(''app_user''),sysdate from details_bon',
'           where num_bon in( select num_bon from bons_facture where num_session = v(''app_session''));',
'           update bons set num_facture = numf,facture=''O''',
'           where num_bon in( select num_bon from bons_facture where num_session = v(''app_session''));',
'      end if;',
'      delete bons_facture where num_session = v(''app_session'');',
'      update parametres_etats set valeur_num = numf',
'      where trim(nom_parametre) = ''numero_facture''',
'      and code_etat = 3;',
'    end if;',
'    commit;',
'end;',
'       ',
'   ',
'        ',
'    ',
'',
'                           ',
''))
,p_attribute_02=>'P102_TYPE,P102_DATE,P102_REFERENCE,P102_NUM_FACTURE,P102_CLIENT,P102_POINT_VENTE'
,p_attribute_03=>'P102_NUM_FACTURE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85165793996587237)
,p_event_id=>wwv_flow_imp.id(85164830717587236)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Facture  g&#xE9;n&#xE9;r&#xE9;e avec succ&#xE8;s'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85166297992587239)
,p_event_id=>wwv_flow_imp.id(85164830717587236)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(241810687003436605)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85166840527587239)
,p_event_id=>wwv_flow_imp.id(85164830717587236)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(241812379164436622)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85167350272587239)
,p_event_id=>wwv_flow_imp.id(85164830717587236)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P102_NUM_FACTURE'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85167764251587240)
,p_event_id=>wwv_flow_imp.id(85164830717587236)
,p_event_result=>'TRUE'
,p_action_sequence=>60
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P102_NUM_FACTURE_1'
,p_attribute_01=>'PLSQL_EXPRESSION'
,p_attribute_04=>':P102_NUM_FACTURE'
,p_attribute_07=>'P102_NUM_FACTURE'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85168177177587240)
,p_name=>'etat'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P102_ETAT_BON,P102_POINT_VENTE'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85168674654587242)
,p_event_id=>wwv_flow_imp.id(85168177177587240)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(241812379164436622)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85169071060587242)
,p_name=>'clt'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P102_CLT'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85169590736587242)
,p_event_id=>wwv_flow_imp.id(85169071060587242)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(241812379164436622)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85170025633587244)
,p_name=>'APP'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P102_PROFIL'
,p_condition_element=>'P102_PROFIL'
,p_triggering_condition_type=>'NOT_EQUALS'
,p_triggering_expression=>'3'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85170473223587244)
,p_event_id=>wwv_flow_imp.id(85170025633587244)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_pv is select num_point_vente from personnel p,affectation f',
'where p.matricule = f.matricule',
'and trim(profil_app)= v(''app_user'');',
'',
'r_pv c_pv%rowtype;',
'',
'begin',
' ',
'     open c_pv;',
'     fetch c_pv into r_pv;',
'     if c_pv%found then',
'         :P102_POINT_VENTE:= r_pv.num_point_vente;',
'     end if;',
'     close c_pv;',
'',
'  end;'))
,p_attribute_02=>'P102_POINT_VENTE'
,p_attribute_03=>'P102_POINT_VENTE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85170966323587244)
,p_event_id=>wwv_flow_imp.id(85170025633587244)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P102_POINT_VENTE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85171443677587245)
,p_name=>'ok'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P102_CLIENT,P102_TYPE,P102_DATE,P102_NB_BONS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85171919855587247)
,p_event_id=>wwv_flow_imp.id(85171443677587245)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if :P102_CLIENT is null then',
'   :P102_OK :=1;',
'elsif :P102_DATE is null then',
'     :P102_OK :=2;',
'elsif :P102_TYPE is null then',
'      :P102_OK :=3;',
'elsif nvl(:P102_NB_BONS,0) = 0 then',
'       :P102_OK :=4;',
'elsif nvl(:P102_NB_BONS,0) >  0 and :P102_CLIENT is not null and :P102_DATE is not null and :P102_TYPE is not null then ',
'       :P102_OK :=0;',
'end if;',
''))
,p_attribute_02=>'P102_CLIENT,P102_DATE,P102_TYPE,P102_NB_BONS,P102_OK'
,p_attribute_03=>'P102_OK'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85172313333587247)
,p_name=>'ok0'
,p_event_sequence=>80
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(85146044856587204)
,p_condition_element=>'P102_OK'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85172766740587247)
,p_event_id=>wwv_flow_imp.id(85172313333587247)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Vous devez renseigner le client '
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85173258697587247)
,p_name=>'ok0_2'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(85146044856587204)
,p_condition_element=>'P102_OK'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'2'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85173756817587248)
,p_event_id=>wwv_flow_imp.id(85173258697587247)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Vous devez renseigner la date'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85174095363587248)
,p_name=>'ok0_3'
,p_event_sequence=>100
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(85146044856587204)
,p_condition_element=>'P102_OK'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'3'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85174607264587250)
,p_event_id=>wwv_flow_imp.id(85174095363587248)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Vous devez renseigner le type de facture'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85175012892587250)
,p_name=>'ok4'
,p_event_sequence=>110
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(85146044856587204)
,p_condition_element=>'P102_OK'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'4'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85175526905587250)
,p_event_id=>wwv_flow_imp.id(85175012892587250)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Veuillez selectionner au moins un bon &#xE0; facturer'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(85159583990587228)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'init'
,p_process_sql_clob=>'delete bons_facture;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>85159583990587228
);
wwv_flow_imp.component_end;
end;
/
