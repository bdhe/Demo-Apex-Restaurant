prompt --application/pages/page_00000
begin
--   Manifest
--     PAGE: 00000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>0
,p_name=>'Page globale'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'D'
,p_page_component_map=>'14'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(308706900530292534)
,p_plug_name=>'Infos Vacation'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_05'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(57880477910423155)
,p_name=>'P0_NOUVEAU'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(308706900530292534)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(57880913270423157)
,p_name=>'P0_APPRO_PV'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(308706900530292534)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(57881302224423157)
,p_name=>'P0_APPRO_PV_TOUS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(308706900530292534)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(57881650535423158)
,p_name=>'P0_APPRO_DIRECT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(308706900530292534)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(57882068491423158)
,p_name=>'P0_APPRO_PROD'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(308706900530292534)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(57882538691423158)
,p_name=>'P0_APPRO_MAG'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(308706900530292534)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(57882851671423160)
,p_name=>'P0_APPRO_MAG_TOUS'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(308706900530292534)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(57883289148423160)
,p_name=>'P0_APPRO_RECEP_PV'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(308706900530292534)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(57883717263423160)
,p_name=>'P0_APPRO_VALIDES'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(308706900530292534)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(57884059559423160)
,p_name=>'P0_APPRO_DIRECTS'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(308706900530292534)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(57884540593423160)
,p_name=>'P0_SORTIE_0'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(308706900530292534)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(57884885635423160)
,p_name=>'P0_INVENT'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(308706900530292534)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(57885336462423161)
,p_name=>'P0_CMDE_0'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(308706900530292534)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(57885697720423161)
,p_name=>'P0_CMDE_1'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(308706900530292534)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(57886136847423161)
,p_name=>'P0_CMDE_T'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(308706900530292534)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83327096531280690)
,p_name=>'P0_DATE_VACATION'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(308706900530292534)
,p_use_cache_before_default=>'NO'
,p_format_mask=>'DD/MM/YYYY'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.DATEHEURE_DEBUT_VAC ',
'from vacation v,affectation a,personnel p',
'where v.num_espace_vente = a.num_espace_vente',
'and a.matricule = p.matricule',
'and cloture = ''N''',
'and trim(p.profil_app) = trim(nvl(v(''app_user''), user));'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83327552230280697)
,p_name=>'P0_PV'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(308706900530292534)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select pv.nom_point_vente',
'from affectation a,personnel p,espace_vente e,point_vente pv',
'where a.matricule = p.matricule',
'and a.num_espace_vente = e.num_espace_vente',
'and e.num_point_vente = pv.num_point_vente',
'and trim(profil_app) = nvl(v(''app_user''), user);'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83327868175280697)
,p_name=>'P0_ESPACE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(308706900530292534)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.nom_espace',
'from affectation a,personnel p,espace_vente e',
'where a.matricule = p.matricule',
'and a.num_espace_vente = e.num_espace_vente',
'and trim(profil_app) = nvl(v(''app_user''), user);'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83328301382280697)
,p_name=>'P0_USER'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(308706900530292534)
,p_use_cache_before_default=>'NO'
,p_source=>'select v(''app_user'') from dual;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83328663871280698)
,p_name=>'P0_NUM_PV'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(308706900530292534)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.num_point_vente',
'from affectation a,personnel p,espace_vente e',
'where a.matricule = p.matricule',
'and a.num_espace_vente = e.num_espace_vente',
'and trim(profil_app) = nvl(v(''app_user''), user);'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83329073625280698)
,p_name=>'P0_NUMESPACE'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(308706900530292534)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.num_espace_vente',
'from affectation a,personnel p,espace_vente e',
'where a.matricule = p.matricule',
'and a.num_espace_vente = e.num_espace_vente',
'and trim(profil_app) = nvl(v(''app_user''), user);'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83329501094280698)
,p_name=>'P0_NUM_VACATION'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(308706900530292534)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select num_vacation',
'from vacation',
'where  num_point_vente = :p0_num_pv',
'and num_espace_vente = :P0_NUMESPACE',
'and cloture = ''N'';'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp.component_end;
end;
/
