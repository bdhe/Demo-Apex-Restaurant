prompt --application/pages/page_00051
begin
--   Manifest
--     PAGE: 00051
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>51
,p_name=>'Statuts personnel'
,p_alias=>'STATUTS-PERSONNEL'
,p_step_title=>'Statuts personnel'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(268944016071649702)
,p_plug_name=>'Report 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'STATUT_PERSONNEL'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_IR'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(268944434105649702)
,p_name=>'Report 1'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_allow_save_rpt_public=>'Y'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_display_row_count=>'Y'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_rows_per_page=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:61:&SESSION.::&DEBUG.:RP:P61_CODE_STATUT_PERSONNEL:\#CODE_STATUT_PERSONNEL#\'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'BDHE'
,p_internal_uid=>213771873649976733
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86199890428711458)
,p_db_column_name=>'CODE_STATUT_PERSONNEL'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>'Code Statut Personnel'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86200265528711458)
,p_db_column_name=>'LIBELLE_STATUT_PERSONNEL'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Libelle Statut Personnel'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86200711261711459)
,p_db_column_name=>'ACTIF'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Actif'
,p_column_type=>'STRING'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_rpt_named_lov=>wwv_flow_imp.id(80976620147194334)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86201060680711459)
,p_db_column_name=>'CODE_UTILISATEUR'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Code Utilisateur'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(86201500649711461)
,p_db_column_name=>'DATE_CREATION'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>'Date Creation'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(268949362684662285)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'321397'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODE_STATUT_PERSONNEL:LIBELLE_STATUT_PERSONNEL:ACTIF:CODE_UTILISATEUR:DATE_CREATION'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(86202187142711461)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(268944016071649702)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Cr\00E9er')
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:61:&SESSION.::&DEBUG.:61'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(86202594067711462)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(268944016071649702)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86203118075711462)
,p_event_id=>wwv_flow_imp.id(86202594067711462)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(268944016071649702)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
