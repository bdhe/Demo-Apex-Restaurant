prompt --application/pages/page_00104
begin
--   Manifest
--     PAGE: 00104
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>104
,p_name=>unistr('Comptoir - Op\00E9ration de caisse')
,p_alias=>unistr('COMPTOIR-OP\00C9RATION-DE-CAISSE')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Comptoir - Op\00E9ration de caisse')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'02'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(198923353223617617)
,p_plug_name=>unistr('Saisie op\00E9ration de caisse')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(265269415987943458)
,p_plug_name=>unistr('Op\00E9ration de caisse')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>20
,p_query_type=>'TABLE'
,p_query_table=>'OPERATION_CAISSE'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(265279481659943471)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(83775729916549633)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(265279481659943471)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Enregistrer'
,p_button_position=>'CLOSE'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P104_NUM_OP_CAISSE'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_row=>'Y'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(83775348968549631)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(265279481659943471)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Supprimer'
,p_button_position=>'DELETE'
,p_button_alignment=>'RIGHT'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_button_condition=>'P104_NUM_OP_CAISSE'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_grid_new_row=>'Y'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(83776086084549633)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(265279481659943471)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Cr\00E9er')
,p_button_position=>'PREVIOUS'
,p_button_alignment=>'RIGHT'
,p_button_condition=>'P104_NUM_OP_CAISSE'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83761458184549606)
,p_name=>'P104_NUM_VAC'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(198923353223617617)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.num_vacation',
'from vacation v,affectation a,personnel p',
'where v.num_espace_vente = a.num_espace_vente',
'and a.matricule = p.matricule',
'and cloture = ''N''',
'and trim(p.profil_app) = trim(v(''app_user''));'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83761832327549608)
,p_name=>'P104_DATE_VACATION'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(198923353223617617)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.DATEHEURE_DEBUT_VAC',
'from vacation v,affectation a,personnel p',
'where v.num_espace_vente = a.num_espace_vente',
'and a.matricule = p.matricule',
'and cloture = ''N''',
'and trim(p.profil_app) = trim(nvl(v(''app_user''), user));'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83762178619549608)
,p_name=>'P104_SOLDE_INIT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(198923353223617617)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select SOLDE_INITIAL_CAISSE as SOLDE',
'from vacation',
'where num_vacation = :p104_num_vac;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83762651382549609)
,p_name=>'P104_TOT_VENTES'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(198923353223617617)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  sum(MONTANT_OP) as tot ',
'from operation_caisse',
'where num_vacation= :P104_NUM_VAC',
'and CODE_TYPE_OP_CAISSE = 4',
'and sens = ''C'';'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83763009480549609)
,p_name=>'P104_TOT_CREDIT'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(198923353223617617)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  nvl(sum(MONTANT_OP),0) as tot ',
'from operation_caisse',
'where num_vacation= :P104_NUM_VAC',
'and CODE_TYPE_OP_CAISSE !=4',
'and sens = ''C'';'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83763433687549609)
,p_name=>'P104_TOT_DEBIT'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(198923353223617617)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  nvl(sum(MONTANT_OP),0) as tot ',
'from operation_caisse',
'where num_vacation= :P104_NUM_VAC',
'and CODE_TYPE_OP_CAISSE !=4',
'and sens = ''D'';'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83763839976549611)
,p_name=>'P104_SOLDE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(198923353223617617)
,p_use_cache_before_default=>'NO'
,p_source=>'nvl(:P104_TOT_VENTES,0)+nvl(:P104_SOLDE_INIT,0)+nvl(:P104_TOT_CREDIT,0)-nvl(:P104_TOT_DEBIT,0)'
,p_source_type=>'EXPRESSION'
,p_source_language=>'PLSQL'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83764484533549612)
,p_name=>'P104_NUM_CAISSE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(265269415987943458)
,p_item_source_plug_id=>wwv_flow_imp.id(265269415987943458)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.num_caisse',
'from affectation a,personnel p,espace_vente e',
'where a.matricule = p.matricule',
'and a.num_espace_vente = e.num_espace_vente',
'and trim(profil_app) = nvl(v(''app_user''), user);'))
,p_item_default_type=>'SQL_QUERY'
,p_source=>'NUM_CAISSE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83764922048549614)
,p_name=>'P104_NUM_OP_CAISSE'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(265269415987943458)
,p_item_source_plug_id=>wwv_flow_imp.id(265269415987943458)
,p_item_default=>'OPERATION_CAISSE_NUM_OP_CAISSE'
,p_item_default_type=>'SEQUENCE'
,p_source=>'NUM_OP_CAISSE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83765317834549614)
,p_name=>'P104_CODE_TYPE_OP_CAISSE'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(265269415987943458)
,p_item_source_plug_id=>wwv_flow_imp.id(265269415987943458)
,p_prompt=>' Type Op Caisse'
,p_source=>'CODE_TYPE_OP_CAISSE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TYPE OPERATION CAISSE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select libelle_type_op_caisse as d,',
'       code_type_op_caisse as r',
'  from type_operation_caisse p',
' order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83765627434549615)
,p_name=>'P104_DATEHEURE_OP'
,p_source_data_type=>'DATE'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(265269415987943458)
,p_item_source_plug_id=>wwv_flow_imp.id(265269415987943458)
,p_prompt=>'Dateheure Op'
,p_source=>'DATEHEURE_OP'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>3031561932232085882
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83766023981549615)
,p_name=>'P104_REFERENCE'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(265269415987943458)
,p_item_source_plug_id=>wwv_flow_imp.id(265269415987943458)
,p_prompt=>'Reference'
,p_source=>'REFERENCE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>60
,p_cMaxlength=>150
,p_cHeight=>5
,p_field_template=>3031561932232085882
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83766411306549615)
,p_name=>'P104_SENS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(265269415987943458)
,p_item_source_plug_id=>wwv_flow_imp.id(265269415987943458)
,p_prompt=>'Sens'
,p_source=>'SENS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>unistr('STATIC:D\00E9bit;D,Cr\00E9dit;C')
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>3031561932232085882
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83766786569549617)
,p_name=>'P104_MONTANT_OP'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(265269415987943458)
,p_item_source_plug_id=>wwv_flow_imp.id(265269415987943458)
,p_prompt=>'Montant Op'
,p_source=>'MONTANT_OP'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>3031561932232085882
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83767182147549617)
,p_name=>'P104_MATRICULE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(265269415987943458)
,p_item_source_plug_id=>wwv_flow_imp.id(265269415987943458)
,p_source=>'MATRICULE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83767604721549617)
,p_name=>'P104_NUM_REGL_CLT'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(265269415987943458)
,p_item_source_plug_id=>wwv_flow_imp.id(265269415987943458)
,p_source=>'NUM_REGL_CLT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83768020881549619)
,p_name=>'P104_NUM_VACATION'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(265269415987943458)
,p_item_source_plug_id=>wwv_flow_imp.id(265269415987943458)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.num_vacation',
'from vacation v,affectation a,personnel p',
'where v.num_espace_vente = a.num_espace_vente',
'and a.matricule = p.matricule',
'and cloture = ''N''',
'and trim(p.profil_app) = trim(v(''app_user''));'))
,p_item_default_type=>'SQL_QUERY'
,p_source=>'NUM_VACATION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83768396930549619)
,p_name=>'P104_NUM_REGL_FRN'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(265269415987943458)
,p_item_source_plug_id=>wwv_flow_imp.id(265269415987943458)
,p_source=>'NUM_REGL_FRN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83768784101549619)
,p_name=>'P104_ACTIF'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(265269415987943458)
,p_item_source_plug_id=>wwv_flow_imp.id(265269415987943458)
,p_item_default=>'O'
,p_source=>'ACTIF'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83769260441549619)
,p_name=>'P104_CODE_UTILISATEUR'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(265269415987943458)
,p_item_source_plug_id=>wwv_flow_imp.id(265269415987943458)
,p_item_default=>'select nvl(v(''app_user''), user) from dual;'
,p_item_default_type=>'SQL_QUERY'
,p_source=>'CODE_UTILISATEUR'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83769620852549620)
,p_name=>'P104_DATE_CREATION'
,p_source_data_type=>'DATE'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(265269415987943458)
,p_item_source_plug_id=>wwv_flow_imp.id(265269415987943458)
,p_item_default=>'select sysdate from dual;'
,p_item_default_type=>'SQL_QUERY'
,p_source=>'DATE_CREATION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83776934929549634)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(127804957218396311)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83777421046549636)
,p_event_id=>wwv_flow_imp.id(83776934929549634)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83777798466549636)
,p_name=>'Sens'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P104_CODE_TYPE_OP_CAISSE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83778308115549636)
,p_event_id=>wwv_flow_imp.id(83777798466549636)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NATURE_OPERATION into :P104_SENS from TYPE_OPERATION_CAISSE',
'where CODE_TYPE_OP_CAISSE = :P104_CODE_TYPE_OP_CAISSE;'))
,p_attribute_02=>'P104_CODE_TYPE_OP_CAISSE,P104_SENS'
,p_attribute_03=>'P104_SENS'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(83774580705549629)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(265269415987943458)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>unistr('Process form Op\00E9ration de caisse')
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>83774580705549629
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(83776498605549634)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>83776498605549634
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(83774166160549626)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(265269415987943458)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>unistr('Initialize form Op\00E9ration de caisse')
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>83774166160549626
);
wwv_flow_imp.component_end;
end;
/
