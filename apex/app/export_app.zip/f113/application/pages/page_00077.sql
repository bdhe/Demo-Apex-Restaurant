prompt --application/pages/page_00077
begin
--   Manifest
--     PAGE: 00077
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>77
,p_name=>'Don'
,p_alias=>'DON'
,p_page_mode=>'MODAL'
,p_step_title=>'Don'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(234847296249897833)
,p_plug_name=>'Don'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(83854471008703692)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(234847296249897833)
,p_button_name=>'Enregistrer'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Enregistrer'
,p_button_position=>'NEXT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83854880483703694)
,p_name=>'P77_NUM_BON'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(234847296249897833)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83855318782703695)
,p_name=>'P77_PWD'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(234847296249897833)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Mot de passe Administrateur'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'submit_when_enter_pressed', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83855755407703695)
,p_name=>'P77_PRODUIT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(234847296249897833)
,p_prompt=>'Produit'
,p_display_as=>'NATIVE_POPUP_LOV'
,p_named_lov=>'POINT_VENTE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nom_point_vente as d,',
'       num_point_vente as r',
'  from point_vente where actif=''O''',
'order by 1'))
,p_lov_display_null=>'YES'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'case_sensitive', 'N',
  'display_as', 'DIALOG',
  'initial_fetch', 'FIRST_ROWSET',
  'manual_entry', 'N',
  'match_type', 'CONTAINS',
  'min_chars', '0')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83856102078703697)
,p_name=>'P77_QTE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(234847296249897833)
,p_item_default=>'0'
,p_prompt=>unistr('Quantit\00E9')
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83856498509703697)
,p_name=>'P77_VERIF'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(234847296249897833)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83856958678703698)
,p_name=>'VerifPwdsaisie'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P77_PWD'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83857427789703700)
,p_event_id=>wwv_flow_imp.id(83856958678703698)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':p77_verif :=0;',
'if verifpwd(:p77_pwd) = 1 then',
'  :p77_verif := 1;',
'end if;'))
,p_attribute_02=>'P77_PWD,P77_VERIF'
,p_attribute_03=>'P77_VERIF'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83857838263703700)
,p_name=>'Verifpwd'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P77_VERIF'
,p_condition_element=>'P77_VERIF'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'0'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83858349499703701)
,p_event_id=>wwv_flow_imp.id(83857838263703700)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P77_PRODUIT'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83858797238703701)
,p_event_id=>wwv_flow_imp.id(83857838263703700)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P77_PRODUIT'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83859336367703701)
,p_event_id=>wwv_flow_imp.id(83857838263703700)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P77_QTE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83859760963703703)
,p_event_id=>wwv_flow_imp.id(83857838263703700)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P77_QTE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83860330715703703)
,p_event_id=>wwv_flow_imp.id(83857838263703700)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Mot de passe administrateur incorrect !'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83860843853703704)
,p_event_id=>wwv_flow_imp.id(83857838263703700)
,p_event_result=>'FALSE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(83854471008703692)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83861305684703706)
,p_event_id=>wwv_flow_imp.id(83857838263703700)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(83854471008703692)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83861725929703706)
,p_name=>'EnregDon'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(83854471008703692)
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83862258576703708)
,p_event_id=>wwv_flow_imp.id(83861725929703706)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_type_det is select code_type_famille from famille_produit x,type_produit y,produits z',
'where x.code_famille = y.code_famille',
'and y.code_type_produit = z.code_type_produit',
'and num_produit = :P77_PRODUIT;',
'',
'r_type_det c_type_det%rowtype;',
'',
'type_det char(1);',
'',
'prix number:=0;',
'',
'begin',
'    if nvl(:p77_qte,0) > 0 then',
'            open c_type_det;',
'            fetch c_type_det into r_type_det;',
'            if c_type_det%found then',
'                type_det := r_type_det.code_type_famille;',
'             end if;',
'             close c_type_det;',
'',
'            insert into details_bon_temp(NUM_DETAIL_BON,NUM_PRODUIT,NUM_BON,QTE_BON,PU_BON,QTE_RETOURNE,QTE_CONSIGNE,ETAT_DETAIL_BON,  ',
'                    CODE_UTILISATEUR,DATE_CREATION,LIVRE,TYPE_DETAIL_BON,NUM_MENU,TOTAL)',
'            values(seq_det_bon_temp.nextval,:P77_PRODUIT,:P77_NUM_BON,:P77_QTE,prix,null,null,0,  ',
'                    nvl(v(''app_user''), user),sysdate,0,type_det,null,prix*1);',
'            commit;',
'    end if;',
'            ',
'   /*select sum(nvl(qte_bon,0)*nvl(pu_bon,0)) into :P15_TOTAL from details_bon_temp;',
'   if nvl(:P12_NUM_BON,0)=0 then',
'      :p12_nouveau := 1;',
'   else',
'       if :p12_nouveau = 0 then',
'             :p12_nouveau := 1;',
'       else',
'             :p12_nouveau := 0;',
'       end if;',
'   end if;*/',
'      ',
'end;',
''))
,p_attribute_02=>'P77_PRODUIT,P77_QTE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83862723941703708)
,p_event_id=>wwv_flow_imp.id(83861725929703706)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83863084605703708)
,p_name=>'New'
,p_event_sequence=>40
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(234847296249897833)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexbeforerefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83863563308703709)
,p_event_id=>wwv_flow_imp.id(83863084605703708)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P77_PRODUIT'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83864131728703709)
,p_event_id=>wwv_flow_imp.id(83863084605703708)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(83854471008703692)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83864620796703711)
,p_event_id=>wwv_flow_imp.id(83863084605703708)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P77_QTE'
);
wwv_flow_imp.component_end;
end;
/
