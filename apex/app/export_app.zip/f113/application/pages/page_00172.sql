prompt --application/pages/page_00172
begin
--   Manifest
--     PAGE: 00172
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>172
,p_name=>unistr('R\00E8glement bon')
,p_alias=>unistr('R\00C8GLEMENT-BON')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('R\00E8glement bon')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(276305713990629060)
,p_plug_name=>'Reglement bon'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(83881232227724197)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(276305713990629060)
,p_button_name=>'Enregistrer'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Enregistrer'
,p_button_position=>'EDIT'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(83923489084724258)
,p_branch_name=>'Go To Page 82'
,p_branch_action=>'f?p=&APP_ID.:82:&SESSION.::&DEBUG.:RP::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_COMPUTATION'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83881603437724197)
,p_name=>'P172_MODE_REG'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(276305713990629060)
,p_use_cache_before_default=>'NO'
,p_item_default=>'1'
,p_prompt=>unistr('Mode R\00E8glement')
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select libelle_mode,ID_MODERGLT from MODE_RGLT',
'order by ID_MODERGLT '))
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '6',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83882044090724198)
,p_name=>'P172_CLIENT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(276305713990629060)
,p_prompt=>'Client'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_colspan=>4
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'NONE',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83882373754724198)
,p_name=>'P172_REFERENCE_CHEQUE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(276305713990629060)
,p_prompt=>'Reference '
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83882774400724200)
,p_name=>'P172_VERIF'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(276305713990629060)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83883196711724200)
,p_name=>'P172_VERIFL'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(276305713990629060)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83883645691724200)
,p_name=>'P172_NUM_PV'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(276305713990629060)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct num_point_vente  from bons b,espace_vente e ',
'where b.num_espace_vente = e.num_espace_vente',
'and num_bon = (select distinct num_bon from details_bon_temp',
'where trim(util_modif) = nvl(v(''app_user''), user));'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83883964345724201)
,p_name=>'P172_CLT'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(276305713990629060)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct num_clt from bons ',
'where num_bon = (select distinct num_bon from details_bon_temp',
'where trim(util_modif) = nvl(v(''app_user''), user));'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83884427169724201)
,p_name=>'P172_NUM_ESPACE'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(276305713990629060)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct num_espace_vente from bons ',
'where num_bon = (select distinct num_bon from details_bon_temp',
'where trim(util_modif) = nvl(v(''app_user''), user));'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83884801661724201)
,p_name=>'P172_NBPERS'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(276305713990629060)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83885194717724201)
,p_name=>'P172_TABLE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(276305713990629060)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83885573783724203)
,p_name=>'P172_NUM_BON'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(276305713990629060)
,p_use_cache_before_default=>'NO'
,p_prompt=>unistr('N\00B0Bon')
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct num_bon from details_bon_temp',
'where trim(util_modif) = nvl(v(''app_user''), user);'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83886020564724203)
,p_name=>'P172_CMDE'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(276305713990629060)
,p_prompt=>unistr('N\00B0Cmde')
,p_format_mask=>'999G999G999G999G999G999G990'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select num_table from bons',
'where num_bon = :P172_NUM_BON;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83886385691724203)
,p_name=>'P172_TOTAL'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(276305713990629060)
,p_prompt=>'Total'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select distinct montant_bon from bons ',
'where num_bon = (select distinct num_bon from details_bon_temp',
'where trim(util_modif) = nvl(v(''app_user''), user));'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83886789827724203)
,p_name=>'P172_MT_ARRONDI'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(276305713990629060)
,p_item_default=>'0'
,p_prompt=>unistr('Arrondi \00E0')
,p_format_mask=>'999G999G999G999G999G999G990'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83887177995724204)
,p_name=>'P172_ARRONDI'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(276305713990629060)
,p_prompt=>'Arrondi'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83887642987724204)
,p_name=>'P172_SE'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(276305713990629060)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select code_traitement from bons',
'where num_bon = :P172_NUM_BON;'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83888035456724204)
,p_name=>'P172_PWD'
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(276305713990629060)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Mot de passe pour la remise'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_colspan=>4
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'submit_when_enter_pressed', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83888411875724204)
,p_name=>'P172_TYPE'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(276305713990629060)
,p_prompt=>'Type remise'
,p_display_as=>'NATIVE_RADIOGROUP'
,p_lov=>'STATIC:Pourcentage;1,Montant;2'
,p_begin_on_new_line=>'N'
,p_colspan=>4
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '2',
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83888842072724206)
,p_name=>'P172_VALEUR_REMISE'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(276305713990629060)
,p_prompt=>'Valeur Remise'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83889210960724206)
,p_name=>'P172_MONTANT_REMISE'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(276305713990629060)
,p_prompt=>'Remise'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83889636085724206)
,p_name=>'P172_LIVREUR'
,p_item_sequence=>220
,p_item_plug_id=>wwv_flow_imp.id(276305713990629060)
,p_prompt=>'Livreur'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select trim(nom) || '' '' || trim(prenoms) as nom, matricule from personnel',
'where code_statut_personnel = 8;'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83889973412724208)
,p_name=>'P172_PWD_L'
,p_item_sequence=>230
,p_item_plug_id=>wwv_flow_imp.id(276305713990629060)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Mot de passe pour exempter les frais'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>5
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'submit_when_enter_pressed', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83890446617724208)
,p_name=>'P172_FRAISL'
,p_item_sequence=>240
,p_item_plug_id=>wwv_flow_imp.id(276305713990629060)
,p_prompt=>'Frais de livraison'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_colspan=>3
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83890825870724208)
,p_name=>'P172_NET'
,p_item_sequence=>250
,p_item_plug_id=>wwv_flow_imp.id(276305713990629060)
,p_prompt=>unistr('Montant \00E0 payer')
,p_format_mask=>'999G999G999G999G999G999G990'
,p_source=>'P172_TOTAL'
,p_source_type=>'ITEM'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_column=>7
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83891223487724208)
,p_name=>'P172_ENCAISSE'
,p_is_required=>true
,p_item_sequence=>260
,p_item_plug_id=>wwv_flow_imp.id(276305713990629060)
,p_prompt=>unistr('Montant encaiss\00E9')
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_grid_column=>7
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83891610924724209)
,p_name=>'P172_RELIQUAT'
,p_item_sequence=>270
,p_item_plug_id=>wwv_flow_imp.id(276305713990629060)
,p_prompt=>'Reliquat'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_grid_column=>7
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'N',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83892022553724209)
,p_name=>'P172_NUM_CAISSE'
,p_item_sequence=>280
,p_item_plug_id=>wwv_flow_imp.id(276305713990629060)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.num_caisse',
'from affectation a,personnel p,espace_vente e',
'where a.matricule = p.matricule',
'and a.num_espace_vente = e.num_espace_vente',
'and trim(profil_app) = nvl(v(''app_user''), user);'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83892399553724211)
,p_name=>'P172_NUM_VACATION'
,p_item_sequence=>290
,p_item_plug_id=>wwv_flow_imp.id(276305713990629060)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.num_vacation',
'from vacation v,affectation a,personnel p',
'where v.num_espace_vente = a.num_espace_vente',
'and a.matricule = p.matricule',
'and cloture = ''N''',
'and trim(p.profil_app) = trim(nvl(v(''app_user''), user));'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83892858248724212)
,p_name=>'P172_DATE_VAC'
,p_item_sequence=>300
,p_item_plug_id=>wwv_flow_imp.id(276305713990629060)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.DATEHEURE_DEBUT_VAC ',
'from vacation v,affectation a,personnel p',
'where v.num_espace_vente = a.num_espace_vente',
'and a.matricule = p.matricule',
'and trim(p.profil_app) = trim(nvl(v(''app_user''), user))',
'and cloture=''N'';'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83893219869724212)
,p_name=>'P172_RESULTAT'
,p_item_sequence=>310
,p_item_plug_id=>wwv_flow_imp.id(276305713990629060)
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.DATEHEURE_DEBUT_VAC ',
'from vacation v,affectation a,personnel p',
'where v.num_espace_vente = a.num_espace_vente',
'and a.matricule = p.matricule',
'and trim(p.profil_app) = trim(nvl(v(''app_user''), user))',
'and cloture=''N'';'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83893923608724214)
,p_name=>'EnregBon'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(83881232227724197)
,p_condition_element=>'P172_RELIQUAT'
,p_triggering_condition_type=>'GREATER_THAN_OR_EQUAL'
,p_triggering_expression=>'0'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83894432048724215)
,p_event_id=>wwv_flow_imp.id(83893923608724214)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Veuillez v&#xE9;rifier les frais de livraisons et&#x2F;ou le montant encaiss&#xE9;'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83894890959724217)
,p_event_id=>wwv_flow_imp.id(83893923608724214)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'pr_paye_bon(:p172_clt ,:p172_se ,:p172_fraisl ,:p172_encaisse ,:p172_net ,',
'									   :p172_num_pv ,:p172_DATE_VAC ,v(''app_user''),:p172_arrondi ,:p172_montant_remise ,',
'									   :p172_num_caisse ,:p172_num_vacation ,:p172_num_bon ,:p172_mode_reg ,',
'									   :p172_LIVREUR ,:p172_reference_cheque ,:p172_CLIENT ,:p172_RELIQUAT ,:P172_TOTAL,',
'									   :p172_resultat );'))
,p_attribute_02=>'P172_NUM_BON,P172_NUM_PV,P172_ARRONDI,P172_MONTANT_REMISE,P172_TOTAL,P172_NET,P172_NUM_CAISSE,P172_NUM_VACATION,P172_DATE_VAC,P172_MODE_REG,P172_CLIENT,P172_CLT,P172_RELIQUAT,P172_REFERENCE_CHEQUE,P172_LIVREUR,P172_SE,P172_FRAISL,P172_RESULTAT'
,p_attribute_03=>'P172_RESULTAT'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83895312008724217)
,p_name=>'arrondi'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P172_MT_ARRONDI'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83895809346724219)
,p_event_id=>wwv_flow_imp.id(83895312008724217)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P172_ARRONDI'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>' select decode(:p172_mt_arrondi,0,0,(:p172_total-:p172_mt_arrondi)*-1) as mt from dual;'
,p_attribute_07=>'P172_MT_ARRONDI,P172_TOTAL,P172_MONTANT_REMISE'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83896305712724219)
,p_event_id=>wwv_flow_imp.id(83895312008724217)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P172_NET'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'select :p172_total +nvl(:P172_FRAISL,0)+nvl(:p172_arrondi,0)-nvl(:p172_montant_remise,0) as t from dual;'
,p_attribute_07=>'P172_MT_ARRONDI,P172_MONTANT_REMISE,P172_TOTAL,P172_ARRONDI,P172_FRAISL'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83896828916724220)
,p_event_id=>wwv_flow_imp.id(83895312008724217)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P172_ENCAISSE'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'0'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83897346195724220)
,p_event_id=>wwv_flow_imp.id(83895312008724217)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P172_RELIQUAT'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'0'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83897783548724222)
,p_event_id=>wwv_flow_imp.id(83895312008724217)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P172_MONTANT_REMISE'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'select decode(:p172_type,1,:p172_total*:p172_valeur_remise/100,2,:p172_valeur_remise,0)  as t from dual;'
,p_attribute_07=>'P172_TYPE,P172_VALEUR_REMISE,P172_NET,P172_TOTAL'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83898210025724222)
,p_name=>'calculReliquat'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P172_ENCAISSE'
,p_condition_element=>'P172_ENCAISSE'
,p_triggering_condition_type=>'GREATER_THAN_OR_EQUAL'
,p_triggering_expression=>'0'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83898732193724222)
,p_event_id=>wwv_flow_imp.id(83898210025724222)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P172_RELIQUAT'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'select :p172_encaisse - :p172_net from dual;'
,p_attribute_07=>'P172_ENCAISSE,P172_NET'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83899200925724223)
,p_event_id=>wwv_flow_imp.id(83898210025724222)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(83881232227724197)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83899645961724223)
,p_name=>'disable'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P172_NUM_BON'
,p_condition_element=>'P172_NUM_BON'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83900151956724225)
,p_event_id=>wwv_flow_imp.id(83899645961724223)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P172_TYPE,P172_VALEUR_REMISE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83900558752724225)
,p_name=>'showpwd'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P172_TYPE'
,p_condition_element=>'P172_TYPE'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83901035321724226)
,p_event_id=>wwv_flow_imp.id(83900558752724225)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P172_PWD'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83901381037724226)
,p_name=>'New'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P172_VALEUR_REMISE'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83901922317724228)
,p_event_id=>wwv_flow_imp.id(83901381037724226)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P172_MONTANT_REMISE'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'select decode(:p172_type,1,:p172_total*:p172_valeur_remise/100,2,:p172_valeur_remise,0)  as t from dual;'
,p_attribute_07=>'P172_VALEUR_REMISE,P172_NET,P172_TYPE,P172_TOTAL'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83902422733724228)
,p_event_id=>wwv_flow_imp.id(83901381037724226)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P172_NET'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'select :p172_total +nvl(:P172_FRAISL,0)+nvl(:p172_arrondi,0)-nvl(:p172_montant_remise,0) as t from dual;'
,p_attribute_07=>'P172_TOTAL,P172_ARRONDI,P172_MONTANT_REMISE,P172_FRAISL'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83902873224724229)
,p_event_id=>wwv_flow_imp.id(83901381037724226)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P172_RELIQUAT'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'select (:p172_total +nvl(:P172_FRAISL,0)+nvl(:p172_arrondi,0)-nvl(:p172_montant_remise,0))*-1 as t from dual;'
,p_attribute_07=>'P172_TOTAL,P172_ARRONDI,P172_MONTANT_REMISE,P172_FRAISL'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83903332684724229)
,p_name=>'DisableRemise'
,p_event_sequence=>90
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(276305713990629060)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexbeforerefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83903858908724231)
,p_event_id=>wwv_flow_imp.id(83903332684724229)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P172_TYPE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83904350805724231)
,p_event_id=>wwv_flow_imp.id(83903332684724229)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P172_VALEUR_REMISE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83904826862724231)
,p_event_id=>wwv_flow_imp.id(83903332684724229)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(83881232227724197)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83905253462724233)
,p_name=>'veridpwd'
,p_event_sequence=>100
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P172_PWD'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83905715698724233)
,p_event_id=>wwv_flow_imp.id(83905253462724233)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':p172_verif :=0;',
'if verifpwd(:p172_pwd) = 1 then',
'  :p172_verif := 1;',
'end if;'))
,p_attribute_02=>'P172_PWD,P172_VERIF'
,p_attribute_03=>'P172_VERIF'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83906079229724233)
,p_name=>'verif'
,p_event_sequence=>120
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P172_VERIF'
,p_condition_element=>'P172_VERIF'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83906637634724234)
,p_event_id=>wwv_flow_imp.id(83906079229724233)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P172_TYPE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83907135931724234)
,p_event_id=>wwv_flow_imp.id(83906079229724233)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P172_VALEUR_REMISE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83907538578724234)
,p_name=>'New_1'
,p_event_sequence=>130
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(83881232227724197)
,p_condition_element=>'P172_RELIQUAT'
,p_triggering_condition_type=>'GREATER_THAN'
,p_triggering_expression=>'0'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83908027702724236)
,p_event_id=>wwv_flow_imp.id(83907538578724234)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83908456364724236)
,p_name=>'ESPECES'
,p_event_sequence=>140
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P172_MODE_REG'
,p_condition_element=>'P172_MODE_REG'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83908944542724237)
,p_event_id=>wwv_flow_imp.id(83908456364724236)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P172_CLIENT'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83909374760724239)
,p_event_id=>wwv_flow_imp.id(83908456364724236)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P172_REFERENCE_CHEQUE'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83909840278724239)
,p_name=>'CLIENT'
,p_event_sequence=>150
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P172_MODE_REG'
,p_condition_element=>'P172_MODE_REG'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'3'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83910292885724239)
,p_event_id=>wwv_flow_imp.id(83909840278724239)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P172_REFERENCE_CHEQUE'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83910764579724240)
,p_event_id=>wwv_flow_imp.id(83909840278724239)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P172_CLIENT'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83911160678724240)
,p_name=>'CHEQUE'
,p_event_sequence=>160
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P172_MODE_REG'
,p_condition_element=>'P172_MODE_REG'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'2'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83911668661724242)
,p_event_id=>wwv_flow_imp.id(83911160678724240)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P172_CLIENT'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83912208630724242)
,p_event_id=>wwv_flow_imp.id(83911160678724240)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P172_REFERENCE_CHEQUE'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83912640133724242)
,p_name=>'Tmoney'
,p_event_sequence=>170
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P172_MODE_REG'
,p_condition_element=>'P172_MODE_REG'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'4'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83913128650724244)
,p_event_id=>wwv_flow_imp.id(83912640133724242)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P172_CLIENT'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83913628264724244)
,p_event_id=>wwv_flow_imp.id(83912640133724242)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P172_REFERENCE_CHEQUE'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83913971251724245)
,p_name=>'Flooz'
,p_event_sequence=>180
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P172_MODE_REG'
,p_condition_element=>'P172_MODE_REG'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'5'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83914471532724245)
,p_event_id=>wwv_flow_imp.id(83913971251724245)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P172_CLIENT'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83915026575724245)
,p_event_id=>wwv_flow_imp.id(83913971251724245)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P172_REFERENCE_CHEQUE'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83915363106724247)
,p_name=>'liv'
,p_event_sequence=>190
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P172_FRAISL'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83915894677724247)
,p_event_id=>wwv_flow_imp.id(83915363106724247)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P172_NET'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'select :p172_total +nvl(:P172_FRAISL,0)+nvl(:p172_arrondi,0)-nvl(:p172_montant_remise,0) as t from dual;'
,p_attribute_07=>'P172_TOTAL,P172_FRAISL,P172_ARRONDI,P172_MONTANT_REMISE'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83916396850724248)
,p_event_id=>wwv_flow_imp.id(83915363106724247)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P172_RELIQUAT'
,p_attribute_01=>'SQL_STATEMENT'
,p_attribute_03=>'select :p172_encaisse - :p172_net from dual;'
,p_attribute_07=>'P172_ENCAISSE,P172_NET'
,p_attribute_08=>'Y'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83916864907724248)
,p_event_id=>wwv_flow_imp.id(83915363106724247)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P172_ENREG'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'0'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83917273696724250)
,p_name=>'livre'
,p_event_sequence=>200
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P172_SE'
,p_condition_element=>'P172_SE'
,p_triggering_condition_type=>'IN_LIST'
,p_triggering_expression=>'S,E'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83917855163724250)
,p_event_id=>wwv_flow_imp.id(83917273696724250)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P172_LIVREUR,P172_FRAISL,P172_PWD_L'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83918330437724251)
,p_event_id=>wwv_flow_imp.id(83917273696724250)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P172_FRAISL,P172_LIVREUR,P172_PWD_L'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83918731359724251)
,p_name=>'verifpwdl'
,p_event_sequence=>210
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P172_PWD_L'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83919190520724251)
,p_event_id=>wwv_flow_imp.id(83918731359724251)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P172_VERIFL:=0;',
'if verifpwd(:P172_PWD_L) = 1 then',
'  :P172_VERIFL:= 1;',
'end if;'))
,p_attribute_02=>'P172_PWD_L,P172_VERIFL'
,p_attribute_03=>'P172_VERIFL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83919602067724253)
,p_name=>'fraisl0'
,p_event_sequence=>220
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P172_VERIFL'
,p_condition_element=>'P172_VERIFL'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'1'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83920087162724253)
,p_event_id=>wwv_flow_imp.id(83919602067724253)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P172_FRAISL'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'0'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83920598874724253)
,p_event_id=>wwv_flow_imp.id(83919602067724253)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P172_PWD_L,P172_FRAISL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83921035260724254)
,p_name=>'ok'
,p_event_sequence=>230
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P172_RESULTAT'
,p_condition_element=>'P172_RESULTAT'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'0'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83921550135724254)
,p_event_id=>wwv_flow_imp.id(83921035260724254)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Vous devez saisir le livreur et les frais de livraison '
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83922033790724256)
,p_event_id=>wwv_flow_imp.id(83921035260724254)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Bon regl&#xE9; avec succ&#xE8;s'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83922497719724256)
,p_event_id=>wwv_flow_imp.id(83921035260724254)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83923003503724258)
,p_event_id=>wwv_flow_imp.id(83921035260724254)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(83893604806724214)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Dialogclose'
,p_attribute_02=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>83893604806724214
);
wwv_flow_imp.component_end;
end;
/
