prompt --application/pages/page_10060
begin
--   Manifest
--     PAGE: 10060
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>10060
,p_name=>'A propos de'
,p_alias=>'HELP'
,p_step_title=>'A propos de'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_group_id=>wwv_flow_imp.id(80611377477980250)
,p_page_template_options=>'#DEFAULT#'
,p_required_patch=>wwv_flow_imp.id(80607822820980225)
,p_protection_level=>'C'
,p_help_text=>unistr('L''ensemble du texte d''aide de l''application est accessible \00E0 partir de cette page. Les liens figurant dans la r\00E9gion "Documentation" fournissent une explication bien plus approfondie des fonctions et fonctionnalit\00E9s de l''application.')
,p_page_component_map=>'11'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(80761498229981236)
,p_plug_name=>'A propos de la page'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--padded:t-ContentBlock--h1:t-ContentBlock--lightBG'
,p_escape_on_http_output=>'Y'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>20
,p_query_type=>'SQL'
,p_plug_source=>unistr('Le texte concernant cette application peut \00EAtre ins\00E9r\00E9 ici.')
,p_plug_query_num_rows=>15
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp.component_end;
end;
/
