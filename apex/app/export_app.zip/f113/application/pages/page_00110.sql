prompt --application/pages/page_00110
begin
--   Manifest
--     PAGE: 00110
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>110
,p_name=>unistr('Liste des appro valid\00E9s')
,p_alias=>unistr('LISTE-DES-APPRO-VALID\00C9S')
,p_step_title=>unistr('Liste des appro valid\00E9s')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(238866756797437476)
,p_plug_name=>unistr('Liste des appro valid\00E9s')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select "NUM_APPRO", ',
'"LIBELLE",',
'"CODE_TYPE_APPRO",',
'"NUM_POINT_VENTED",',
'"NUM_POINT_VENTEA",',
'"DATE_APPRO",',
'"CODE_UTILISATEUR",',
'"DATE_CREATION",',
'"CODE_ETAT"',
'from "#OWNER#"."APPRO" ',
'where code_etat = 1',
'and NUM_POINT_VENTEA =:P110_POINT_VENTE',
'  ',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P110_POINT_VENTE'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(238867226426437478)
,p_name=>unistr('Liste des appro valid\00E9s')
,p_max_row_count=>'1000000'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_show_nulls_as=>'-'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_show_search_bar=>'N'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_enable_mail_download=>'N'
,p_detail_link=>'f?p=&APP_ID.:111:&APP_SESSION.::::P111_NUM_APPRO:#NUM_APPRO#'
,p_detail_link_text=>'<span aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'BDHE'
,p_internal_uid=>183694665970764509
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85861345920265976)
,p_db_column_name=>'NUM_APPRO'
,p_display_order=>1
,p_column_identifier=>'A'
,p_column_label=>unistr('N\00B0 Appro')
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85861717355265978)
,p_db_column_name=>'LIBELLE'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Libelle'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85862091271265978)
,p_db_column_name=>'CODE_TYPE_APPRO'
,p_display_order=>3
,p_column_identifier=>'C'
,p_column_label=>'Type Appro'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(81193600919304700)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85862490069265978)
,p_db_column_name=>'NUM_POINT_VENTED'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Point de vente sortie'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(81104181522273040)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85862948639265979)
,p_db_column_name=>'NUM_POINT_VENTEA'
,p_display_order=>5
,p_column_identifier=>'E'
,p_column_label=>unistr('Point de vente entr\00E9e')
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_rpt_named_lov=>wwv_flow_imp.id(81104181522273040)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85863268012265979)
,p_db_column_name=>'DATE_APPRO'
,p_display_order=>6
,p_column_identifier=>'F'
,p_column_label=>'Date '
,p_column_type=>'DATE'
,p_column_alignment=>'CENTER'
,p_format_mask=>'DD/MM/YYYY'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85863670292265981)
,p_db_column_name=>'CODE_UTILISATEUR'
,p_display_order=>7
,p_column_identifier=>'G'
,p_column_label=>'Code Utilisateur'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85864110587265981)
,p_db_column_name=>'DATE_CREATION'
,p_display_order=>8
,p_column_identifier=>'H'
,p_column_label=>'Date Creation'
,p_column_type=>'DATE'
,p_display_text_as=>'HIDDEN'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(85864494156265981)
,p_db_column_name=>'CODE_ETAT'
,p_display_order=>9
,p_column_identifier=>'I'
,p_column_label=>'Code Etat'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(238881006255452251)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'352180'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NUM_APPRO:LIBELLE:CODE_TYPE_APPRO:NUM_POINT_VENTED:NUM_POINT_VENTEA:DATE_APPRO:CODE_UTILISATEUR:DATE_CREATION:CODE_ETAT'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85865246613265983)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(238866756797437476)
,p_button_name=>'Quitter'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Quitter'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85865628489265986)
,p_name=>'P110_PROFIL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(238866756797437476)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select code_statut_personnel  from personnel',
'    where trim(profil_app) =v(''app_user'');'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85865977905265986)
,p_name=>'P110_POINT_VENTE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(238866756797437476)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Point Vente'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'POINT_VENTE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nom_point_vente as d,',
'       num_point_vente as r',
'  from point_vente where actif=''O''',
'order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_colspan=>5
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85866364300265987)
,p_name=>'app'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P110_PROFIL'
,p_condition_element=>'P110_PROFIL'
,p_triggering_condition_type=>'NOT_EQUALS'
,p_triggering_expression=>'3'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85866938738265987)
,p_event_id=>wwv_flow_imp.id(85866364300265987)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_pv is select num_point_vente from personnel p,affectation f',
'where p.matricule = f.matricule',
'and trim(profil_app)= v(''app_user'');',
'',
'r_pv c_pv%rowtype;',
'',
'begin',
' ',
'     open c_pv;',
'     fetch c_pv into r_pv;',
'     if c_pv%found then',
'         :P110_POINT_VENTE:= r_pv.num_point_vente;',
'         ',
'     end if;',
'     close c_pv;',
'',
'  end;',
'  ',
'  '))
,p_attribute_02=>'P110_POINT_VENTE'
,p_attribute_03=>'P110_POINT_VENTE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85867434136265989)
,p_event_id=>wwv_flow_imp.id(85866364300265987)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P110_POINT_VENTE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85867810087265989)
,p_name=>'list'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P110_POINT_VENTE'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85868276430265989)
,p_event_id=>wwv_flow_imp.id(85867810087265989)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(238866756797437476)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
