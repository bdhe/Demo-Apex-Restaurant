prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>7
,p_name=>'Recapitulatif'
,p_alias=>'RECAPITULATIF'
,p_step_title=>'Recapitulatif'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(91750611938009111)
,p_plug_name=>'Vantes'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>8
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select code_famille,p.code_type_produit,num_produit,designation_produit,',
'(select valeur from detail_produit where num_produit = p.num_produit and code_type_detail =13 and rownum = 1) prix_achat,',
'(select valeur from detail_produit where num_produit = p.num_produit and code_type_detail =2 and rownum = 1) prix_vente,',
'fn_stockprdpv(num_produit,1,:P7_DATE_DEBUT) qte_stock_depart ,',
'(select sum(qte_bon) from details_bon d,bons b where b.num_bon = d.num_bon and  d.num_produit = p.num_produit and to_number(to_char(date_bon,''yyyymmdd'')) between fn_date_num(:P7_DATE_DEBUT) and fn_date_num(:P7_DATE_FIN)) qte_vendue,',
'(select sum(qte_bon*pu_bon) from details_bon d,bons b where b.num_bon = d.num_bon and  d.num_produit = p.num_produit and to_number(to_char(date_bon,''yyyymmdd'')) between fn_date_num(:P7_DATE_DEBUT) and fn_date_num(:P7_DATE_FIN)) CA,',
'(select sum(qte_bon) from details_bon d,bons b where b.num_bon = d.num_bon and  d.num_produit = p.num_produit and to_number(to_char(date_bon,''yyyymmdd'')) between fn_date_num(:P7_DATE_DEBUT) and fn_date_num(:P7_DATE_FIN)) *',
'((select valeur from detail_produit where num_produit = p.num_produit and code_type_detail =2 and rownum = 1) -(select valeur from detail_produit where num_produit = p.num_produit and code_type_detail =13 and rownum = 1)) Marge,',
'(select sum(qte) from mouvement where num_produit = p.num_produit and to_number(to_char(date_mvt,''yyyymmdd'')) between fn_date_num(:P7_DATE_DEBUT) and fn_date_num(:P7_DATE_FIN) and code_type_mouvement = 4) qte_commande,',
'fn_stockprdpv(num_produit,1,:P7_DATE_FIN) qte_stock ,',
'(select valeur*fn_stockprdpv(num_produit,1,:P7_DATE_FIN) from detail_produit where num_produit = p.num_produit and code_type_detail =13) valorisation',
'from produits p,type_produit t',
'where stockable=''O''',
'and p.code_type_produit = t.code_type_produit',
'and code_famille in (2,3,0,5,6,710,11);'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P7_DATE_DEBUT,P7_DATE_FIN'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'Vantes'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(91750658788009112)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'BDHE'
,p_internal_uid=>75608021457236533
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91750750421009113)
,p_db_column_name=>'CODE_FAMILLE'
,p_display_order=>10
,p_column_identifier=>'A'
,p_column_label=>'Famille'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(81559302653430937)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91750838707009114)
,p_db_column_name=>'CODE_TYPE_PRODUIT'
,p_display_order=>20
,p_column_identifier=>'B'
,p_column_label=>'Type Produit'
,p_column_type=>'NUMBER'
,p_display_text_as=>'LOV_ESCAPE_SC'
,p_column_alignment=>'RIGHT'
,p_rpt_named_lov=>wwv_flow_imp.id(80978610833194342)
,p_rpt_show_filter_lov=>'1'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91750943922009115)
,p_db_column_name=>'NUM_PRODUIT'
,p_display_order=>30
,p_column_identifier=>'C'
,p_column_label=>'Num Produit'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91751128823009116)
,p_db_column_name=>'DESIGNATION_PRODUIT'
,p_display_order=>40
,p_column_identifier=>'D'
,p_column_label=>'Designation Produit'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91751213310009117)
,p_db_column_name=>'PRIX_ACHAT'
,p_display_order=>50
,p_column_identifier=>'E'
,p_column_label=>'Prix Achat'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91751246064009118)
,p_db_column_name=>'PRIX_VENTE'
,p_display_order=>60
,p_column_identifier=>'F'
,p_column_label=>'Prix Vente'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91751380172009119)
,p_db_column_name=>'QTE_STOCK_DEPART'
,p_display_order=>70
,p_column_identifier=>'G'
,p_column_label=>'Qte Stock Depart'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91751506953009120)
,p_db_column_name=>'QTE_VENDUE'
,p_display_order=>80
,p_column_identifier=>'H'
,p_column_label=>'Qte Vendue'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91751607927009121)
,p_db_column_name=>'CA'
,p_display_order=>90
,p_column_identifier=>'I'
,p_column_label=>'Chiffres d''affaires'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91751703496009122)
,p_db_column_name=>'MARGE'
,p_display_order=>100
,p_column_identifier=>'J'
,p_column_label=>'Marge'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91751770368009123)
,p_db_column_name=>'QTE_COMMANDE'
,p_display_order=>110
,p_column_identifier=>'K'
,p_column_label=>'Qte Commande'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91751893817009124)
,p_db_column_name=>'QTE_STOCK'
,p_display_order=>120
,p_column_identifier=>'L'
,p_column_label=>'Qte Stock'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91751996207009125)
,p_db_column_name=>'VALORISATION'
,p_display_order=>130
,p_column_identifier=>'M'
,p_column_label=>'Valorisation'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_format_mask=>'999G999G999G999G999G999G990'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(93561084859105174)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'774185'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODE_FAMILLE:CODE_TYPE_PRODUIT:NUM_PRODUIT:DESIGNATION_PRODUIT:PRIX_ACHAT:PRIX_VENTE:QTE_STOCK_DEPART:QTE_VENDUE:CA:MARGE:QTE_COMMANDE:QTE_STOCK:VALORISATION'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(91752077250009126)
,p_plug_name=>unistr('D\00E9penses')
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select o.CODE_TYPE_OP_CAISSE,LIBELLE_TYPE_OP_CAISSE,',
'       sum(MONTANT_OP) Montant     ',
'  from OPERATION_CAISSE o,type_operation_caisse t  ',
'  where o.CODE_TYPE_OP_CAISSE = t.CODE_TYPE_OP_CAISSE',
'  and FN_DATE_NUM(DATEHEURE_OP) between FN_DATE_NUM(:P7_DATE_DEBUT) and FN_DATE_NUM(:P7_DATE_FIN)',
'  group by o.CODE_TYPE_OP_CAISSE,LIBELLE_TYPE_OP_CAISSE'))
,p_plug_source_type=>'NATIVE_IR'
,p_ajax_items_to_submit=>'P7_DATE_DEBUT,P7_DATE_FIN'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'MILLIMETERS'
,p_prn_paper_size=>'A4'
,p_prn_width=>297
,p_prn_height=>210
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>unistr('D\00E9penses')
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(91752225310009127)
,p_max_row_count=>'1000000'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'BDHE'
,p_internal_uid=>75609587979236548
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(91752340809009129)
,p_db_column_name=>'CODE_TYPE_OP_CAISSE'
,p_display_order=>20
,p_column_identifier=>'A'
,p_column_label=>'Code Type Op Caisse'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(93567138601293392)
,p_db_column_name=>'LIBELLE_TYPE_OP_CAISSE'
,p_display_order=>30
,p_column_identifier=>'B'
,p_column_label=>'Libelle Type Op Caisse'
,p_column_type=>'STRING'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(93567265325293393)
,p_db_column_name=>'MONTANT'
,p_display_order=>40
,p_column_identifier=>'C'
,p_column_label=>'Montant'
,p_column_type=>'NUMBER'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(93572172440331627)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'774296'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'CODE_TYPE_OP_CAISSE:LIBELLE_TYPE_OP_CAISSE:MONTANT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91750176980009107)
,p_name=>'P7_DATE_DEBUT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(91750611938009111)
,p_use_cache_before_default=>'NO'
,p_item_default=>'select sysdate - 7 from dual;'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>unistr('DAte d\00E9but')
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(91750276046009108)
,p_name=>'P7_DATE_FIN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(91750611938009111)
,p_use_cache_before_default=>'NO'
,p_item_default=>'select sysdate  from dual;'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Date fin'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>3031561666792084173
,p_item_template_options=>'#DEFAULT#'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp.component_end;
end;
/
