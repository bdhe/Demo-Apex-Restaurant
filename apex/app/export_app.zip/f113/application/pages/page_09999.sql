prompt --application/pages/page_09999
begin
--   Manifest
--     PAGE: 09999
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>9999
,p_name=>'Page de connexion'
,p_alias=>'LOGIN'
,p_step_title=>'RestoBar  2022 - Connexion'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'Span.t-Login-logo{',
'background-image : url(#APP_FILES#icons/app-icon-512.png);',
'background-position: center;',
'background-Size :cover;',
'background-repeat: no-repeat; ',
'width :300px;',
'height : 200px;',
'}',
'',
'',
'.t-Login-region{',
'    position:relative;',
'    width:400px;',
'    --height:300px;',
'    margin:0Auto;',
'    background:rgba(182, 233, 160, 0.3);',
'    padding:20px 22px;    ',
'    border:1px solid;',
'    border-top-color:#28e972;',
'    border-left-color:#3eda4b;',
'    border-bottom-color:#24b84b;',
'    border-right-color:#0e9c0e;',
'    border-radius:5%;',
'}',
'',
'',
'.t-Login-containerBody {',
'    flex-grow: 0;',
'    BACKGROUND-COLOR: #f1ebeb;',
'    flex-shrink: 0;',
'    flex-basis: auto;',
'    display: flex;',
'    flex-direction: column;',
'    margin-top: auto;',
'    margin-bottom: px;',
'    align-items: center;',
'}',
'',
'.t-LoginPage--split .t-Login-container {',
'    background-color: #38c557;',
'    //box-shadow: 0 0 0px -4px rgba(0,0,0,.2), 0 0 0 1px rgb(0 0 0 / 4.0);',
'}',
'',
'',
'',
'body .t-Login-title {',
'    color:#37be64;',
'}',
'',
'',
'',
'.t-Form-checkboxLabel, .t-Form-inputContainer .checkbox_group label, .t-Form-inputContainer .radio_group label, .t-Form-label, .t-Form-radioLabel {',
'    color:#36c044;',
'}',
'',
'',
'',
'.t-Login-region .t-Login-body .apex-item-text {',
'    font-size: 25px;',
'    padding: 4px 36px;',
'    height: 40px;',
'    border-radius: 15px;',
'}',
'',
'',
'.a-Button--hot, .t-Button--hot:not(.t-Button--simple), body .ui-button.ui-button--hot, body .ui-state-default.ui-priority-primary {',
' ',
'    border-radius: 20px;',
'}',
'',
'a-Button--hot:hover, .a-Button--hot:not(:active):focus, .t-Button--hot:not(.t-Button--simple):hover, .t-Button--hot:not(.t-Button--simple):not(:active):focus, body .ui-button.ui-button--hot:hover, body .ui-button.ui-button--hot:not(:active):focus, bo'
||'dy .ui-state-default.ui-priority-primary:hover, body .ui-state-default.ui-priority-primary:not(:active):focus {',
'    background-color:#129e5af2;',
'}',
'.a-Icon {',
'    color: rgb(31, 122, 63);',
'    }'))
,p_step_template=>2101157952850466385
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'12'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(80612193557980304)
,p_plug_name=>'RestoBar  2022'
,p_icon_css_classes=>'app-icon'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2674157997338192145
,p_plug_display_sequence=>10
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'TEXT',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(80615048791980322)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(80612193557980304)
,p_button_name=>'LOGIN'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Ouvrir une session'
,p_button_position=>'NEXT'
,p_button_alignment=>'LEFT'
,p_grid_new_row=>'Y'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(80612600349980309)
,p_name=>'P9999_USERNAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(80612193557980304)
,p_prompt=>'Nom utilisateur'
,p_placeholder=>'Nom utilisateur'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>40
,p_cMaxlength=>100
,p_label_alignment=>'RIGHT'
,p_field_template=>2040785906935475274
,p_item_icon_css_classes=>'fa-user'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'send_on_page_submit', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(80613014802980309)
,p_name=>'P9999_PASSWORD'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(80612193557980304)
,p_prompt=>'Mot de passe'
,p_placeholder=>'Mot de passe'
,p_display_as=>'NATIVE_PASSWORD'
,p_cSize=>40
,p_cMaxlength=>100
,p_label_alignment=>'RIGHT'
,p_field_template=>2040785906935475274
,p_item_icon_css_classes=>'fa-key'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'submit_when_enter_pressed', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(80614100754980319)
,p_name=>'P9999_REMEMBER'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(80612193557980304)
,p_prompt=>unistr('M\00E9moriser le nom utilisateur')
,p_display_as=>'NATIVE_CHECKBOX'
,p_named_lov=>'LOGIN_REMEMBER_USERNAME'
,p_lov=>'.'||wwv_flow_imp.id(80613350184980311)||'.'
,p_label_alignment=>'RIGHT'
,p_display_when=>'apex_authentication.persistent_cookies_enabled'
,p_display_when2=>'PLSQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>2040785906935475274
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
unistr('Si vous cochez cette case, l''application enregistre votre nom utilisateur dans un cookie de navigateur persistant nomm\00E9 "LOGIN_USERNAME_COOKIE".'),
unistr('Lors de votre prochain acc\00E8s \00E0 la page de connexion,'),
unistr('cette valeur est automatiquement renseign\00E9e dans le champ de nom utilisateur.'),
'</p>',
'<p>',
unistr('Si vous d\00E9sactivez cette case \00E0 cocher et que votre nom utilisateur est d\00E9j\00E0 enregistr\00E9 dans le cookie,'),
'l''application le remplace par une valeur vide.',
unistr('Vous pouvez \00E9galement utiliser les outils de d\00E9veloppement de votre navigateur pour enlever enti\00E8rement le cookie.'),
'</p>'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_of_columns', '1')).to_clob
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>':'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(80615857255980325)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>unistr('D\00E9finir le cookie de nom utilisateur')
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_authentication.send_login_username_cookie (',
'    p_username => lower(:P9999_USERNAME),',
'    p_consent  => :P9999_REMEMBER = ''Y'' );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>80615857255980325
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(80615422361980323)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Login'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_authentication.login(',
'    p_username => :P9999_USERNAME,',
'    p_password => :P9999_PASSWORD );'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>80615422361980323
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(80616621849980326)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_SESSION_STATE'
,p_process_name=>'Effacer le cache des pages'
,p_attribute_01=>'CLEAR_CACHE_CURRENT_PAGE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>80616621849980326
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(80616162536980325)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Obtenir le cookie de nom utilisateur'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P9999_USERNAME := apex_authentication.get_login_username_cookie;',
':P9999_REMEMBER := case when :P9999_USERNAME is not null then ''Y'' end;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>80616162536980325
);
wwv_flow_imp.component_end;
end;
/
