prompt --application/pages/page_00151
begin
--   Manifest
--     PAGE: 00151
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>151
,p_name=>'Profil statut'
,p_alias=>'PROFIL-STATUT'
,p_step_title=>'Profil statut'
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("#FONCT.foo").each(function(){',
' $(this).closest(''tr'').css({"background-color":"red"});',
'});'))
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'03'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(197857224823285716)
,p_name=>unistr('Liste des fonctionnalit\00E9s')
,p_region_name=>'repid'
,p_template=>4072358936313175081
,p_display_sequence=>10
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select display_sequence,LIST_ENTRY_PARENT_ID,LIST_ENTRY_ID,entry_text,',
'case when LIST_ENTRY_PARENT_ID is null then ''blue''',
'       end the_color',
'from apex_application_list_entries',
'where application_id =  v(''APP_ID'')',
'and list_name not in (''Wizard Progress List'',''Access Control'',''Desktop Navigation Bar'')',
'order by display_sequence asc',
'',
''))
,p_header=>'<div style="height:800px;overflow:scroll;scrollbar-width:none;"> '
,p_footer=>'</div>'
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>1000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(86117871691502256)
,p_query_column_id=>1
,p_column_alias=>'DISPLAY_SEQUENCE'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(86118269212502256)
,p_query_column_id=>2
,p_column_alias=>'LIST_ENTRY_PARENT_ID'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(86118681869502258)
,p_query_column_id=>3
,p_column_alias=>'LIST_ENTRY_ID'
,p_column_display_sequence=>4
,p_column_heading=>'Ajouter'
,p_column_link=>'#'
,p_column_linktext=>'<span class="t-Icon fa fa-toggle-right affbons-note" aria-hidden="true"></span>'
,p_column_link_attr=>unistr('id=''#LIST_ENTRY_ID#'' class="AjoutAccess t-Button t-Button--danger t-Button--simple t-Button--small" title="Ajouter l''acc\00E8s \00E0 : #ENTRY_TEXT#"')
,p_column_alignment=>'CENTER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(86119093297502258)
,p_query_column_id=>4
,p_column_alias=>'ENTRY_TEXT'
,p_column_display_sequence=>3
,p_column_heading=>'Fonctions'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span style="color:#THE_COLOR#;display:block;width:350px;">#ENTRY_TEXT#</span>',
'',
'',
''))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(86119500523502259)
,p_query_column_id=>5
,p_column_alias=>'THE_COLOR'
,p_column_display_sequence=>5
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(197857668226285721)
,p_name=>unistr('Acc\00E8s au fonctionnalit\00E9s')
,p_template=>4072358936313175081
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_new_grid_row=>false
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUMERO_PROFIL,',
'       CODE_STATUT_PERSONNEL,',
'       LISTE_ID,',
'       PARENT_ID,',
'       SEQUENCE_ID,',
'       LIBELLE,',
'case when PARENT_ID is null then ''blue''',
'       end the_color',
'  from PROFIL_STATUT_PERSONNEL',
' where CODE_STATUT_PERSONNEL = :P151_CODE_STATUT_PERSONNEL',
' order by SEQUENCE_ID'))
,p_header=>'<div style="height:800px;overflow:scroll;scrollbar-width:none;"> '
,p_footer=>'</div> '
,p_ajax_enabled=>'Y'
,p_ajax_items_to_submit=>'P151_CODE_STATUT_PERSONNEL'
,p_lazy_loading=>false
,p_query_row_template=>2538654340625403440
,p_query_num_rows=>1000
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_show_nulls_as=>'-'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(86121010236502261)
,p_query_column_id=>1
,p_column_alias=>'NUMERO_PROFIL'
,p_column_display_sequence=>1
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(86121445392502261)
,p_query_column_id=>2
,p_column_alias=>'CODE_STATUT_PERSONNEL'
,p_column_display_sequence=>2
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(86121837731502261)
,p_query_column_id=>3
,p_column_alias=>'LISTE_ID'
,p_column_display_sequence=>6
,p_column_heading=>unistr('R\00E9tirer')
,p_column_link=>'#'
,p_column_linktext=>'<span class="t-Icon fa fa-trash-o" aria-hidden="true"></span>'
,p_column_link_attr=>unistr('id=''#LISTE_ID#'' class="RetraitAccess t-Button t-Button--danger t-Button--simple t-Button--small" title="Retirer l''acc\00E8s \00E0 : #LIBELLE#"')
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(86122234274502262)
,p_query_column_id=>4
,p_column_alias=>'PARENT_ID'
,p_column_display_sequence=>3
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(86122592431502262)
,p_query_column_id=>5
,p_column_alias=>'SEQUENCE_ID'
,p_column_display_sequence=>4
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(86123039348502262)
,p_query_column_id=>6
,p_column_alias=>'LIBELLE'
,p_column_display_sequence=>5
,p_column_heading=>'Fonction'
,p_column_html_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<span style="color:#THE_COLOR#;display:block;width:350px;">#LIBELLE#</span>',
''))
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(86123405885502264)
,p_query_column_id=>7
,p_column_alias=>'THE_COLOR'
,p_column_display_sequence=>7
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(86119900518502259)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(197857224823285716)
,p_button_name=>'reinit'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>unistr('R\00E9inisialiser mot de passe')
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:161:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86120323915502259)
,p_name=>'P151_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(197857224823285716)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86123856206502264)
,p_name=>'P151_CODE_STATUT_PERSONNEL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(197857668226285721)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Profil'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'STATUT PERSONNEL'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select libelle_statut_personnel as d,',
'       code_statut_personnel as r',
'  from statut_personnel ',
'order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_colspan=>5
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86124175265502264)
,p_name=>'P151_IDDEL'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(197857668226285721)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(86124629333502265)
,p_name=>'modif'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P151_STATUT_PERSONNEL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(86125016208502265)
,p_name=>'profil'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P151_PROFIL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(86125405760502265)
,p_name=>'prof'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P151_CODE_STATUT_PERSONNEL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86125936231502267)
,p_event_id=>wwv_flow_imp.id(86125405760502265)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(197857668226285721)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(86126303108502269)
,p_name=>'AjoutAccess'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'a.AjoutAccess'
,p_condition_element=>'P151_CODE_STATUT_PERSONNEL'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86126807253502269)
,p_event_id=>wwv_flow_imp.id(86126303108502269)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P151_ID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.id'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86127272397502269)
,p_event_id=>wwv_flow_imp.id(86126303108502269)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Veuillez s&#xE9;lectionner le profil avant !'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86127850457502270)
,p_event_id=>wwv_flow_imp.id(86126303108502269)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
' cursor c_a is select * from profil_statut_personnel',
' where liste_id = :P151_ID',
' and code_statut_personnel = :P151_CODE_STATUT_PERSONNEL;',
' r_a c_a%rowtype;',
' ',
' parent number;',
' ',
' ',
'',
' cursor c_ap is select * from profil_statut_personnel',
' where liste_id = parent',
' and code_statut_personnel = :P151_CODE_STATUT_PERSONNEL;',
' r_ap c_ap%rowtype;',
' ',
' ',
' ',
' ',
'',
'begin',
'    open c_a;',
'    fetch c_a into r_a;',
'    if c_a%notfound then',
'       insert into profil_statut_personnel select seq_profil_personnel.nextval,:P151_CODE_STATUT_PERSONNEL,LIST_ENTRY_ID,LIST_ENTRY_PARENT_ID,',
'       DISPLAY_SEQUENCE,ENTRY_TEXT from apex_application_list_entries',
'       where LIST_ENTRY_ID = :P151_ID;',
'       ',
'       select LIST_ENTRY_PARENT_ID into parent from apex_application_list_entries',
'       where LIST_ENTRY_ID = :P151_ID;',
'       ',
'       open c_ap;',
'       fetch c_ap into r_ap;',
'       if c_ap%notfound then',
'           insert into profil_statut_personnel select seq_profil_personnel.nextval,:P151_CODE_STATUT_PERSONNEL,LIST_ENTRY_ID,LIST_ENTRY_PARENT_ID,',
'           DISPLAY_SEQUENCE,ENTRY_TEXT from apex_application_list_entries',
'           where LIST_ENTRY_ID = parent;',
'       end if;',
'       close c_ap;',
'    end if;',
'    close c_a;',
'    commit;',
'end;',
'    '))
,p_attribute_02=>'P151_ID,P151_CODE_STATUT_PERSONNEL'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86128343838502270)
,p_event_id=>wwv_flow_imp.id(86126303108502269)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(197857668226285721)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(86128661928502270)
,p_name=>'RetraitAccess'
,p_event_sequence=>40
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'a.RetraitAccess'
,p_condition_element=>'P151_CODE_STATUT_PERSONNEL'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86129227233502272)
,p_event_id=>wwv_flow_imp.id(86128661928502270)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P151_IDDEL'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.id'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86129704183502272)
,p_event_id=>wwv_flow_imp.id(86128661928502270)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Veuillez s&#xE9;lectionner le profil avant !'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86130180465502272)
,p_event_id=>wwv_flow_imp.id(86128661928502270)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'parent number;',
'cursor c_ap is select * from profil_statut_personnel',
' where parent_id = parent;',
' r_ap c_ap%rowtype;',
' ',
'begin',
'    select parent_id into parent from profil_statut_personnel where liste_id = :P151_IDDEL and code_statut_personnel = :P151_CODE_STATUT_PERSONNEL;',
'    delete profil_statut_personnel where  liste_id = :P151_IDDEL and code_statut_personnel = :P151_CODE_STATUT_PERSONNEL;',
'    commit;',
'    open c_ap;',
'    fetch c_ap into r_ap;',
'    if c_ap%notfound then',
'       delete profil_statut_personnel where  liste_id = parent and code_statut_personnel = :P151_CODE_STATUT_PERSONNEL;',
'    end if;',
'    close c_ap;',
'       ',
'    commit;',
'end;'))
,p_attribute_02=>'P151_IDDEL,P151_CODE_STATUT_PERSONNEL'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86130724522502272)
,p_event_id=>wwv_flow_imp.id(86128661928502270)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(197857668226285721)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
