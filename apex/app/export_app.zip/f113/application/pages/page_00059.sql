prompt --application/pages/page_00059
begin
--   Manifest
--     PAGE: 00059
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>59
,p_name=>'Stock initial'
,p_alias=>'STOCK-INITIAL1'
,p_step_title=>'Stock initial'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(267963746384098526)
,p_plug_name=>'Point de vente'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>4
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(267986865478754419)
,p_plug_name=>'Stock i'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUM_MVT,',
'       x.NUM_PRODUIT,matricule unite_mesure,',
'       QTE,',
'       NUM_POINT_VENTE',
'from MOUVEMENT x',
'where  NUM_POINT_VENTE = :P59_PV',
'and (select code_type_produit from produits where num_produit=x.num_produit) = :P59_TYPE_PRODUIT',
'and code_type_mouvement = 24'))
,p_plug_source_type=>'NATIVE_IG'
,p_ajax_items_to_submit=>'P59_PV,P59_TYPE_PRODUIT'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(204638624865162305)
,p_name=>'UNITE_MESURE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'UNITE_MESURE'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Unite Mesure'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'trim_spaces', 'BOTH')).to_clob
,p_is_required=>false
,p_max_length=>10
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(267966317820098552)
,p_name=>'NUM_MVT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NUM_MVT'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(267966381069098553)
,p_name=>'NUM_PRODUIT'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NUM_PRODUIT'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_type=>'NATIVE_SELECT_LIST'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_is_required=>false
,p_lov_type=>'SHARED'
,p_lov_id=>wwv_flow_imp.id(81557789633430934)
,p_lov_display_extra=>false
,p_lov_display_null=>false
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'LOV'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_include_in_export=>false
,p_readonly_condition_type=>'ALWAYS'
,p_readonly_for_each_row=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(268035894875866505)
,p_name=>'QTE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'QTE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_NUMBER_FIELD'
,p_heading=>'Qte'
,p_heading_alignment=>'RIGHT'
,p_display_sequence=>60
,p_value_alignment=>'RIGHT'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
,p_format_mask=>'999G999G999G999G990D00'
,p_is_required=>true
,p_enable_filter=>true
,p_filter_is_required=>false
,p_filter_lov_type=>'NONE'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(268036226796866508)
,p_name=>'NUM_POINT_VENTE'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'NUM_POINT_VENTE'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>70
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_filter_is_required=>false
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(267966193366098551)
,p_internal_uid=>212793632910425582
,p_is_editable=>true
,p_edit_operations=>'u'
,p_lost_update_check_type=>'VALUES'
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_show_nulls_as=>'-'
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>'SAVE'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>true
,p_define_chart_view=>true
,p_enable_download=>true
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
' function(config) {',
'        let $             = apex.jQuery,',
'            toolbarData   = $.apex.interactiveGrid.copyDefaultToolbar(),',
'            addrowAction  = toolbarData.toolbarFind("selection-add-row"),',
'            saveAction    = toolbarData.toolbarFind("save"),',
'            editAction    = toolbarData.toolbarFind("edit");',
'         ',
'        addrowAction.icon = "icon-ig-add-row";',
'        addrowAction.iconBeforeLabel = true;',
'        addrowAction.hot = true;',
'        saveAction.label = "Enregistrer";',
'        saveAction.iconBeforeLabel = true;',
'        saveAction.icon ="icon-ig-save-as";',
'        saveAction.hot = true;',
'        editAction.label = "Modifier";',
'        config.toolbarData = toolbarData;',
'        return config;',
'    }'))
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(268041817405867935)
,p_interactive_grid_id=>wwv_flow_imp.id(267966193366098551)
,p_static_id=>'252149'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(268041971248867935)
,p_report_id=>wwv_flow_imp.id(268041817405867935)
,p_view_type=>'GRID'
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(204690379890887971)
,p_view_id=>wwv_flow_imp.id(268041971248867935)
,p_display_seq=>8
,p_column_id=>wwv_flow_imp.id(204638624865162305)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(268042471947867936)
,p_view_id=>wwv_flow_imp.id(268041971248867935)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(267966317820098552)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(268042948902867938)
,p_view_id=>wwv_flow_imp.id(268041971248867935)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(267966381069098553)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(268043888669867941)
,p_view_id=>wwv_flow_imp.id(268041971248867935)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(268035894875866505)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(268045405034867947)
,p_view_id=>wwv_flow_imp.id(268041971248867935)
,p_display_seq=>7
,p_column_id=>wwv_flow_imp.id(268036226796866508)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85717875648109064)
,p_name=>'P59_PROFIL'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(267963746384098526)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select code_statut_personnel  from personnel',
'    where trim(profil_app) =v(''app_user'');'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85718269832109064)
,p_name=>'P59_PV'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(267963746384098526)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Point de vente'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'POINT_VENTE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nom_point_vente as d,',
'       num_point_vente as r',
'  from point_vente where actif=''O''',
'order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.num_point_vente',
'    from affectation a,personnel p,espace_vente e',
'    where a.matricule = p.matricule',
'    and a.num_espace_vente = e.num_espace_vente',
'    and trim(profil_app) = nvl(v(''app_user''), user)',
'    and code_statut_personnel = 4;'))
,p_read_only_when_type=>'EXISTS'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(85718736467109067)
,p_name=>'P59_TYPE_PRODUIT'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(267963746384098526)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Type Produit'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'TYPE_PRODUIT_STOCK'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select libelle_type_produit as d,',
'       code_type_produit as r',
'  from type_produit',
'  where code_type_produit in (select code_type_produit from produits where STOCKABLE =''O'')',
' order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85722870549109075)
,p_name=>'AffMvt'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P59_PV,P59_TYPE_PRODUIT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85723400008109076)
,p_event_id=>wwv_flow_imp.id(85722870549109075)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(267986865478754419)
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85723855556109076)
,p_name=>'app'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P59_PROFIL'
,p_condition_element=>'P59_PROFIL'
,p_triggering_condition_type=>'NOT_EQUALS'
,p_triggering_expression=>'3'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85724263954109078)
,p_event_id=>wwv_flow_imp.id(85723855556109076)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_pv is select num_point_vente from personnel p,affectation f',
'where p.matricule = f.matricule',
'and trim(profil_app)= v(''app_user'');',
'',
'r_pv c_pv%rowtype;',
'',
'begin',
' ',
'     open c_pv;',
'     fetch c_pv into r_pv;',
'     if c_pv%found then',
'         :P59_PV:= r_pv.num_point_vente;',
'         ',
'     end if;',
'     close c_pv;',
'',
'  end;'))
,p_attribute_02=>'P59_PV'
,p_attribute_03=>'P59_PV'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85724857753109078)
,p_event_id=>wwv_flow_imp.id(85723855556109076)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P59_PV'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(85722106224109073)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(267986865478754419)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'Stock i - Save Interactive Grid Data'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>85722106224109073
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(85722525796109075)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'InitStockInit'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'cursor c_pv is select * from point_vente',
'where actif =''O'';',
'r_pv c_pv%rowtype;',
'',
'cursor c_prd is select * from produits',
'where stockable =''O''',
'and num_produit not in (select num_produit from mouvement',
'                           where num_point_vente = r_pv.num_point_vente and code_type_mouvement =24);',
'r_prd c_prd%rowtype;',
'',
'',
'begin',
'   open c_pv;',
'   loop',
'       fetch c_pv into r_pv;',
'       exit when c_pv%notfound;',
'          open c_prd;',
'          loop',
'              fetch c_prd into r_prd;',
'              exit when c_prd%notfound;',
'                   insert into mouvement values',
'                      (MOUVEMENT_NUM_MVT_SEQ.nextval/*NUM_MVT*/,r_prd.num_produit,24/*CODE_TYPE_MOUVEMENT*/,null/*NUM_BON*/,r_pv.num_point_vente/*NUM_POINT_VENTE*/,        ',
'                        null/*NUM_LIVR*/, null/*NUM_LIVR_CLT*/,null/*NUM_CMDE*/,null/*CODE_FOURN*/,0/*QTE*/,sysdate/*DATE_MVT*/,               ',
'                        0/*PU_MVT*/,''1''/*ETAT*/,nvl(v(''app_user''), user)/*CODE_UTILISATEUR*/,sysdate/*DATE_CREATION*/ ,null/*NUM_CARNET*/,',
'                        r_prd.unite_mesure/*MATRICULE*/,null/*NUM_TICKET*/,2/*CODE_NATURE_MVT*/,null);',
'          end loop;',
'          close c_prd;',
'    end loop;',
'    close c_pv;',
'    commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>85722525796109075
);
wwv_flow_imp.component_end;
end;
/
