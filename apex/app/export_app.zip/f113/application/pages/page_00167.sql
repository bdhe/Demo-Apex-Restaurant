prompt --application/pages/page_00167
begin
--   Manifest
--     PAGE: 00167
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>167
,p_name=>'Journal des ventes'
,p_alias=>'JOURNAL-DES-VENTES'
,p_step_title=>'Journal des ventes'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(340111049243728552)
,p_plug_name=>'Edition du journal des ventes '
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>4
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(86136074413566225)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(340111049243728552)
,p_button_name=>'Editer'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Editer journal'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:162:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(86136510785566225)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(340111049243728552)
,p_button_name=>'Editer_2'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>unistr('Editer R\00E9capitulatif')
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:160:&SESSION.::&DEBUG.:RP::'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86136892034566226)
,p_name=>'P167_DATEJ'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(340111049243728552)
,p_source=>'select sysdate from dual;'
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86137263118566226)
,p_name=>'P167_LIB'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(340111049243728552)
,p_source=>unistr('Edition du journal des ventes de la p\00E9riode date d\00E9but \00E0 date fin')
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86137734585566228)
,p_name=>'P167_ATTRIB'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(340111049243728552)
,p_use_cache_before_default=>'NO'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select code_statut_personnel as code from personnel',
'where trim(profil_app) =v(''app_user'');'))
,p_source_type=>'QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86138119997566229)
,p_name=>'P167_NUM_PV'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(340111049243728552)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Point de vente'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'POINT_VENTE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select nom_point_vente as d,',
'       num_point_vente as r',
'  from point_vente where actif=''O''',
'order by 1'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_colspan=>4
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86138511498566229)
,p_name=>'P167_DATE_DEBUT'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(340111049243728552)
,p_use_cache_before_default=>'NO'
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.DATEHEURE_DEBUT_VAC ',
'from vacation v,affectation a,personnel p',
'where v.num_espace_vente = a.num_espace_vente',
'and a.matricule = p.matricule',
'and cloture = ''N''',
'and trim(p.profil_app) = trim(nvl(v(''app_user''), user));'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>unistr('Date d\00E9but')
,p_format_mask=>'YYYY/MM/DD'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'appearance_and_behavior', 'MONTH-PICKER:YEAR-PICKER',
  'days_outside_month', 'VISIBLE',
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_on', 'FOCUS',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(86138880605566231)
,p_name=>'P167_DATE_FIN'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(340111049243728552)
,p_use_cache_before_default=>'NO'
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select v.DATEHEURE_DEBUT_VAC ',
'from vacation v,affectation a,personnel p',
'where v.num_espace_vente = a.num_espace_vente',
'and a.matricule = p.matricule',
'and cloture = ''N''',
'and trim(p.profil_app) = trim(nvl(v(''app_user''), user));'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Date fin'
,p_format_mask=>'YYYY/MM/DD'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'appearance_and_behavior', 'MONTH-PICKER:YEAR-PICKER',
  'days_outside_month', 'VISIBLE',
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_on', 'FOCUS',
  'show_time', 'N',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(86139614227566234)
,p_name=>'param'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P167_DATE_DEBUT,P167_DATE_FIN,P167_NUM_PV'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86140068395566236)
,p_event_id=>wwv_flow_imp.id(86139614227566234)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'nn varchar2(10);',
'nn1 varchar2(10);',
'begin',
'    if :p167_attrib not in (1,3)  then',
'       :p167_date_debut := sysdate;',
'       :p167_date_fin := sysdate;',
'    end if;',
'    nn := replace(:p167_date_debut,''/'');',
'    nn1 := replace(:p167_date_fin,''/'');',
'   PR_JVENTES(2,nn,nn1,:P167_NUM_PV);',
' ',
'    commit;',
'end;'))
,p_attribute_02=>'P167_DATE_DEBUT,P167_DATE_FIN,P167_ATTRIB,P167_NUM_PV'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(86140537828566236)
,p_name=>'attrib'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P167_ATTRIB'
,p_condition_element=>'P167_ATTRIB'
,p_triggering_condition_type=>'NOT_IN_LIST'
,p_triggering_expression=>'3,27'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86140989229566237)
,p_event_id=>wwv_flow_imp.id(86140537828566236)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  ',
'declare',
'',
'cursor c_pv is select num_point_vente from personnel p,affectation f',
'where p.matricule = f.matricule',
'and trim(profil_app)= v(''app_user'');',
'',
'r_pv c_pv%rowtype;',
'',
'begin',
'    -- :p167_date_debut := sysdate;',
'   --  :p167_date_fin := sysdate;',
'     open c_pv;',
'     fetch c_pv into r_pv;',
'     if c_pv%found then',
'         :P167_NUM_PV:= r_pv.num_point_vente;',
'         ',
'     end if;',
'     close c_pv;',
'',
'  end;'))
,p_attribute_02=>'P167_ATTRIB,P167_NUM_PV'
,p_attribute_03=>'P167_NUM_PV'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86141512060566237)
,p_event_id=>wwv_flow_imp.id(86140537828566236)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P167_DATE_DEBUT,P167_DATE_FIN,P167_NUM_PV'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(86141867296566239)
,p_name=>'PARAMFACT'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P167_NUM_FACTURE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86142403366566239)
,p_event_id=>wwv_flow_imp.id(86141867296566239)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update parametres_etats set valeur_num = :P167_NUM_FACTURE',
'where trim(nom_parametre) = ''numero_facture''',
'and code_etat = 3;',
'',
'commit;'))
,p_attribute_02=>'P167_NUM_FACTURE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(86142784149566239)
,p_name=>'num_invt'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P167_NUM_INVENT'
,p_condition_element=>'P167_NUM_INVENT'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86143347446566240)
,p_event_id=>wwv_flow_imp.id(86142784149566239)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update parametres_etats set valeur_num = :P167_NUM_INVENT',
'where  code_etat = 4;',
'commit;'))
,p_attribute_02=>'P167_NUM_INVENT'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(86143699968566240)
,p_name=>'paramcommande'
,p_event_sequence=>60
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P167_NUM_CMDE'
,p_condition_element=>'P167_NUM_CMDE'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86144160598566240)
,p_event_id=>wwv_flow_imp.id(86143699968566240)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update parametres_etats set valeur_num = :P167_NUM_CMDE',
'where trim(nom_parametre) = ''num_cmde''',
'and code_etat = 5;',
'',
'commit;'))
,p_attribute_02=>'P167_NUM_CMDE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(86144636497566242)
,p_name=>'btton'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P167_NUM_PV'
,p_condition_element=>'P167_NUM_PV'
,p_triggering_condition_type=>'NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86145149269566242)
,p_event_id=>wwv_flow_imp.id(86144636497566242)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(86136074413566225)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86145638352566244)
,p_event_id=>wwv_flow_imp.id(86144636497566242)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(86136074413566225)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86146105129566244)
,p_event_id=>wwv_flow_imp.id(86144636497566242)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(86136510785566225)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(86146617489566245)
,p_event_id=>wwv_flow_imp.id(86144636497566242)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(86136510785566225)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(86139161513566233)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'attrib'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'',
'code_stat number;',
'',
'begin',
'    select code_statut_personnel into code_stat  from personnel',
'    where trim(profil_app) =v(''app_user'');',
'    if code_stat != 3 then',
'         update parametres_etats set valeur_date = sysdate',
'        where trim(nom_parametre) = ''date_debut''',
'        and code_etat = 2;',
'',
'        update parametres_etats set valeur_date = sysdate',
'        where trim(nom_parametre) = ''date_fin''',
'        and code_etat = 2;',
'   end if;',
'',
'commit;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>86139161513566233
);
wwv_flow_imp.component_end;
end;
/
