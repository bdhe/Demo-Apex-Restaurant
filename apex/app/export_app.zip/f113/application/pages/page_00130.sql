prompt --application/pages/page_00130
begin
--   Manifest
--     PAGE: 00130
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>130
,p_name=>unistr('Commande Quantit\00E9s')
,p_alias=>unistr('COMMANDE-QUANTIT\00C9S1')
,p_page_mode=>'MODAL'
,p_step_title=>unistr('Commande Quantit\00E9s')
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'300'
,p_dialog_width=>'500'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(309422686235169186)
,p_plug_name=>unistr('Quantit\00E9s')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(38089185123511819)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(309422686235169186)
,p_button_name=>'Enregistrer'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Enregistrer'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38089514058511819)
,p_name=>'P130_NUM_PRODUIT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(309422686235169186)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38089927346511830)
,p_name=>'P130_SQTE'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(309422686235169186)
,p_use_cache_before_default=>'NO'
,p_item_default=>'0'
,p_prompt=>unistr('Quantit\00E9 ')
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(38090317831511830)
,p_name=>'P130_NUMERO_COMMANDE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(309422686235169186)
,p_use_cache_before_default=>'NO'
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(38090749873511832)
,p_name=>'QTE'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(38089185123511819)
,p_condition_element=>'P130_SQTE'
,p_triggering_condition_type=>'NOT_EQUALS'
,p_triggering_expression=>'0'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38091215735511833)
,p_event_id=>wwv_flow_imp.id(38090749873511832)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_ALERT'
,p_attribute_01=>'Veuillez saisir la quantit&#xE9; !'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38091753533511835)
,p_event_id=>wwv_flow_imp.id(38090749873511832)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'insert into DETAIL_CMDE select seq_detail_cmde.nextval,:P130_NUMERO_COMMANDE,num_produit,:P130_SQTE ,FN_PRIX_ACHAT(num_produit),code_type_produit,unite_mesure,:P130_SQTE,:P130_SQTE*FN_PRIX_ACHAT(num_produit)',
'   from produits',
'   where num_produit = :P130_NUM_PRODUIT;',
'   ',
'   '))
,p_attribute_02=>'P130_NUM_PRODUIT,P130_NUMERO_COMMANDE,P130_SQTE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(38092222489511835)
,p_event_id=>wwv_flow_imp.id(38090749873511832)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp.component_end;
end;
/
