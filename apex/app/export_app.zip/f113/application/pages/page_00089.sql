prompt --application/pages/page_00089
begin
--   Manifest
--     PAGE: 00089
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>89
,p_name=>'Menu du jour'
,p_alias=>'MENU-DU-JOUR'
,p_step_title=>'Menu du jour'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_component_map=>'08'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(238080696851960056)
,p_plug_name=>'Menu du jour'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select NUM_MENU,',
'       DATE_MENU,',
'       NUM_PRODUIT_ENTREE,',
'       NUM_PRODUIT_PLAT,',
'       NUM_PRODUIT_GARN,',
'       NUM_PRODUIT_DESSERT,',
'       NUM_PRODUIT_BOISSON,',
'       (select trim(designation_produit)|| ''+'' from produits where num_produit = NUM_PRODUIT_ENTREE )|| ',
'       (select trim(designation_produit)|| ''+'' from produits where num_produit = NUM_PRODUIT_PLAT )|| ',
'       (select trim(designation_produit)|| ''+'' from produits where num_produit = NUM_PRODUIT_GARN )|| ',
'       (select trim(designation_produit)|| ''+'' from produits where num_produit = NUM_PRODUIT_DESSERT )|| ',
'       (select trim(designation_produit) from produits where num_produit = NUM_PRODUIT_BOISSON ) nom,',
'       PRIX,',
'       CODE_UTILISATEUR,',
'       DATE_CREATION,',
'       DESIGNATION',
'  from MENU_JOUR '))
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'additional_calendar_views', 'list:navigation',
  'create_link', 'f?p=&APP_ID.:90:&SESSION.::&DEBUG.:RP:P90_DATE_MENU:&APEX$NEW_START_DATE',
  'css_class', 'NUM_MENU',
  'display_column', 'NOM',
  'drag_and_drop', 'N',
  'end_date_column', 'DATE_MENU',
  'event_sorting', 'AUTOMATIC',
  'maximum_events_day', '10',
  'multiple_line_event', 'Y',
  'primary_key_column', 'NUM_MENU',
  'show_time', 'N',
  'show_tooltip', 'Y',
  'show_weekend', 'Y',
  'start_date_column', 'DATE_MENU',
  'view_edit_link', 'f?p=&APP_ID.:90:&SESSION.::&DEBUG.:RP:P90_NUM_MENU:##NUM_MENU#')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(85309936149702300)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(238080696851960056)
,p_button_name=>'Creer'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>unistr('Cr\00E9er')
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:90:&SESSION.::&DEBUG.:RP:P90_DATE_MENU:&APEX$NEW_START_DATE'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(85310333635702301)
,p_name=>'RefreshMenu'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(85309936149702300)
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(85310779013702301)
,p_event_id=>wwv_flow_imp.id(85310333635702301)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(238080696851960056)
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
