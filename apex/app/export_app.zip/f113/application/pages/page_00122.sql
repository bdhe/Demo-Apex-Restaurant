prompt --application/pages/page_00122
begin
--   Manifest
--     PAGE: 00122
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.9'
,p_default_workspace_id=>15475120125710231
,p_default_application_id=>113
,p_default_id_offset=>16142637330772579
,p_default_owner=>'RESTOADMIN'
);
wwv_flow_imp_page.create_page(
 p_id=>122
,p_name=>'Sortie_Quantites'
,p_alias=>'SORTIE-QUANTITES'
,p_page_mode=>'MODAL'
,p_step_title=>'Sortie_Quantites'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_dialog_height=>'100'
,p_dialog_width=>'200'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(345186647174787273)
,p_plug_name=>unistr('Quantit\00E9s')
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(83849885324680095)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(345186647174787273)
,p_button_name=>'Enregistrer'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Enregistrer'
,p_button_position=>'TOP'
,p_button_alignment=>'RIGHT'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83850333769680097)
,p_name=>'P122_NUM_PRODUIT'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(345186647174787273)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83850755213680097)
,p_name=>'P122_QTE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(345186647174787273)
,p_use_cache_before_default=>'NO'
,p_item_default=>'0'
,p_prompt=>unistr('Quantit\00E9 \00E0 sortir')
,p_format_mask=>'999G999G999G999G990D00'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'right',
  'virtual_keyboard', 'text')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(83851148823680098)
,p_name=>'P122_NUMERO_SORTIE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(345186647174787273)
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(83851489621680098)
,p_name=>'QTE'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(83849885324680095)
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83851997691680100)
,p_event_id=>wwv_flow_imp.id(83851489621680098)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin ',
'if nvl(:P122_QTE,0) > 0 then',
'   insert into sortie_stock_detail select seq_det_sortie.nextval,:P122_NUMERO_SORTIE,num_produit,:P122_QTE ,',
'   v(''app_user''),sysdate,unite_mesure,code_type_produit',
'   from produits',
'   where num_produit = :P122_NUM_PRODUIT;',
'   ',
'  commit;',
' end if;',
'end;'))
,p_attribute_02=>'P122_NUM_PRODUIT,P122_QTE,P122_NUMERO_SORTIE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(83852558569680100)
,p_event_id=>wwv_flow_imp.id(83851489621680098)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CLOSE'
);
wwv_flow_imp.component_end;
end;
/
